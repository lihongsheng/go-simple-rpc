package main

import "fmt"

func defer_call() {
	val := 111
	defer func() {fmt.Println(val)}() // 因为是闭包，所以最后执行的时候最后的变量值
	defer fmt.Println(val) // 打印 111，与绑定的时候一直

	val = 222
	defer fmt.Println(val)
	//defer func(val int) {fmt.Println(val)}(val) // 依据变量传递，所以是222
	val = 333
	defer  func() {fmt.Println(val)}() // 333
}

func main() {
	defer_call()

}

func quick(sl []int,left int,right int)  {
	if left < right {
		center := GetMid(sl,left,right)
		quick(sl,left,center)
		quick(sl,center+1,right)
	}
}

func GetMid(sl []int,left int,right int)  int {
	mid := sl[left] // 做为对比值
	leftStart := left // 左右一起扫描
	for  {
		for leftStart <= right && sl[leftStart] <= mid {
			leftStart++
		}
		for leftStart <= right && sl[right] >= mid {
			right--
		}

		if leftStart >= right {
			break
		}
		tmp := sl[leftStart]
		sl[leftStart] = sl[right]
		sl[right] = tmp
	}
	sl[left] = sl[right]
	sl[right] = mid
	return right
}

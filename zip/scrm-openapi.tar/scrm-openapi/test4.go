package main

//func main()  {
//	pre := math.MinInt64
//	isValidBST := func(TreeNode *root) bool {
//		if root == nil {
//			return true
//		}
//		if !isValidBST(root.Left)
//	}
//}


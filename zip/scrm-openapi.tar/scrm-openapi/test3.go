package main

import (
	"fmt"
	"math"
)

type TreeNode struct {
	Val   int
	Left  *TreeNode
	Right *TreeNode
}

var pre = math.MinInt64
func main() {

	t1 := &TreeNode{
		Val: 6,
		Left: &TreeNode{
			Val: 4,
			Left: &TreeNode{
				Val: 3,
				Left: &TreeNode{
					Val: 1,
					Left: nil,
					Right: nil,
				},

			},
			Right: &TreeNode{
				Val: 5,
				Left: nil,
				Right: nil,
			},
		},
		Right: &TreeNode{
			Val: 10,
			Left: &TreeNode{
				Val: 7,
				Left: nil,
				Right: nil,
			},
			Right: &TreeNode{
				Val: 11,
				Left: nil,
				Right: nil,
			},
		},
	}

 //

 fmt.Println(isValidBST(t1))

 //ZX(t1)
}

func isValidBST(root *TreeNode) bool {
	if root == nil {
		return true
	}
	// 访问左子树
	if !isValidBST(root.Left) {
		return false
	}
	// 访问当前节点：如果当前节点小于等于中序遍历的前一个节点，说明不满足BST，返回 false；否则继续遍历。
	fmt.Printf("%d,%d\n",root.Val,pre)
	if root.Val <= pre {
		return false
	}
	pre = root.Val
	// 访问右子树
	return isValidBST(root.Right)
}

func Pr(tl *TreeNode)  {
	fmt.Println(tl.Val)
}

func ZX(tl *TreeNode)  {
	if tl == nil {
		return
	}
	ZX(tl.Left)
	Pr(tl)
	ZX(tl.Right)
}

//func isValidBST(root *TreeNode) bool {
//	return helper(root, math.MinInt64, math.MaxInt64)
//}
//
//func helper(root *TreeNode, lower, upper int) bool {
//	if root == nil {
//		return true
//	}
//	if root.Val <= lower || root.Val >= upper {
//		return false
//	}
//	return helper(root.Left, lower, root.Val) && helper(root.Right, root.Val, upper)
//}



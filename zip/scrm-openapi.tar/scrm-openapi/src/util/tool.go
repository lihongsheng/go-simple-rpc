package util

import (
	"context"
	"fmt"
	"github.com/go-playground/validator/v10"
	"github.com/google/uuid"
	"os"
	"runtime"
	"strings"
	"time"
	"unicode"
	"errors"

)

// CatchPanic 捕获异常
func CatchPanic()  {
	switch p := recover(); p {
	case nil:       // no panic
	default:
		// log 打印
	}

}


// FormatValidateError 格式化错误信息
func FormatValidateError(err error) error{
	var errStr strings.Builder
	if vErrs, ok:= err.(validator.ValidationErrors); ok {
		for _,er := range vErrs {
			errStr.WriteString(er.Error())
		}
		return errors.New(errStr.String())
	} else {
		return err
	}
}


// 不要用此函数
func printlnMsg(msg string,color string)  {
	conf := 1
	bg := 40
	textColor := 30
	switch color {
	case "red":
		textColor = 31
	case "yellow":
		textColor = 33
	}
	PrintColorMsg(msg,conf,bg,textColor)
}

func PrintColorMsg(msg string, conf, bg, text int) {
	fmt.Printf("\n %c[%d;%d;%dm%s%c[0m\n\n", 0x1B, conf, bg, text, msg, 0x1B)
}

func FileWithLineNum(skip int) (file string,line int) {
	_, f, l, _ := runtime.Caller(skip)
	return f,l
}

func FileWithLineNumToStr(skip int) string {
	f,l := FileWithLineNum(skip+1)
	return fmt.Sprintf("File:%s;Line:%d",f,l)
}

func GetTraceId(ctx context.Context,traceName string) string  {
	traceId := ctx.Value(traceName)
	if traceId != nil {
		return traceId.(string)
	}
	return ""
}

func FileExists(path string) bool {
	_,err := os.Stat(path)
	if os.IsNotExist(err) {
		return false
	}
	return true
}

// Case2Camel 下划线写法转为驼峰写法
func Case2Camel(name string) string {
	name = strings.Replace(name, "_", " ", -1)
	name = strings.Title(name)
	return strings.Replace(name, " ", "", -1)
}

// Lcfirst 首字母小写
func Lcfirst(str string) string {
	for i, v := range str {
		return string(unicode.ToLower(v)) + str[i+1:]
	}
	return ""
}

// Go 创建和运行 go
func Go(f func()) {
	go func(fu func()) {
		defer func() {
			if err := recover(); err != nil {
				const call = 2
				_, file, line, ok := runtime.Caller(call)
				if !ok {
					file = "???"
					line = 0
				}
				fmt.Printf("\npanic err: %s:%d %s\n\n", file, line, err)
			}
		}()
		fu()
	}(f)

}


func TimeUnix() int64 {
	return time.Now().Unix()
}

func GenerateTraceId() string {
	return uuid.New().String()
}

// GetError 获取err信息
func GetError(err interface{}) string  {
	switch err.(type) {
	case error:
		return err.(error).Error()
	case []error:
		str := strings.Builder{}
		for _,e := range err.([]error) {
			str.WriteString(e.Error())
		}
		return str.String()
	default:
		return ""
	}
}
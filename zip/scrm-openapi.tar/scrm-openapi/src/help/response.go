package help

import (
	"github.com/gin-gonic/gin"
	"net/http"
	"scrm-openapi/src/constant"
)

func  ResponseSignErr(c *gin.Context)  {
	c.JSON(http.StatusOK, constant.Response{
		Code:constant.SIGN_FAIL,
		Msg:"验签验证失败",
	})
	c.Writer.CloseNotify()
}

func  ResponseParamErr(c *gin.Context,msg string)  {
	c.JSON(http.StatusOK, constant.Response{
		Code:constant.PARAMS_NULL,
		Msg:msg,
	})
	c.Writer.CloseNotify()
}

func  ResponseMsgTypeErr(c *gin.Context,msg string)  {
	c.JSON(http.StatusOK, constant.Response{
		Code:constant.UNKNOW_MESSAGE_TYPE,
		Msg:"无法识别的消息类型:【" + msg + "】",
	})
	c.Writer.CloseNotify()
}

func ResponseJsonSuccess(c *gin.Context,data interface{})  {
	c.JSON(http.StatusOK, constant.Response{
		Code:constant.ResponseSuccess,
		Msg:"success",
		Data: data,
	})
	c.Writer.CloseNotify()
}

func ResponseJsonSuccessNoData(c *gin.Context)  {
	c.JSON(http.StatusOK, constant.Response{
		Code:constant.ResponseSuccess,
		Msg:"success",
	})
	c.Writer.CloseNotify()
}

func  ResponseJsonMsg(c *gin.Context,data interface{},msg string)  {
	c.JSON(http.StatusOK, constant.Response{
		Code:constant.ResponseSuccess,
		Msg: msg,
		Data: data,
	})
	c.Writer.CloseNotify()
}

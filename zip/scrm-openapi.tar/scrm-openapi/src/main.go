package main

import (
	"errors"
	"flag"
	"fmt"
	"os"
	"scrm-openapi/src/bootstart"
	"scrm-openapi/src/util"
)

var cfgPath string
var appEnv string
var AppPath = ""

func main() {
	AppPath,_ = os.Getwd()
	if AppPath != "" {
		AppPath += "/"
	}
	flag.StringVar(&cfgPath,"c","","")
	flag.StringVar(&appEnv,"env","","")
	flag.Parse()
	if appEnv == "" {
		fmt.Println("请设置环境变量" + cfgPath + ":" + appEnv)
		os.Exit(1)
	}

	if findConfigFile(&cfgPath,"config-" + appEnv + ".yml") != nil {
		fmt.Println("找不到配置文件" + cfgPath + "config-" + appEnv)
		os.Exit(1)
	}
	// 启动接受消息
	app := bootstart.BootStart(cfgPath)
	app.Start()
}

func findConfigFile(originFile *string,fileName string) error  {
	if *originFile == "" {
		if *originFile == "" {
			if util.FileExists(AppPath+"conf/" + fileName) {
				*originFile = AppPath+"conf/" + fileName
			} else if util.FileExists(AppPath+"../conf/" + fileName) {
				*originFile = AppPath+"../conf/" + fileName
			} else {
				return errors.New("can not find config in the path "+ *originFile)
			}
		}
		return nil
	} else {
		str := *originFile
		last := str[len(str)-2:]
		if last == "/" {
			if util.FileExists(str + fileName) {
				*originFile = str + fileName
				return nil
			}
		} else {
			if util.FileExists(str + "/" + fileName) {
				*originFile = str + "/" + fileName
				return nil
			}
		}
		return errors.New("can not find config in the path "+ *originFile)

	}
	return nil
}
package controller

import (
	"encoding/json"
	"fmt"
	"github.com/gin-gonic/gin"
	"github.com/tidwall/gjson"
	"io/ioutil"
	"net/http"
	"scrm-openapi/src/constant"
	"scrm-openapi/src/dto"
	"scrm-openapi/src/help"
	"scrm-openapi/src/modules/log"
	"scrm-openapi/src/modules/service"
)

// AcceptMessage 接受消息
func AcceptMessage(ctx *gin.Context)  {
	body,_ := ioutil.ReadAll(ctx.Request.Body) // 使用这个获取全部数据,ctx.Request.Body.Read([]byte)方式获取不全
	log.LogOut.Info(ctx.Request.Context(),"请求参数",string(body))
	jsonParam := gjson.Parse(string(body))
	msgType := 0
	var dataEntity *dto.ChatDataEntity
	var materialNotifyDataEntity *dto.MaterialNotifyDataEntity
	if jsonParam.Exists() {
		nType := jsonParam.Get("nType")
		if !nType.Exists() {
			help.ResponseParamErr(ctx,"缺少参数nType")
			return
		}
		msgType = int(nType.Int())
		if msgType == constant.QS_MATERIAL_NOTIFY { // 群消息回调成功通知
			vcContent := jsonParam.Get("vcContent").String()
			vcSign    := jsonParam.Get("vcSign").String()
			materialNotifyDataEntity = &dto.MaterialNotifyDataEntity{}
			fmt.Println(vcContent)
			if json.Unmarshal([]byte(vcContent),materialNotifyDataEntity) != nil {
				help.ResponseParamErr(ctx,"vcContent无法转换")
				log.LogOut.Info(ctx.Request.Context(),"vcContent无法转换:" ,vcContent)
				return
			}
			if !service.VerifyQianShouSign(vcContent,vcSign) {
				help.ResponseSignErr(ctx)
				log.LogOut.Info(ctx.Request.Context(),"签名验证失败", string(body))
				return
			}

		} else { // 聊天数据和群消息回调失败数据
			dataEntity = &dto.ChatDataEntity{}
			 if err := json.Unmarshal(body,dataEntity); err != nil {
				 help.ResponseParamErr(ctx,"参数错误" + err.Error())
				 log.LogOut.Info(ctx.Request.Context(),"参数错误" , string(body))
				 return
			 }
			if !service.VerifyQianShouSign(dataEntity.Data,dataEntity.Sign) {
				help.ResponseSignErr(ctx)
				log.LogOut.Info(ctx.Request.Context(),"聊天数据，签名验证失败", string(body))
				return
			}
			msgType = dataEntity.NType
		}
		switch msgType {
		case constant.QS_MATERIAL_FAIL:
			err := service.SyncPushMaterialFailNotify(ctx.Request.Context(), dataEntity.Data)
			if err != nil {
				help.ResponseParamErr(ctx,"链接出错")
				return
			}
			log.LogOut.Info(ctx.Request.Context(),"回调发送成功", dataEntity)
		case constant.QS_MATERIAL_NOTIFY:
			err := service.SyncPushMaterialResultNotify(ctx.Request.Context(), *materialNotifyDataEntity)
			if err != nil {
				help.ResponseParamErr(ctx,"转发队列出错" + err.Error())
				return
			}
			log.LogOut.Info(ctx.Request.Context(),"回调发送成功", materialNotifyDataEntity)
		case constant.QS_GROUP_MEMBER_SYNC:
			err := service.SyncGroupMemberInfo(ctx.Request.Context(),dataEntity)
			if err != nil {
				help.ResponseParamErr(ctx,"存储群成员出错" + err.Error())
				return
			}

		default:
			help.ResponseMsgTypeErr(ctx,string(msgType))
			return
		}
	}
	ctx.JSON(http.StatusOK, constant.Response{
		Code:constant.ResponseSuccess,
		Msg:"success1",
		Data: nil,
	})

}


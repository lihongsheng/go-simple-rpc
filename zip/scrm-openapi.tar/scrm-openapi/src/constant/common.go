package constant

const (
	ResponseSystemError = -1
	ResponseSuccess = 0
	SIGN_FAIL = 599
	PARAMS_NULL = 597
	UNKNOW_MESSAGE_TYPE = 598
)


type Response struct {
	Code int           `json:"code"`
	Msg  string        `json:"msg"`
	Data interface{} `json:"data"`
}

var Tips = struct {
	SystemErrorMsg string
}{
	SystemErrorMsg: "系统异常",
}

const (
	QS_ADD = 3005 //主动加好友/机器人被加
	QS_JP = 4505 // 入群
	QS_OP1 = 4014 // 自动注销群
	QS_OP2 = 4007 //,"机器人主动退群"),
	QS_OP3 = 4507 //,"机器人被踢出群"),
	QS_OP4 = 4015 //,"触发系统规则退群"),
	QS_SR = 1010//1010,"机器人封号"),
	QS_GU =4001 //(4001,"群基础信息变更"),
	QS_MSG_SYNC = 5003//, "群消息同步"),
	QS_MATERIAL_NOTIFY = 50021 //, "任务状态回调接口"),
	QS_MATERIAL_FAIL = 5002 //, "群聊消息发送失败结果回调"),
	QS_GROUP_MEMBER_SYNC = 4501 //, "群成员信息同步"),
	QS_UNKONWN = -10000//-10000,"未知");
)


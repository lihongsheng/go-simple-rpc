package constant

const (
//推送结果回调队列
 SCRM_PUSH_MATERIAL_NOTIFY_MESSAGE_QUEUE = "nicetuan.push.material.notify.queue";
 SCRM_PUSH_MATERIAL_NOTIFY_ROUTE_KEY = "nicetuan.push.material.notify.key";
 SCRM_PUSH_MATERIAL_NOTIFY_EXCHANGE = "nicetuan.push.material.notify.direct";

//消息推送失败回调队列
 SCRM_PUSH_MATERIAL_FAIL_NOTIFY_MESSAGE_QUEUE = "nicetuan.push.fail.material.notify.queue";
 SCRM_PUSH_MATERIAL_FAIL_NOTIFY_ROUTE_KEY = "nicetuan.push.fail.material.notify.key";
 SCRM_PUSH_MATERIAL_FAIL_NOTIFY_EXCHANGE = "nicetuan.push.fail.material.notify.direct";
)
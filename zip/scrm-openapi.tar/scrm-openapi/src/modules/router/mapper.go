package router

import (
	"fmt"
	"github.com/gin-gonic/gin"
	controller2 "scrm-openapi/src/controller"
)

type ApiMethod int

const (
	GET  ApiMethod = iota
	POST
	PUT
	ANY
)

func (a ApiMethod) String() string {
	switch a {
	case GET:
		return "GET"
	case POST:
		return "POST"
	case PUT:
		return "PUT"
	case ANY:
		return "ANY"
	default:
		return fmt.Sprintf("ApiMethod(%d)", a)
	}
}



func RegisterApiNoParam(api gin.HandlerFunc,apiMethod ApiMethod,urlPath  string)  {
	rs := routerStruct{
		api: api,
		path: urlPath,
	}
	routers[apiMethod.String()] = append(routers[apiMethod.String()],rs)
}

type routerStruct struct {
	api gin.HandlerFunc
	path string
}
var routers =  make(map[string][]routerStruct)

func InitRouter(engine *gin.Engine) {
	// 默认 gin.context参数的
	for key, apiList := range routers {
		switch key {
		case "POST":
			for _,api := range apiList {
				engine.POST(api.path,api.api)
			}
		case "GET":
			for _,api := range apiList {
				engine.GET(api.path,api.api)
			}
		case "PUT":
			for _,api := range apiList {
				engine.PUT(api.path,api.api)
			}
		case "ANY":
			for _,api := range apiList {
				engine.Any(api.path,api.api)
			}
		}
	}
}

func init()  {
	// 接受消息
	RegisterApiNoParam(controller2.AcceptMessage,POST,"/message/accept")
}


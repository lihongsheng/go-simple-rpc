package service

import (
	"crypto/md5"
	"fmt"
	"scrm-openapi/src/library"
)

func VerifyQianShouSign(vcContent string,vcSign string) bool  {
	sign := library.Config.GetString("qs.api_key")
	content := vcContent + sign
	hex := md5.Sum([]byte(content))
	newSign := fmt.Sprintf("%x",hex)
	if newSign != vcSign {
		return false
	}
	return true
}

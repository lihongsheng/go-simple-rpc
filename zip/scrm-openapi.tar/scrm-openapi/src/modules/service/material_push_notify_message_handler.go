package service

import (
	"context"
	"encoding/json"
	"errors"
	"reflect"
	"scrm-openapi/src/constant"
	"scrm-openapi/src/dto"
	"scrm-openapi/src/library"
	"scrm-openapi/src/modules/log"
)

func SyncPushMaterialResultNotify(context context.Context, dataEntity dto.MaterialNotifyDataEntity) error {
	dataStr,_ := json.Marshal(dataEntity.Data)
	data := dto.MaterialNotifyDataEntityString{
		NType         :dataEntity.NType,
		NBusinessType   :dataEntity.NBusinessType,
		NBrandId        :dataEntity.NBrandId,
		NPushType       :dataEntity.NPushType,
		VcRobotSerialNo :dataEntity.VcRobotSerialNo,
		VcSerialNo      :dataEntity.VcSerialNo,
		NResult         :dataEntity.NResult,
		VcResult       :dataEntity.VcResult,
		DTimeStamp      :dataEntity.DTimeStamp,
		Data: string(dataStr),
	}
	return sendMq(context,
		constant.SCRM_PUSH_MATERIAL_NOTIFY_EXCHANGE,
		constant.SCRM_PUSH_MATERIAL_NOTIFY_ROUTE_KEY,
		data)
}

func SyncPushMaterialFailNotify(context context.Context, dataEntity string) error {
	return sendMq(context,
		constant.SCRM_PUSH_MATERIAL_FAIL_NOTIFY_EXCHANGE,
		constant.SCRM_PUSH_MATERIAL_FAIL_NOTIFY_ROUTE_KEY,
		dataEntity)
}

func sendMq(context context.Context, exchange string, router string, msg interface{}) error {
	r, err := library.GetRabbitClient("rabbitmq")
	if err != nil {
		log.LogOut.Error(context, "rabbit链接失败:", msg)
		return errors.New("rabbit链接失败:")
	}
	if reflect.TypeOf(msg).Kind() == reflect.String {
		return r.Send(context,
			exchange,
			router,
			[]byte(msg.(string)))
	} else {
		return r.SendAndCovert(context,
			exchange,
			router,
			msg)
	}


}


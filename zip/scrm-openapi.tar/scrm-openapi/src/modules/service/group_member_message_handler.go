package service

import (
	"context"
	"crypto/md5"
	"encoding/json"
	"errors"
	"fmt"
	"scrm-openapi/src/dto"
	"scrm-openapi/src/library"
	"scrm-openapi/src/model"
	"scrm-openapi/src/modules/log"
	"scrm-openapi/src/types"
	"strconv"
	"strings"
	"time"
)

// 以下代码逻辑来自于Java，写的是个啥玩意，自己理解

func SyncGroupMemberInfo(context context.Context, dataEntity *dto.ChatDataEntity) error {
	content := dataEntity.Data
	groupMemberDataEntity := &dto.GroupMemberDataEntity{}
	if err := json.Unmarshal([]byte(content), groupMemberDataEntity); err != nil {
		return errors.New("无法解析GroupMemberDataEntity" + err.Error())
	}
	groupMemberDataEntity.GroupMemberDetail = dto.GroupMemberDetail{}
	if err := json.Unmarshal([]byte(groupMemberDataEntity.Data), &groupMemberDataEntity.GroupMemberDetail); err != nil {
		return errors.New("无法解析groupMemberDataEntity.GroupMemberDetail" + err.Error())
	}

	if len(groupMemberDataEntity.GroupMemberDetail.Members) <= 0 {
		return nil
	}

	groupMemberInfoList := make([]*dto.GroupMemberInfo, 0)
	for _, groupMemberDetail := range groupMemberDataEntity.GroupMemberDetail.Members {
		groupMemberInfo := &dto.GroupMemberInfo{}
		groupMemberInfo.VcRobotWxId = groupMemberDataEntity.VcRobotWxId
		groupMemberInfo.VcRobotSerialno = groupMemberDataEntity.VcRobotSerialno
		groupMemberInfo.VcMemberUserWxId = groupMemberDetail.VcMemberUserWxId
		groupMemberInfo.VcMemberUserSerialno = groupMemberDetail.VcMemberUserSerialNo
		groupMemberInfo.VcNickName = groupMemberDetail.VcNickName
		groupMemberInfo.VcGroupNickName = groupMemberDetail.VcGroupNickName
		groupMemberInfo.VcHeadImgUrl = groupMemberDetail.VcHeadImgUrl
		groupMemberInfo.VcFatherWxId = groupMemberDetail.VcFatherWxId
		groupMemberInfo.VcFatherWxUserSerialno = groupMemberDetail.VcFatherWxUserSerialNo
		groupMemberInfo.VcChatRoomSerialno = groupMemberDataEntity.GroupMemberDetail.VcChatRoomSerialNo
		groupMemberInfo.NIsAdmin = checkGroupMemberIsAdmin(groupMemberDataEntity.GroupMemberDetail.VcChatAdminWxUserSerialNo, groupMemberDataEntity.GroupMemberDetail.Members)
		groupMemberInfoList = append(groupMemberInfoList, groupMemberInfo)
	}
	// 重设admin字段
	if len(groupMemberDataEntity.GroupMemberDetail.Managers) > 0 {
		resetGroupMemberIsAdmin(groupMemberInfoList, groupMemberDataEntity.GroupMemberDetail.Managers)
	}
	log.LogOut.Info(context, "bactInsertGroupMemberList", groupMemberInfoList)
	bactInsertGroupMemberList(context, groupMemberInfoList)

	return nil
}

// bactInsertGroupMemberList 插入数据表
func bactInsertGroupMemberList(ctx context.Context, groupMemberInfoList []*dto.GroupMemberInfo) error {
	if len(groupMemberInfoList) <= 0 {
		return nil
	}
	vcChatRoomSerialNoListzMap := make(map[string]int) //标记是否已经添加过，去除重复数据
	vcChatRoomSerialNoList := make([]string, 0)
	for _, gm := range groupMemberInfoList {
		if _, exit := vcChatRoomSerialNoListzMap[gm.VcChatRoomSerialno]; exit {
			continue
		}
		vcChatRoomSerialNoListzMap[gm.VcChatRoomSerialno] = 1
		vcChatRoomSerialNoList = append(vcChatRoomSerialNoList, gm.VcChatRoomSerialno)
	}

	time := 10
	// 获取成员列表
	key := getKey(vcChatRoomSerialNoList, "B")
	memList := getGroupInfoList(ctx, key, vcChatRoomSerialNoList, time)
	if len(memList) <= 0 {
		log.LogOut.Info(ctx, "no-site-param-1")
		return nil
	}

	list := buildMemberInfo(memList, groupMemberInfoList)
	if len(list) <= 0 {
		log.LogOut.Info(ctx, "no-site-param-2")
		return nil
	}

	key = getKey(vcChatRoomSerialNoList, "A")
	distinctByUniqueList := getDistinctByUniqueList(ctx, key, vcChatRoomSerialNoList, list, time)
	if len(distinctByUniqueList) > 0 {
		log.LogOut.Info(ctx, "insert-distinctByUniqueList", distinctByUniqueList)
		return model.NewGroupmembersiteRelationDao(ctx).Insert(distinctByUniqueList)
	}

	return nil
}

func getDistinctByUniqueList(ctx context.Context, key string, vcChatRoomSerialNoList []string, scrmGroupInfoList []model.GroupmembersiteRelation, t int) []model.GroupmembersiteRelation {
	groupInfoListAlreadyExists, _ := getData(ctx, key)
	if len(groupInfoListAlreadyExists) <= 0 {
		groupInfoListAlreadyExists, _ = model.NewGroupmembersiteRelationDao(ctx).SelectDataByGroupIds(vcChatRoomSerialNoList)
		if len(groupInfoListAlreadyExists) > 0 {
			rdb, _ := library.BuildClient("redis")
			con, _ := json.Marshal(groupInfoListAlreadyExists)
			ti := time.Duration(t) * time.Second
			rdb.Set(ctx, key, string(con), ti)
		}
	}
	log.LogOut.Info(ctx, "insert-groupInfoListAlreadyExists", groupInfoListAlreadyExists)
	distinctByUniqueList := make([]model.GroupmembersiteRelation, 0)
	for _, mem := range scrmGroupInfoList {
		isExit := false
		for _, scrmGroupInfo := range groupInfoListAlreadyExists {
			if mem.GroupNo == scrmGroupInfo.GroupNo && mem.GroupMemberNo == scrmGroupInfo.GroupMemberNo {
				isExit = true
				break
			}
		}
		if !isExit {
			distinctByUniqueList = append(distinctByUniqueList, mem)
		}
	}

	return distinctByUniqueList

}

func buildMemberInfo(memberList []model.GroupmembersiteRelation, groupMemberInfoList []*dto.GroupMemberInfo) []model.GroupmembersiteRelation {
	list := make([]model.GroupmembersiteRelation, 0)
	mapList := make(map[string]int)
	for _, scrmGroupInfo := range memberList {
		for _, groupMemberInfo := range groupMemberInfoList {
			if scrmGroupInfo.GroupNo == groupMemberInfo.VcChatRoomSerialno {
				// 去重
				if _, exit := mapList[scrmGroupInfo.GroupNo+scrmGroupInfo.SiteName+strconv.Itoa(scrmGroupInfo.SiteId)]; exit {
					continue
				}
				mapList[scrmGroupInfo.GroupNo+scrmGroupInfo.SiteName+strconv.Itoa(scrmGroupInfo.SiteId)] = 1
				groupmembersiteRelation := model.GroupmembersiteRelation{
					//机器人微信id
					VcRobotWxId: groupMemberInfo.VcRobotWxId,
					//群机器人编号
					VcRobotSerialno: groupMemberInfo.VcRobotSerialno,
					//群成员微信id
					VcMemberUserWxId: groupMemberInfo.VcMemberUserWxId,
					//邀请人用户微信id
					VcFatherWxId: groupMemberInfo.VcFatherWxId,
					//邀请人用户编号
					VcFatherWxUserSerialno: groupMemberInfo.VcFatherWxUserSerialno,
					//群成员昵称
					VcNickName: groupMemberInfo.VcNickName,
					//群成员头像
					VcHeadImgUrl: groupMemberInfo.VcHeadImgUrl,
					//是否是群主  0 群成员 1 群主 2 群管
					IsAdmin: groupMemberInfo.NIsAdmin,
					//群编号
					GroupNo: groupMemberInfo.VcChatRoomSerialno,
					//群名称
					GroupName: scrmGroupInfo.GroupName,
					//群成员编号
					GroupMemberNo: groupMemberInfo.VcMemberUserSerialno,
					//主站id
					SiteId: scrmGroupInfo.SiteId,
					//主站名称
					SiteName: scrmGroupInfo.SiteName,
					//是否删除
					IsDeleted:   0,
					GmtCreate:   types.LocalDateTime(time.Now()),
					GmtModified: types.LocalDateTime(time.Now()),
				}
				list = append(list, groupmembersiteRelation)
			}
		}
	}

	return list
}

func getGroupInfoList(ctx context.Context, key string, vcChatRoomSerialNoList []string, t int) []model.GroupmembersiteRelation {
	mist, _ := getData(ctx, key)
	log.LogOut.Info(ctx, "getGroupInfoList-redis-00000", mist)
	if len(mist) <= 0 {
		log.LogOut.Info(ctx, "getGroupInfoList-redis", vcChatRoomSerialNoList)
		gr := model.NewGroupmembersiteRelationDao(ctx)
		mist, _ = gr.GetRelationshipWithGroupAndMember(vcChatRoomSerialNoList)
		log.LogOut.Info(ctx, "getGroupInfoList-redis", mist)
		if len(mist) > 0 {
			rdb, _ := library.BuildClient("redis")
			con, _ := json.Marshal(mist)
			ti := time.Duration(t) * time.Second
			rdb.Set(ctx, key, string(con), ti)
		}
	}
	log.LogOut.Info(ctx, "getGroupInfoList-redis-00", mist)
	list := make([]model.GroupmembersiteRelation, 0)
	mapList := make(map[string]int) // 标记是否已经添加过，去除重复数据
	if len(mist) > 0 {
		for _, mem := range mist {
			if _, exit := mapList[mem.GroupNo+mem.SiteName+strconv.Itoa(mem.SiteId)]; exit {
				continue
			}
			mapList[mem.GroupNo+mem.SiteName+strconv.Itoa(mem.SiteId)] = 1
			list = append(list, mem)
		}
		log.LogOut.Info(ctx, "getGroupInfoList-memberList", list)
		return list
	}
	return list
}

// 重缓存获取值
func getData(ctx context.Context, key string) (list []model.GroupmembersiteRelation, err error) {
	rdb, err := library.BuildClient("redis")
	if err != nil {
		return list, err
	}
	data, err := rdb.Get(ctx, key).Result()
	if err != nil {
		return list, err
	}
	json.Unmarshal([]byte(data), &list)
	return list, nil
}

// 迁移至Java代码，写的不知道是个啥玩意
func getKey(keyList []string, keyType string) string {
	size := len(keyList)
	keyStr := ""
	str := strings.Builder{}
	for i := 0; i < size; i++ {
		s := keyList[i]
		if i < size-1 {
			str.WriteString(s)
			str.WriteString("_")
			keyStr = str.String()
		}
		if i == size-1 {
			str.WriteString(s)
			str.WriteString("_")
			str.WriteString(keyType)
			str.WriteString("_nicetuan")
			keyStr = str.String()
		}
	}
	// 这里做了MD5，防止键值过长
	hex := md5.Sum([]byte(keyStr))
	return fmt.Sprintf("%x", hex)
}

func checkGroupMemberIsAdmin(VcChatAdminWxUserSerialNo string, Members []dto.Members) int {
	for _, Member := range Members {
		if Member.VcMemberUserSerialNo == VcChatAdminWxUserSerialNo {
			return 1
		}
	}
	return 0
}

func resetGroupMemberIsAdmin(groupMemberInfoList []*dto.GroupMemberInfo, managerList []dto.Managers) {
	for _, groupMemberInfo := range groupMemberInfoList {
		for _, manager := range managerList {
			if manager.VcManagerSerialNo == groupMemberInfo.VcMemberUserSerialno {
				groupMemberInfo.NIsAdmin = 2
			}
		}
	}
}

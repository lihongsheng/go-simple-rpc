package model

import (
	"context"
	"scrm-openapi/src/types"
)

type GroupmembersiteRelationDao struct {
	table string
	Dao
}

func NewGroupmembersiteRelationDao(ctx context.Context) *GroupmembersiteRelationDao {
	db := GetConnect("db.scrm")
	db = db.WithContext(ctx)
	return &GroupmembersiteRelationDao{
		table: "scrm_groupmembersite_relation",
		Dao: Dao{
			connect: "db.scrm",
			db: db,
		},
	}
}

type GroupmembersiteRelation struct {
	Id int64 `gorm:"type:int(20);column:id;primaryKey;autoIncrement;comment:" json:"id"`
	GroupNo string  `gorm:"type:varchar(64);column:group_no;comment:" json:"group_no"`
	GroupName  string  `gorm:"type:varchar(128);column:group_name;comment:" json:"group_name"`
	GroupMemberNo string  `gorm:"type:varchar(64);column:group_member_no;comment:" json:"group_member_no"`
	SiteId  int `gorm:"type:int(11);column:site_id;primaryKey;autoIncrement;comment:" json:"site_id"`
	SiteName string  `gorm:"type:varchar(64);column:site_name;comment:" json:"site_name"`
	VcHeadImgUrl string  `gorm:"type:varchar(512);column:vc_head_img_url;comment:" json:"vc_head_img_url"`
	VcRobotWxId string  `gorm:"type:varchar(64);column:vc_robot_wx_id;comment:" json:"vc_robot_wx_id"`
	VcRobotSerialno  string  `gorm:"type:varchar(128);column:vc_robot_serialno;comment:" json:"vc_robot_serialno"`
	VcMemberUserWxId string  `gorm:"type:varchar(128);column:vc_member_user_wx_id;comment:" json:"vc_member_user_wx_id"`
	VcFatherWxId string  `gorm:"type:varchar(128);column:vc_father_wx_id;comment:" json:"vc_father_wx_id"`
	VcFatherWxUserSerialno string  `gorm:"type:varchar(128);column:vc_father_wx_user_serialno;comment:" json:"vc_father_wx_user_serialno"`
	VcNickName string `gorm:"type:varchar(64);column:vc_nick_name;comment:" json:"vc_nick_name"`
	IsAdmin int `gorm:"type:int(4);column:is_admin;primaryKey;autoIncrement;comment:" json:"is_admin"`
	IsDeleted int `gorm:"type:int(4);column:is_deleted;primaryKey;autoIncrement;comment:" json:"is_deleted"`
	GmtModified types.LocalDateTime `gorm:"type:date;column:gmt_modified;comment:" json:"gmt_modified,string"`
	GmtCreate types.LocalDateTime `gorm:"type:date;column:gmt_create;comment:" json:"gmt_create,string"`
}

func (d *GroupmembersiteRelationDao) Insert(list []GroupmembersiteRelation) error  {
	result := d.db.Table(d.table).Create(list)
	return result.Error
}

func (d *GroupmembersiteRelationDao) GetRelationshipWithGroupAndMember(ChatRoomSerialNoList []string) (list []GroupmembersiteRelation,err error) {
	if err = d.db.Table( "scrm_robot_group as srg").
		// srg.robot_group_count as num        -- 群成员数量 这个字段在此无用
		Select("srg.robot_group_no as group_no,srg.robot_group_name as group_name,srg.site_id as site_id,ssbs.site_name as site_name").
		 Joins("LEFT JOIN scrm_site_bind_sm ssbs ON srg.site_id = ssbs.site_id where srg.robot_group_no IN ?",ChatRoomSerialNoList).
	     Find(&list).Error; err != nil {
		return list,err
	}
	return list,nil

}

func (d *GroupmembersiteRelationDao) SelectDataByGroupIds(groupNoList []string) (list []GroupmembersiteRelation,err error)  {
	err = d.db.Table(d.table).Where("is_deleted = 0 AND group_no  IN ?",groupNoList).Find(&list).Error
	return list, err
}
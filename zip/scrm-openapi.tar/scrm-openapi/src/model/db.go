package model

import (
	"context"
	"fmt"
	"gorm.io/driver/mysql"
	"gorm.io/gorm"
	"gorm.io/gorm/logger"
	"gorm.io/gorm/schema"
	"scrm-openapi/src/config"
	"scrm-openapi/src/library"
	"scrm-openapi/src/modules/log"
	"sync"
	"time"
)

var connects = make(map[string]*gorm.DB)
var lock sync.Mutex

// GetConnect 加载配置
func GetConnect(key string) *gorm.DB {
	if v,exit := connects[key];exit {
		return v
	}
	lock.Lock()
	if v,exit := connects[key];exit {
		lock.Unlock()
		return v
	}
	conf := &config.MysqlConf{}
	if err := library.Config.UnmarshalKey(key,conf); err != nil {
		panic("加载配置异常" + err.Error())
	}
	connects[key] = newConnnect(*conf)
	lock.Unlock()
	return connects[key]
}

func newConnnect(mysql2 config.MysqlConf) *gorm.DB  {
	dns := getDns(mysql2)
	db, err := gorm.Open(mysql.Open(dns), &gorm.Config{
		// gorm日志模式：silent
		Logger: log.NewSqlLog(log.InfoLevel).LogMode(logger.Info),
		// 外键约束
		DisableForeignKeyConstraintWhenMigrating: true,
		// 禁用默认事务（提高运行速度）
		SkipDefaultTransaction: true,
		NamingStrategy: schema.NamingStrategy{
			// 使用单数表名，启用该选项，此时，`User` 的表名应该是 `user`
			SingularTable: true,
		},
	})

	if err != nil {
		fmt.Println(fmt.Sprintf("连接数据库失败，请检查参数：%s", err.Error()),"red")
		return nil
	}
	sqlDB, _ := db.DB()
	// SetMaxIdleCons 设置连接池中的最大闲置连接数。
	maxIdleConn := 10
	if mysql2.MaxIdleConn  > 0 {
		maxIdleConn = mysql2.MaxIdleConn
	}
	sqlDB.SetMaxIdleConns(maxIdleConn)

	// SetMaxOpenCons 设置数据库的最大连接数量。
	maxOpenConn := 10
	if mysql2.MaxOpenConn  > 0 {
		maxOpenConn = mysql2.MaxOpenConn
	}

	sqlDB.SetMaxOpenConns(maxOpenConn)
	// SetConnMaxLifetiment 设置连接的最大可复用时间。
	connMaxLifetime := 30 * time.Second
	if mysql2.ConnMaxLifetime  > 0 {
		connMaxLifetime = time.Duration(mysql2.ConnMaxLifetime) * time.Second
	}
	sqlDB.SetConnMaxLifetime(connMaxLifetime)

	return db
}

func getDns(mysql2 config.MysqlConf) string  {
	return fmt.Sprintf("%s:%s@tcp(%s:%d)/%s?charset=%s&parseTime=True&loc=Local",
		mysql2.User,
		mysql2.Password,
		mysql2.Host,
		mysql2.Port,
		mysql2.DbName,
		mysql2.Chart,
	)
}



type DaoConnect interface {
	GetConnect() string
	GetTable() string
}

type Dao struct {
	ctx context.Context
	db *gorm.DB
	connect string
}

func (d Dao) GetDb() *gorm.DB {
	return d.db
}

func (d Dao) GetConnect() string {
	return d.connect
}

func (d *Dao) WithContext(ctx context.Context) {
	d.db = d.db.WithContext(ctx)
	d.ctx = ctx
}
package bootstart

import (
	"context"
	"fmt"
	"github.com/gin-gonic/gin"
	"net/http"
	"os"
	"os/signal"
	"scrm-openapi/src/library"
	"scrm-openapi/src/modules/log"
	"scrm-openapi/src/modules/router"
	"scrm-openapi/src/util"
	"strconv"
	"syscall"
	"time"
)

type Application struct {
	Port int `yaml:"port"`
	Name string `yaml:"name"`
	Version string `yaml:"version"`
}

var App *Application
func BootStart(configFile string) *Application {
	App := &Application{
	}
	library.Config = &library.ConfigStruct{}

	library.Config.InitConfig(configFile)
	if err := library.Config.UnmarshalKey("application",App);err != nil {
		fmt.Println("无法找到应用默认配置节点application" + err.Error())
		os.Exit(1)
	}
	fmt.Println(configFile)
	log.InitLog(library.Config.GetString("logPath"),"chat")
	return App
}

func httpHandlers() *gin.Engine{
	//gin.SetMode(config.ConfigMap.Mode)
	engine := gin.New()
	gin.DisableConsoleColor()
	// 给gin的每个请求赋予traceID
	// 其他公共中间件
	//middleware.LoadMiddle(engine)
	// 替换 gin的log
	engine.Use(creatTraceId())
	engine.Use(log.GinRequestLog(),log.RecoveryWithZap())
	// 注册路由
	router.InitRouter(engine)
	//gin.DefaultWriter = log.LogOut
	engine.GET("/actuator", func(c *gin.Context) {
		c.JSON(200, struct {
			Name string `json:"name"`
		}{Name: "hello"})
		log.LogOut.Info(context.TODO(),"request1","hello word111")
	})
	return engine
}
// CreatTraceId 给 gin 的上下文加上 traceID
func creatTraceId() gin.HandlerFunc {
	return func(c *gin.Context) {
		// 接受外部和自定义 tag
		c.Request = c.Request.WithContext(context.WithValue(c.Request.Context(),"trace_id",util.GenerateTraceId()))
		//c.Request = c.Request.WithContext(context.WithValue(c.Request.Context(),"trace_id",util.GenerateTraceId()))
		c.Next()
	}
}

func (a *Application) Start()  {
	// 监听的服务IP和地址，0.0.0.0表示监控所有IP
	fmt.Println(a.Port)
	addr := "0.0.0.0:"+ strconv.Itoa(a.Port)
	timeOut := 10 * time.Second
	// 启动 go自带的HTTP_SERVER
	httpServer := &http.Server{
		Addr:         addr,
		Handler:      httpHandlers(), // 返回 gin实现的 serverHttp 接口
		WriteTimeout: timeOut,
		ReadTimeout:  timeOut,
	}
	// 启动程序
	util.Go(func() {
		fmt.Println("start by "+ addr + " success")
		if err := httpServer.ListenAndServe(); err != nil && err != http.ErrServerClosed {
			panic(err)
		}
	})
	// 监听系统信号，如 control + c的中断信号
	quit := make(chan os.Signal, 1)
	signal.Notify(quit, syscall.SIGINT, syscall.SIGTERM, syscall.SIGCHLD)
	// 阻塞等待系统信号
	<-quit
	// 处理未完成的请求, 响应超时
	now := time.Now()
	ctx, cancel := context.WithTimeout(context.Background(), 15*time.Second)
	defer cancel()
	// 关闭 http server
	if err := httpServer.Shutdown(ctx); err != nil {
		fmt.Println(err)
	}
	log.Close()
	fmt.Println("exit elapsed time: "+time.Since(now).String(),"red")
}

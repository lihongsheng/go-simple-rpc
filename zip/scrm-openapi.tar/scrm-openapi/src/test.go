package main

import (
	"fmt"
	"github.com/streadway/amqp"
	"os"
	"os/signal"
	"syscall"
)

type ss struct {
	A string
	B string
}
func main()  {
	go func() {
		con,_ := amqp.Dial("amqp://guest:guest@127.0.0.1:5672/")
		ch,_ := con.Channel()
		msgs, _ := ch.Consume(
			"test", // queue
			"test1",     // consumer
			false,   // auto ack
			false,  // exclusive
			false,  // no local
			false,  // no wait
			nil,    // args
		)

		for d := range msgs {
			d.Ack(false)
			fmt.Println(string(d.Body) + ": test1")
		}
	}()

	go func() {
		con,_ := amqp.Dial("amqp://guest:guest@127.0.0.1:5672/")
		ch,_ := con.Channel()
		msgs, _ := ch.Consume(
			"test", // queue
			"test2",     // consumer
			false,   // auto ack
			false,  // exclusive
			false,  // no local
			false,  // no wait
			nil,    // args
		)

		for d := range msgs {
			d.Ack(true)
			fmt.Println(string(d.Body) + ": test2")
		}
	}()

	quit := make(chan os.Signal, 1)
	signal.Notify(quit, syscall.SIGINT, syscall.SIGTERM, syscall.SIGCHLD)
	// 阻塞等待系统信号
	<-quit
}

package library

import (
	"context"
	"encoding/json"
	"errors"
	"github.com/streadway/amqp"
	"scrm-openapi/src/config"
	"scrm-openapi/src/modules/log"
	"strconv"
	"sync"
	"time"
)

const (
	DIRECT = "direct"
	TOPIC = "topic"
	FANOUT = "fanout"
	HEADERS = "headers"
)

// rabbit的发送消息模式有四种
// direct 直连模式 ，推荐使用。支持路由的设置。此模式下一个exchange可以对应多个queue，而消息发送到那个queue是根据路由来匹配的
// topic 主题模式，支持路由的设置，且支持正则匹配的方式是匹配路由。其他与直连模式一样
// header模式 不推荐使用。基于header头里来匹配发送到那个queue。路由在此模式下无用
// pub/sub 发布订阅模式，路由建无用，消息发送到exchange下所有的queue

// rabbit 支持延迟消息需要设置过期时间和过期转移的exchange和路由键。所有一些需要延迟的消息可以使用rabbitMQ的延迟特性

// **********
// 看到这个sdk里是有起一个go，去维护链接的
// **********

// rabbit的channel是用来支持复用TCP链接的，也即是一个TCP链接上可以有多个channel


// rabbit
var rabbitClient = make(map[string]*RabbitTemplate)
var rabbitClientLock =  sync.Mutex{}

// GetRabbitClient 获取客户端模板对象
func GetRabbitClient(node string) (r *RabbitTemplate,err error ) {
	if r,exit := rabbitClient[node]; exit {
		return r,nil
	}
	rabbitClientLock.Lock()
	if r,exit := rabbitClient[node]; exit {
		rabbitClientLock.Unlock()
		return r,nil
	}
	cg := &config.RabbitConfig{}
	err = Config.UnmarshalKey(node,cg)
	if err != nil {
		return nil,errors.New("无法解析rabbitmq配置")
	}
	rabbitClient[node] = NewRabbitClient(func(v interface{}) ([]byte,error) {
		return json.Marshal(v)
	},cg)
	rabbitClientLock.Unlock()
	return rabbitClient[node],nil

}

func NewRabbitClient(encode func(v interface{}) ([]byte,error), config *config.RabbitConfig) *RabbitTemplate {
	return &RabbitTemplate{
		Encode: encode,
		config: config,
	}
}

type RabbitTemplate struct {
	Encode func(v interface{}) ([]byte,error) //消息编码
	config *config.RabbitConfig
	Con *amqp.Connection
	conLock sync.Mutex
}

func (t *RabbitTemplate) CreateDirectQueue(ctx context.Context,exchange string,route string,queue string) error  {
	return t.createQueue(ctx,exchange,route,queue,DIRECT)
}

func (t *RabbitTemplate) createQueue(ctx context.Context,exchange string,route string,queue string,kind string) error  {
	ch,err := t.Channel(ctx)
	if (err!= nil) {
		return err
	}
	err = ch.ExchangeDeclare(exchange,kind,true,false,false,true,nil)
	_,err = ch.QueueDeclare(queue,true,false,false,true,nil)
	err = ch.QueueBind(queue,route,exchange,false,nil)
	ch.Close()
	return err
}

// Send 发送消息
func (t *RabbitTemplate) Send(ctx context.Context,exchange string,router string,msg []byte) error {
	ch,err := t.Channel(ctx)
	if err!= nil {
		return err
	}
	err = ch.Publish(exchange,router,false,false,amqp.Publishing{
		ContentType: "text/plain",
		Body:        msg,
		DeliveryMode: amqp.Persistent,
	})
	ch.Close()
	return err
}

// SendAndCovert 依据自定义的编码方法发送
func (t *RabbitTemplate) SendAndCovert(ctx context.Context,exchange string,router string,msg interface{}) error {
	msgBody,err := t.Encode(msg)
	if err != nil {
		return err
	}
	return t.Send(ctx,exchange,router,msgBody)
}

// DelayQueue 延迟队列
func (t *RabbitTemplate) DelayQueue(ctx context.Context,second int, msg string, exchange string, routingKey string) error {
	ch,err := t.Channel(ctx)
	if (err != nil) {
		return err
	}
	queueName := "delay." + exchange + "." + routingKey + "." + string(second)
	exchangeName := "delay." + exchange
	// 自动创建延迟队列
	err = ch.ExchangeDeclare(exchangeName,DIRECT,true,false,false,true,nil)
	_,err = ch.QueueDeclare(queueName,true,false,false,true,amqp.Table{
		"x-message-ttl":second* 1000, // 延迟的时间
		"x-dead-letter-exchange":exchange, // 到达时间后转发的exchange
		"x-dead-letter-routing-key":routingKey,// 到达时间后转发的exchange的路由键
	})
	err = ch.QueueBind(queueName,queueName,exchangeName,true,nil)
	// 发布延迟消息
	err = ch.Publish(exchangeName,queueName,false,false,amqp.Publishing{
		ContentType: "text/plain",
		Body:        []byte(msg),
		DeliveryMode: amqp.Persistent,
	})
	ch.Close()
	return err
}

func (t *RabbitTemplate) Channel(ctx context.Context) (*amqp.Channel,error) {
	if t.Con != nil && !t.Con.IsClosed() {
		return t.Con.Channel()
	}
	t.conLock.Lock()
	if t.Con != nil && !t.Con.IsClosed(){
		t.conLock.Unlock()
		return t.Con.Channel()
	}
	con,err := t.GetCon()
	if err != nil {
		log.LogOut.Error(ctx,"链接RabbitMQ失败")
		return nil,err
	}
	t.Con = con
	t.conLock.Unlock()
	return t.Con.Channel()
}

func (t *RabbitTemplate) GetCon() (*amqp.Connection,error)  {
	url := "amqp://" + t.config.Username
	url += ":" + t.config.Password
	url += "@" + t.config.Host
	url += ":" +  strconv.Itoa(t.config.Port)
	url += "/"
	vhost := t.config.Virtual
	return amqp.DialConfig(url,amqp.Config{
			Heartbeat:       10 * time.Second,
			Locale:          "en_US",
			ChannelMax: 200,
			Vhost: vhost,
	})
}

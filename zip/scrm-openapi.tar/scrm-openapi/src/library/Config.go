package library

import (
	"errors"
	"fmt"
	"github.com/spf13/viper"
	"os"
	"reflect"
	"scrm-openapi/src/util"
	"sync"
)

var Config ConfigInterface

type ConfigInterface interface {
	// InitConfig 初始化加载配置
	InitConfig(filepath string) error
	AddConfig(filepath string) error
	Get(node string) interface{}
	GetBool(node string) bool
	GetInt(node string) int
	GetString(node string) string
	GetMap(node string) map[string]interface{}
	GetStringSlice(node string) []string
	getNodeStruct(node string,tag string,target interface{}) error
	Unmarshal(param interface{}) error
	UnmarshalKey(node string,param interface{}) error
	// Watch 为以后使用 etcd等留下接口观察节点变化做通知准备
	Watch(node string,callback func(interface{}))

}

type ConfigStruct struct {
	configPath []string
	once sync.Once
}

func (c *ConfigStruct) InitConfig(filepath string) error  {
	viper.SetConfigFile(filepath)
	if err := viper.ReadInConfig(); err != nil {
		return errors.New("load config err"+ err.Error())
	}
	return nil
}

// 保留配置文件地址
func (c *ConfigStruct) addConfigFile(filepaht string)  {
	c.once.Do(func() {
		if c.configPath == nil {
			c.configPath = make([]string, 2)
		}
	})
	c.configPath = append(c.configPath,filepaht)
}

func (c *ConfigStruct) AddConfig(filepath string) error  {
	file,err := os.OpenFile(filepath,os.O_RDONLY,0644)
	if err != nil {
		return errors.New("open config err"+ err.Error())
	}
	// 新配置和当前配置做merge操作
	if err := viper.MergeConfig(file); err != nil {
		return errors.New("load config err"+ err.Error())
	}
	return nil
}

func (c *ConfigStruct) Get(node string) interface{}  {
	return viper.Get(node)
}

func (c *ConfigStruct) GetBool(node string) bool  {
	return viper.GetBool(node)
}

func (c *ConfigStruct) GetInt(node string) int  {
	return viper.GetInt(node)
}

func (c *ConfigStruct) GetString(node string) string  {
	return viper.GetString(node)
}

func (c *ConfigStruct) GetMap(node string) map[string]interface{}  {
	return viper.GetStringMap(node)
}

func (c *ConfigStruct) GetStringSlice(node string) []string  {
	return viper.GetStringSlice(node)
}

func (c *ConfigStruct) Unmarshal(param interface{}) error  {
	if err := viper.Unmarshal(param); err != nil {
		return err
	}
	return nil
}

func (c *ConfigStruct) UnmarshalKey(node string,param interface{}) error  {
	if err := viper.UnmarshalKey(node,param); err != nil {
		return err
	}
	return nil
}

// GetNodeStruct 给配置对象设置值，只支持一级
func (c *ConfigStruct) getNodeStruct(node string,tag string,target interface{}) error {
	if reflect.TypeOf(target).Kind() != reflect.Ptr {
		return errors.New("参数类型必须是指针类型")
	}
	param := c.GetMap(node)
	tarT := reflect.TypeOf(target)
	tarT = tarT.Elem() // 指针类型的转换一次，否则直接FieldByName会报错
	tarV := reflect.ValueOf(target)
	tarV.Elem()
	for i := 0; i < tarT.NumField(); i++ {
		filed :=  tarT.Field(i)
		tagName,ok := filed.Tag.Lookup(tag)
		for k,v := range param {
			if ok && k == tagName {
				fmt.Println(k + " ---------------")
				tarV.Field(i).Elem().Set(reflect.ValueOf(v).Elem().Elem())
				break
			}
			if util.Case2Camel(k) == filed.Name  {
				tarV.Field(i).Set(reflect.ValueOf(v))
				break
			}
		}
	}

	return nil
}

func (c *ConfigStruct) Watch(node string,callback func(interface{})) {

}

package library

import (
	"github.com/go-redis/redis/v8"
	"scrm-openapi/src/config"
	"strconv"
	"sync"
)

var client = make(map[string]*redis.Client)
var lock sync.Mutex
// 最好和spring框架类似，有个模板类，方便替换不同的组件

func BuildClient(redisConnectName string) (*redis.Client,error)  {
	if val,exit := client[redisConnectName]; exit {
		return val,nil
	}
	lock.Lock()
	defer lock.Unlock()
	if val,exit := client[redisConnectName]; exit {
		return val,nil
	}
	// 获取redisConnectName配置
	// 生成信息
	// 设置client
	// 返回链接
	//rdb := redis.NewClient()
	cfg := &config.Redis{}
	if err:=Config.UnmarshalKey(redisConnectName,cfg); err != nil {
		return nil,err
	}
	rdb := redis.NewClient(&redis.Options{
		Addr: cfg.Host + ":" + strconv.Itoa(cfg.Port),
		Password: cfg.Password,
		MinIdleConns: cfg.MaxIdle,
		DB: cfg.Db,
	})
	client[redisConnectName] = rdb
	return rdb,nil
}

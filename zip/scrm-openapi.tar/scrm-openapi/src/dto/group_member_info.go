package dto

type GroupMemberInfo struct {
/**机器人微信id*/
  VcRobotWxId string
/**机器人编号*/
  VcRobotSerialno string
/**群名称*/
  VcChatRoomName string
/**群成员微信id*/
  VcMemberUserWxId string
/**邀请人用户微信id*/
  VcFatherWxId string
/**邀请人用户编号*/
  VcFatherWxUserSerialno string
/**
 * 群成员编号
 */
  VcMemberUserSerialno string
/**
 * 群成员昵称
 */
  VcNickName string
/**
 * 群备注名称
 */
  VcGroupNickName string
/**
 * 群成员头像
 */
  VcHeadImgUrl string
/**
 * 加入时间
 */
 DtJoinTime string
/**
 * 邀请人昵称
 */
  VcInviteNickName string
/**
 * 群编号
 */
  VcChatRoomSerialno string
/**
 * 有效无效
 */
 NStatus int
/**
 * 退群时间
 */
 DtQuitTime string
/**
 * 是否为群主 0 群成员 1 群主 2 群管
 */
 NIsAdmin int
}

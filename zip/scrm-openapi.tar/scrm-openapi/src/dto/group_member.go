package dto

type GroupMemberDataEntity struct {
	NType             int    `json:"nType"`
	VcRobotWxId       string `json:"vcRobotWxId"`
	VcRobotSerialno   string `json:"vcRobotSerialno"`
	VcSerialNo        string `json:"vcSerialNo"`
	NResult           int `json:"nResult"`
	VcResult          string `json:"vcResult"`
	Data              string `json:"data"`
	GroupMemberDetail GroupMemberDetail
}

type GroupMemberDetail struct {
	VcChatRoomId              string `json:"vcChatRoomId"`
	VcChatRoomSerialNo        string `json:"vcChatRoomSerialNo"`
	VcChatRoomName            string `json:"vcChatRoomName"`
	VcBase64ChatRoomName      string `json:"vcBase64ChatRoomName"`
	VcChatAdminWxUserSerialNo string `json:"vcChatAdminWxUserSerialNo"`
	VcChatAdminWxId           string `json:"vcChatAdminWxId"`
	ChatAdminType             int `json:"ChatAdminType"`
	NMemberCount              int    `json:"nMemberCount"`
	Managers []Managers
	IsEnterpriseChatroom bool `json:"IsEnterpriseChatroom"`
	Members []Members
}

type Members struct {
	VcMemberUserSerialNo string `json:"vcMemberUserSerialNo"`
	VcMemberUserWxId string `json:"vcMemberUserWxId"`
	VcNickName string `json:"vcNickName"`
	VcBase64NickName string `json:"vcBase64NickName"`
	VcHeadImgUrl string `json:"vcHeadImgUrl"`
	VcFatherWxId string `json:"vcFatherWxId"`
	VcFatherWxUserSerialNo string `json:"vcFatherWxUserSerialNo"`
	VcGroupNickName string `json:"vcGroupNickName"`
	VcBase64GroupNickName string `json:"vcBase64GroupNickName"`
}

type Managers struct {
	VcManagerWxId string `json:"vcManagerWxId"`
	VcManagerSerialNo string `json:"vcManagerSerialNo"`
}
package dto

type MaterialNotifyDataEntity struct {
	NType           int    `json:"nType"`
	NBusinessType   int    `json:"nBusinessType"`
	NBrandId        int    `json:"nBrandId"`
	NPushType       int    `json:"nPushType"`
	VcRobotSerialNo string `json:"vcRobotSerialNo"`
	VcSerialNo      string `json:"vcSerialNo"`
	NResult         int    `json:"nResult"`
	VcResult        string `json:"vcResult"`
	DTimeStamp      int64  `json:"nTimeStamp"`
	Data            MaterialDataEntity `json:"Data"`
}

type MaterialNotifyDataEntityString struct {
	NType           int    `json:"nType"`
	NBusinessType   int    `json:"nBusinessType"`
	NBrandId        int    `json:"nBrandId"`
	NPushType       int    `json:"nPushType"`
	VcRobotSerialNo string `json:"vcRobotSerialNo"`
	VcSerialNo      string `json:"vcSerialNo"`
	NResult         int    `json:"nResult"`
	VcResult        string `json:"vcResult"`
	DTimeStamp      int64  `json:"nTimeStamp"`
	Data            string  `json:"data"`
}

type MaterialDataEntity struct {
	VcTaskSerialNo     string `json:"vcTaskSerialNo"`
	VcChatRoomSerialNo string `json:"vcChatRoomSerialNo"`
	VcMerchantTaskNo   string `json:"vcMerchantTaskNo"`
	NResult            int    `json:"nResult"`
	VcResult           string `json:"vcResult"`
	NStep              int    `json:"nStep"`
}


type ChatDataEntity struct {
	Code int `json:"code" form:"code"`
    NType int `json:"nType" form:"nType"`
    NBusinessType int `json:"nBusinessType" form:"nBusinessType"`
	NBrandId int `json:"nBrandId" form:"nBrandId"`
	Data string `json:"data" form:"data"`
 	Result string `json:"result" form:"result"`
    Sign string `json:"sign" form:"sign"`
    NTimeStamp int64 `json:"nTimeStamp" form:"nTimeStamp"`
}
package config

type QsConfig struct {
	ApiKey string `yaml:"api_key"`
	BrandInfoUrl string `yaml:"brand_info_url"`
	MemberInfoUrl string `yaml:"m_member_info_url"`
	TokenUrl string `yaml:"token_url"`
	MerchantId string `yaml:"merchant_id"`
}

package config

type MysqlConf struct {
	User            string `yaml:"user"`
	Password        string `yaml:"password"`
	Port            int    `yaml:"port"`
	Chart           string `yaml:"chart"`
	Host            string `yaml:"host"`
	DbName          string `yaml:"db_name"`
	MaxIdleConn     int    `yaml:"max_idle_conn"`
	MaxOpenConn     int    `yaml:"max_open_conn"`
	ConnMaxLifetime int    `yaml:"conn_max_lifetime"`
}

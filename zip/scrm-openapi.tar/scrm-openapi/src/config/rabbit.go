package config

type RabbitConfig struct {
	Host string `yaml:"host"`
	Port int `yaml:"port"`
	Username string `yaml:"username"`
	Password string `yaml:"password"`
	Virtual string `yaml:"virtual"`
}

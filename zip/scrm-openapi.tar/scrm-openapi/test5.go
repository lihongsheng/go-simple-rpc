package main

import (
	"fmt"
)

func main() {
	sli := []int{2,4,6,8,9,12}
	sli2 := []int{4,7,9,14,17,18}
	fmt.Println(Get(sli,sli2,3))
}

func Get(sli1 []int,sli2 []int,k int) int {
	if k < 0 {
		return -1 //表示没有找到或是错误的
	}
	 sli := make([]int,0)
	 len1 := len(sli1)
	 len2 := len(sli2)
	 l1 := 0
	 l2 := 0
	 // 做数组合并
	for l1 < len1 || l2 < len2 {
		if l1 < len1 && sli1[l1] < sli2[l2]  {
			sli = append(sli,sli1[l1])
			l1++
		} else if l2 < len2 {
			sli = append(sli,sli2[l2])
			l2++
		}
	}
	// 如果是目标值做二分查找，如果是数组下标可以直接定位
	fmt.Println(sli)
	return sli[len(sli) - k]
}


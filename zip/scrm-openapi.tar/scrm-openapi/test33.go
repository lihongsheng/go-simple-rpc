package main

import "golang.org/x/tools/go/ssa/interp/testdata/src/fmt"

type Financial struct {
	Year int
	TotalNetAssets float64 //净资产
	GoodPay float64 // 支出
	DonationIncome float64 // 捐赠收入
	TotalIncome float64 // 总收入
}



func main() {

	mapStruct := make(map[int]Financial)
	mapStruct[0] = Financial{Year: 0}
	fmt.Println(mapStruct[0].DonationIncome)
}

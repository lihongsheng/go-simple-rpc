package main

import (
	"fmt"
	"os"
)

type ListNode struct {
	Val  int
	Next *ListNode
}

func main() {


	ll := []string{"0","1","2","3","4"}

	fmt.Println(ll[4:5])


	os.Exit(0)
	l1 := &ListNode{
		Val: 7,
		Next: &ListNode{
			Val: 2,
			Next: &ListNode{
				Val: 4,
				Next: &ListNode{
					Val: 3,
				},
			},
		},
	}
	l2 := &ListNode{
		Val: 5,
		Next: &ListNode{
			Val: 6,
			Next: &ListNode{
				Val: 4,
				Next: &ListNode{
					Val: 4,
				},
			},
		},
	}

	l := addTwoNumbers(l1,l2)
	for l != nil {
		fmt.Println(l.Val)
		l = l.Next

	}
}

/**
 * Definition for singly-linked list.
 * type ListNode struct {
 *     Val int
 *     Next *ListNode
 * }
 */
func addTwoNumbers(l1 *ListNode, l2 *ListNode) *ListNode {
	// 先翻转链表
	if l1 == nil || l2 == nil {
		return nil
	}
	var pre *ListNode
	for l1 != nil {
		tmp := l1.Next
		l1.Next = pre
		pre = l1
		if tmp == nil {
			break
		}
		l1 = tmp

	}
	pre = nil
	for l2 != nil {
		tmp := l2.Next
		l2.Next = pre
		pre = l2
		if tmp == nil {
			break
		}
		l2 = tmp
	}
	// 从个位开始相加，如果是大于10需要，记录当前值往前进一位，因为是十进制两数相加最大也就是18
	var re *ListNode
	var tmp int = 0
	t := 0
	var p *ListNode
	for (l1 != nil || l2 != nil) || tmp!=0  {
		t = 0
		if l1 != nil {
			t = t + l1.Val
		}
		if l2 != nil {
			t = t + l2.Val
		}
		t = t + tmp
		if t >= 10 {
			tmp = 1
			p = &ListNode{
				Val:  t - 10,
				Next: re,
			}
		} else {
			tmp = 0
			p = &ListNode{
				Val:  t,
				Next: re,
			}
		}
		if l1 != nil {
			l1 = l1.Next
		}
		if l2 != nil {
			l2 = l2.Next
		}
		re = p
	}
	return p
}

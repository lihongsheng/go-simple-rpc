package main

import (
	"fmt"
	"time"
)

type Error struct {
	code int
	reason string
}

func (e Error) Error() string  {
	return fmt.Sprintf("%v: %v",e.code,e.reason)
}
func ops() error  {
	var err *Error
	return err

}

type User struct {
	name string
	agr int
}

func (u *User) String() string  {
	return fmt.Sprintf("name :%v, age: %v",u.name,u.agr)
}
func pase_student() map[string]*User {
	m := make(map[string]*User)
	users := []User{
		{name: "1",agr: 1},
		{name: "2",agr: 2},
		{name: "3",agr: 3},
	}
	for _,u := range users {
		m[u.name] = &u
	}
	return m
}
func main() {
	//users := pase_student()
	//for _, u := range users {
	//	go func() {
	//		fmt.Println(u)
	//	}()
	//}
	//time.Sleep(time.Second * 2)
	var a chan int
	fmt.Println(a)

	 go func() {
		 <-a
		 fmt.Println("qqq")
	 }()

	time.Sleep(time.Second*10)
}
package service

import (
	"context"
	"nicetuan_middle_groupon/src/dto/entity"
	"nicetuan_middle_groupon/src/model"
)

type GrouponMerchandise struct {
	Service
	GrouponMerchandiseDao *model.GrouponMerchandiseDao
	GrouponMerchandiseSiteDao *model.GrouponMerchandiseSiteDao
	GrouponMerchtypeDao *model.GrouponMerchtypeDao
}

func NewGrouponMerchandise(ctx context.Context) *GrouponMerchandise {
	g := &GrouponMerchandise{
		GrouponMerchandiseDao: model.NewGrouponMerchandiseDao(ctx),
		Service: Service{
			Context: ctx,
		},
	}
	g.WithContext(ctx)
	return g
}

func (g *GrouponMerchandise) GetGrouponMerchandiseSiteDao() *model.GrouponMerchandiseSiteDao {
	if g.GrouponMerchandiseSiteDao == nil {
		g.GrouponMerchandiseSiteDao = model.NewGrouponMerchandiseSiteDao(g.Context)
	}
	return g.GrouponMerchandiseSiteDao
}

func (g *GrouponMerchandise) GetGrouponMerchtypeDao() *model.GrouponMerchtypeDao {
	if g.GrouponMerchtypeDao == nil {
		g.GrouponMerchtypeDao = model.NewGrouponMerchtypeDao(g.Context)
	}
	return g.GrouponMerchtypeDao
}

func (g *GrouponMerchandise) WithContext(ctx context.Context) {
	g.Service.WithContext(ctx)
	g.GrouponMerchandiseDao = model.NewGrouponMerchandiseDao(ctx)
}

func (g GrouponMerchandise) GrouponRobotMerchandise(grouponIds []int) ([]entity.GrouponMerchandise,error)  {
	return g.GrouponMerchandiseDao.GetMerchandiseInfo(grouponIds)
}

// GetMerchandiseMerchtype 获取团商品下规格和规格站点信息
func (g GrouponMerchandise) GetMerchandiseMerchtype(grouponId int,grouponMerchandiseId []int, returnSite bool) (merchtypeList []entity.GrouponMerchtype,siteList []model.GrouponMerchandiseSite,err error)  {
	merchtypeList,err = g.GetGrouponMerchtypeDao().GetListByGrouponMerchandiseId(grouponMerchandiseId)
	if err != nil {
		return merchtypeList,siteList,err
	}
	merIds := make([]int,0)
	for _,m := range merchtypeList{
		merIds = append(merIds,m.GrouponMerchtypeId)
	}
	if returnSite {
		siteList,err = g.GetGrouponMerchandiseSiteDao().
			GetSiteByGrouponMerchandiseIds(grouponId,grouponMerchandiseId,merIds)
	}

	return merchtypeList,siteList,err
}

package service

import (
	"context"
	"nicetuan_middle_groupon/src/dto/request"
	"nicetuan_middle_groupon/src/model"
)

type Groupon struct {
	Service
	grouponDao *model.GrouponDao
	grouponMerchtypeDao *model.GrouponMerchtypeDao
}

func NewGroupon(ctx context.Context) *Groupon {
	g := &Groupon{
		grouponDao: model.NewGrouponDao(ctx),
		grouponMerchtypeDao: model.NewGrouponMerchtypeDao(ctx),
		Service: Service{
			Context: ctx,
		},
	}
	return g
}

// GetGrouponList 获取结果集
func (g Groupon) GetGrouponList(dto request.GrouponDto) (grouponList []model.Groupon,err error)  {
	cmsDao := g.grouponDao
	clientType := 0
	groupType  := dto.GetGroupType()
	// 秒杀才有分端定价
	if groupType == 1 {
		clientType = 0
	}
	return cmsDao.GrouponList(dto.GetDateStart(),dto.GetDateEnd(),dto.GetCityId(),groupType,clientType,0)
}

package service

import (
	"context"
	"errors"
	"fmt"
	"nicetuan_middle_groupon/src/dto/request"
	"nicetuan_middle_groupon/src/model"
	"time"
)

type LabelService struct {
	Service
	GrouponLabelDao *model.GrouponLabelDao
}

func NewLabelService(ctx context.Context) *LabelService {
	g := &LabelService{
		GrouponLabelDao: model.NewGrouponLabelDao(ctx),
		Service: Service{
			Context: ctx,
		},
	}
	return g
}

// Save 保存数据
func (l LabelService) Save(label request.AddLabel) (err error)  {
	g,err := l.GrouponLabelDao.GetGrouponLabelByLabelId(label.SaleLabelId)
	if err == nil && g.Id != 0 {
		return errors.New(fmt.Sprintf("标签ID(labelInfo[%d])已经存在",label.SaleLabelId))
	}
	grouponLabel := model.GrouponLabel{
		LabelId: label.SaleLabelId,
		LabelName: label.Name,
		SiteId: label.SiteId,
		Status: label.Status,
		CreateTime: int(time.Now().Unix()),
	}
	_, err = l.GrouponLabelDao.Insert(grouponLabel)
	return err
}
// ChangeStatus 改变标签状态
func (l LabelService) ChangeStatus(labelIds []int64, status int) error {
	return l.GrouponLabelDao.ChangeStatus(labelIds,status)
}
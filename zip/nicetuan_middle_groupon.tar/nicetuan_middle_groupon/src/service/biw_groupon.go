package service

type BiwGroupon struct {
	Service
}
//
//func (biw BiwGroupon) BiwGrouponList(dto request.BiwDto) (grouponList []model.Groupon,err error)  {
//	db := model.NewCmsDao(biw.Context).GetDb()
//	var groupon = model.Groupon{}
//	db = db.Table("groupon").Model(groupon)
//	// 这些条件语句是想写在dao里的
//	if dto.GetDate() != "" {
//		db = db.Where("groupon_date = ?",dto.GetDate())
//	}
//	if dto.GetCityId() > 0 {
//		db = db.Where("city_id = ?",dto.GetCityId())
//	}
//	db = db.Where("group_type = ?",dto.GetGroupType())
//
//	err = db.Find(&grouponList).Error
//	return grouponList,err
//}

package service

import "context"

type ServiceInterface interface {
	Init(ctx context.Context)
}

type ServiceContext struct {
	ctx context.Context
	Groupon *Groupon
	GrouponMerchandise *GrouponMerchandise
	labelService *LabelService
}
// Init 这个只是目前我在Init里写这样了，也可以懒加载方式
func (s *ServiceContext) Init(ctx context.Context)  {
	s.ctx = ctx
	s.Groupon = NewGroupon(ctx)
	s.GrouponMerchandise = NewGrouponMerchandise(ctx)
}

// GetGrouponService 懒加载方式,需要的时候才创建
// 由于ServiceContext，是在每个请求的go里，且依据变量方式注入到 controller的action里，所以这里不会出现
// ServiceContext.Groupon 在另外一个请求的go里被改变的情况
func (s *ServiceContext) GetGrouponService() *Groupon  {
	if s.Groupon == nil {
		s.Groupon = NewGroupon(s.ctx)
	}
	return s.Groupon
}

func (s *ServiceContext) GetGrouponMerchandiseService() *GrouponMerchandise  {
	if s.GrouponMerchandise == nil {
		s.GrouponMerchandise = NewGrouponMerchandise(s.ctx)
	}
	return s.GrouponMerchandise
}

func (s *ServiceContext) GetLabelService() *LabelService {
	if s.labelService == nil {
		s.labelService = NewLabelService(s.ctx)
	}
	return s.labelService
}



package service

import (
	"context"
)

type Service struct {
	Context context.Context
}

func (s *Service) WithContext(ctx context.Context) {
	s.Context = ctx
}

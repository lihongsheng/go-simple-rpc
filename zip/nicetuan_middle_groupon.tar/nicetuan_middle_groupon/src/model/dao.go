package model

import (
	"context"
	"gorm.io/gorm"
)

type DaoConnect interface {
	GetConnect() string
	GetTable() string
}

type Dao struct {
	ctx context.Context
	db *gorm.DB
	connect string
}

func (d Dao) GetDb() *gorm.DB {
	return d.db
}

func (d Dao) GetConnect() string {
	return d.connect
}

func (d *Dao) WithContext(ctx context.Context) {
	d.db = d.db.WithContext(ctx)
	 d.ctx = ctx
}


package model

import (
	"context"
	_ "nicetuan_middle_groupon/src/types"
)

type MerchtypeDao struct {
	table string
	Dao
}

func NewMerchtypeDao(ctx context.Context) *MerchtypeDao {
	db := GetConnect("cms")
	db = db.WithContext(ctx)
	return &MerchtypeDao{
		table: "merchtype",
		Dao: Dao{
			connect: "cms",
			db: db,
		},
	}
}

type Merchtype struct {
    Merchtypeid int `gorm:"type:int(10);column:merchtypeid;primaryKey;autoIncrement;comment:" json:"merchtypeid,string"` 
    MerchtypeName string `gorm:"type:varchar(255);column:merchtype_name;comment:" json:"merchtype_name,string"` 
    Price int64 `gorm:"type:bigint(11);column:price;comment:" json:"price,string"` 
    Quantity int `gorm:"type:int(11);column:quantity;comment:" json:"quantity,string"` 
    Content string `gorm:"type:varchar(512);column:content;comment:" json:"content,string"` 
    MerchAttrids string `gorm:"type:varchar(100);column:merch_attrids;comment:" json:"merch_attrids,string"` 
    Merchandiseid int `gorm:"type:int(10);column:merchandiseid;comment:" json:"merchandiseid,string"` 
    Valid int `gorm:"type:tinyint(3);column:valid;comment:" json:"valid,string"` 
    Supplyprice int64 `gorm:"type:bigint(11);column:supplyprice;comment:" json:"supplyprice,string"` 
    Repositoryfee int `gorm:"type:int(11);column:repositoryfee;comment:" json:"repositoryfee,string"` 
    Sellunits string `gorm:"type:varchar(10);column:sellunits;comment:" json:"sellunits,string"` 
    Size int `gorm:"type:tinyint(3);column:size;comment:" json:"size,string"` 
    Rank int `gorm:"type:tinyint(6);column:rank;comment:" json:"rank,string"` 
    Preselltype int `gorm:"type:tinyint(6);column:preselltype;comment:" json:"preselltype,string"` 
    Brokerage float64 `gorm:"type:decimal(5,2);column:brokerage;comment:" json:"brokerage,string"` 
    UpdateDateline int `gorm:"type:int(10);column:update_dateline;comment:" json:"update_dateline,string"` 
    Deleted int `gorm:"type:tinyint(1);column:deleted;comment:" json:"deleted,string"` 
    DefaultMerchtype int `gorm:"type:tinyint(1);column:default_merchtype;comment:" json:"default_merchtype,string"` 
    StorageType int `gorm:"type:tinyint(4);column:storage_type;comment:" json:"storage_type,string"` 

}

func (d *MerchtypeDao) GetMerchtype(id int) (merchtype Merchtype, err error)  {
	if err := d.db.Table(d.table).Model(Merchtype{}).Where("merchtypeid = ?", id).Find(&merchtype).Error; err != nil {
		return Merchtype{},err
	}
	return merchtype,nil
}

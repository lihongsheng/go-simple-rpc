package model

import (
	"context"
	_ "nicetuan_middle_groupon/src/types"
)

type SpecialactivityDao struct {
	table string
	Dao
}

func NewSpecialactivityDao(ctx context.Context) *SpecialactivityDao {
	db := GetConnect("cms")
	db = db.WithContext(ctx)
	return &SpecialactivityDao{
		table: "specialactivity",
		Dao: Dao{
			connect: "cms",
			db: db,
		},
	}
}

type Specialactivity struct {
    SpecialId int64 `gorm:"type:bigint(20);column:special_id;primaryKey;autoIncrement;comment:" json:"special_id,string"` 
    Title string `gorm:"type:varchar(30);column:title;comment:" json:"title,string"` 
    WarehousesiteId int `gorm:"type:int(11);column:warehousesite_id;comment:" json:"warehousesite_id,string"` 
    Image1 string `gorm:"type:varchar(255);column:image1;comment:" json:"image1,string"` 
    Image2 string `gorm:"type:varchar(255);column:image2;comment:" json:"image2,string"` 
    Image3 string `gorm:"type:varchar(255);column:image3;comment:" json:"image3,string"` 
    StartTime int `gorm:"type:int(11);column:start_time;comment:" json:"start_time,string"` 
    EndTime int `gorm:"type:int(11);column:end_time;comment:" json:"end_time,string"` 
    StopYn int `gorm:"type:tinyint(1);column:stop_yn;comment:" json:"stop_yn,string"` 
    Dateline int `gorm:"type:int(11);column:dateline;comment:" json:"dateline,string"` 
    UpdateDateline int `gorm:"type:int(10);column:update_dateline;comment:" json:"update_dateline,string"` 
    TitleAbbreviation string `gorm:"type:varchar(30);column:title_abbreviation;comment:" json:"title_abbreviation,string"` 
    TitleAssistant string `gorm:"type:varchar(30);column:title_assistant;comment:" json:"title_assistant,string"` 
    ShareContent string `gorm:"type:varchar(25);column:share_content;comment:" json:"share_content,string"` 
    Image4 string `gorm:"type:varchar(255);column:image4;comment:" json:"image4,string"` 
    IsBatchPlace int `gorm:"type:tinyint(1);column:is_batch_place;comment:" json:"is_batch_place,string"` 

}

func (d *SpecialactivityDao) GetSpecialactivity(id int) (specialactivity Specialactivity, err error)  {
	if err := d.db.Table(d.table).Model(Specialactivity{}).Where("special_id = ?", id).Find(&specialactivity).Error; err != nil {
		return Specialactivity{},err
	}
	return specialactivity,nil
}

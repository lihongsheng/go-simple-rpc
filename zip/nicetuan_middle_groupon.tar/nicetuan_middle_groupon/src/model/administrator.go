package model

import (
	"context"
	_ "nicetuan_middle_groupon/src/types"
)

type AdministratorDao struct {
	table string
	Dao
}

func NewAdministratorDao(ctx context.Context) *AdministratorDao {
	db := GetConnect("cms")
	db = db.WithContext(ctx)
	return &AdministratorDao{
		table: "administrator",
		Dao: Dao{
			connect: "cms",
			db: db,
		},
	}
}

type Administrator struct {
    Userid int `gorm:"type:int(11);column:userid;primaryKey;autoIncrement;comment:" json:"userid,string"` 
    Uuid int `gorm:"type:int(11);column:uuid;comment:" json:"uuid,string"` 
    Parentid int `gorm:"type:int(11);column:parentid;comment:" json:"parentid,string"` 
    Cashiercode int `gorm:"type:smallint(5);column:cashiercode;comment:" json:"cashiercode,string"` 
    Usergroupid int `gorm:"type:int(10);column:usergroupid;comment:" json:"usergroupid,string"` 
    ExtUsergroupid string `gorm:"type:varchar(255);column:ext_usergroupid;comment:" json:"ext_usergroupid,string"` 
    Username string `gorm:"type:varchar(32);column:username;comment:" json:"username,string"` 
    Realname string `gorm:"type:varchar(64);column:realname;comment:" json:"realname,string"` 
    Email string `gorm:"type:varchar(64);column:email;comment:" json:"email,string"` 
    Password string `gorm:"type:varchar(128);column:password;comment:" json:"password,string"` 
    Salt string `gorm:"type:char(6);column:salt;comment:" json:"salt,string"` 
    Telephone string `gorm:"type:varchar(255);column:telephone;comment:" json:"telephone,string"` 
    Lastip string `gorm:"type:varchar(39);column:lastip;comment:" json:"lastip,string"` 
    Lastrealip string `gorm:"type:varchar(39);column:lastrealip;comment:" json:"lastrealip,string"` 
    Lastactivity int `gorm:"type:int(10);column:lastactivity;comment:" json:"lastactivity,string"` 
    Deleted int `gorm:"type:tinyint(1);column:deleted;comment:" json:"deleted,string"` 
    Dateline int `gorm:"type:int(11);column:dateline;comment:" json:"dateline,string"` 
    Truename string `gorm:"type:varchar(20);column:truename;comment:" json:"truename,string"` 
    Job string `gorm:"type:varchar(20);column:job;comment:" json:"job,string"` 
    Openid string `gorm:"type:varchar(28);column:openid;comment:" json:"openid,string"` 
    CityIds string `gorm:"type:varchar(150);column:city_ids;comment:" json:"city_ids,string"` 
    SubsiteIds string `gorm:"type:varchar(255);column:subsite_ids;comment:" json:"subsite_ids,string"` 

}

func (d *AdministratorDao) GetAdministrator(id int) (administrator Administrator, err error)  {
	if err := d.db.Table(d.table).Model(Administrator{}).Where("userid = ?", id).Find(&administrator).Error; err != nil {
		return Administrator{},err
	}
	return administrator,nil
}

package model

import (
	"context"
	"nicetuan_middle_groupon/src/types"
	"nicetuan_middle_groupon/src/util"
)

type GrouponDao struct {
	table string
	Dao
}

func NewGrouponDao(ctx context.Context) *GrouponDao {
	db := GetConnect("cms")
	db = db.WithContext(ctx)
	return &GrouponDao{
		table: "groupon",
		Dao: Dao{
			connect: "cms",
			db: db,
		},
	}
}

type Groupon struct {
    GrouponId int `gorm:"type:int(11);column:groupon_id;primaryKey;autoIncrement;comment:" json:"groupon_id,string"` 
    GrouponTitle string `gorm:"type:varchar(60);column:groupon_title;comment:" json:"groupon_title,string"` 
    CityId int `gorm:"type:mediumint(8);column:city_id;comment:" json:"city_id,string"`
    GrouponDate types.LocalDate `gorm:"type:date;column:groupon_date;comment:" json:"groupon_date,string"`
    StartTime int `gorm:"type:int(11);column:start_time;comment:" json:"start_time,string"` 
    EndTime int `gorm:"type:int(11);column:end_time;comment:" json:"end_time,string"` 
    ArriveTime int `gorm:"type:int(11);column:arrive_time;comment:" json:"arrive_time,string"` 
    Dateline int `gorm:"type:int(11);column:dateline;comment:" json:"dateline,string"` 
    CityName string `gorm:"type:varchar(60);column:city_name;comment:" json:"city_name,string"` 
    OpenType int `gorm:"type:tinyint(1);column:open_type;comment:" json:"open_type,string"` 
    IsStop int `gorm:"type:tinyint(1);column:is_stop;comment:" json:"is_stop,string"` 
    GroupType int `gorm:"type:tinyint(1);column:group_type;comment:" json:"group_type,string"` 
    Pushstatus int `gorm:"type:tinyint(1);column:pushstatus;comment:" json:"pushstatus,string"` 
    UpdateDateline int `gorm:"type:int(10);column:update_dateline;comment:" json:"update_dateline,string"` 
    Shareimage string `gorm:"type:varchar(256);column:shareimage;comment:" json:"shareimage,string"` 
    IsAppointPartner int `gorm:"type:tinyint(1);column:is_appoint_partner;comment:" json:"is_appoint_partner,string"` 
    BlockId int64 `gorm:"type:bigint(20);column:block_id;comment:" json:"block_id,string"` 
    ClientType int `gorm:"type:smallint(6);column:client_type;comment:" json:"client_type,string"` 
    PlatformType int `gorm:"type:tinyint(1);column:platform_type;comment:" json:"platform_type,string"` 
    GrouponLinkId int64 `gorm:"type:bigint(20);column:groupon_link_id;comment:" json:"groupon_link_id,string"` 

}
// GetGroupon 获取团购信息
func (d *GrouponDao) GetGroupon(id int) (groupon Groupon, err error)  {
	if err := d.db.Table(d.table).Model(Groupon{}).Where("groupon_id = ?", id).Find(&groupon).Error; err != nil {
		return groupon,err
	}
	return groupon,nil
}
// GrouponList 获取有效且未结束的团购列表
func (d *GrouponDao) GrouponList(dateStart string,dateEnd string,cityId int,groupType int,clinetType int,endTime int) (grouponList []Groupon,err error)  {
	db := d.db.Table("groupon").Model(Groupon{})
	if dateStart != "" {
		db.Where("groupon_date >= ?",dateStart)
	}
	if dateEnd != "" {
		db.Where("groupon_date <= ?",dateEnd)
	}
	if cityId > 0 {
		db.Where("city_id = ?",cityId)
	}
	db.Where("group_type = ?",groupType).
		Where("client_type = ?",clinetType).
		Where("is_stop = 0")
	if endTime <= 0 {
		db.Where("end_time >= ?",util.TimeUnix())
	}
	err = db.Find(&grouponList).Error
	return grouponList,err
}

func (d *GrouponDao) GetGrouponList(dateStart string,dateEnd string) (groupon Groupon, err error)  {
	err = d.db.Model(Groupon{}).Where("groupon_date >= ?",dateStart).Where("groupon_date <= ?",dateStart).Find(&groupon).Error
	if err != nil {
		return groupon,err
	}
	return groupon,nil
}

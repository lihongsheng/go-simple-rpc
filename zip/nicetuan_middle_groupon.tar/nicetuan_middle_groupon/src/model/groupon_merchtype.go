package model

import (
	"context"
	"nicetuan_middle_groupon/src/dto/entity"
)

type GrouponMerchtypeDao struct {
	table string
	Dao
}

func NewGrouponMerchtypeDao(ctx context.Context) *GrouponMerchtypeDao {
	db := GetConnect("cms")
	db = db.WithContext(ctx)
	return &GrouponMerchtypeDao{
		table: "groupon_merchtype",
		Dao: Dao{
			connect: "cms",
			db: db,
		},
	}
}

type GrouponMerchtype struct {
    GrouponMerchtypeId int `gorm:"type:int(11);column:groupon_merchtype_id;primaryKey;autoIncrement;comment:" json:"groupon_merchtype_id,string"` 
    GrouponMerchandiseId int `gorm:"type:int(11);column:groupon_merchandise_id;comment:" json:"groupon_merchandise_id,string"` 
    GrouponId int `gorm:"type:int(11);column:groupon_id;comment:" json:"groupon_id,string"` 
    MerchtypeId int `gorm:"type:int(11);column:merchtype_id;comment:" json:"merchtype_id,string"` 
    Price int `gorm:"type:int(11);column:price;comment:" json:"price,string"` 
    Brokerage float64 `gorm:"type:decimal(5,2);column:brokerage;comment:" json:"brokerage,string"` 
    Quantity int `gorm:"type:int(11);column:quantity;comment:" json:"quantity,string"` 
    MaxQuantity int `gorm:"type:int(11);column:max_quantity;comment:" json:"max_quantity,string"` 
    LimitQuantity int `gorm:"type:int(11);column:limit_quantity;comment:" json:"limit_quantity,string"` 
    Soldout int `gorm:"type:tinyint(1);column:soldout;comment:" json:"soldout,string"` 
    Dateline int `gorm:"type:int(11);column:dateline;comment:" json:"dateline,string"` 
    UpdateDateline int `gorm:"type:int(11);column:update_dateline;comment:" json:"update_dateline,string"` 
    MerchandiseId int `gorm:"type:int(11);column:merchandise_id;comment:" json:"merchandise_id,string"` 
    SupplierPrice int `gorm:"type:int(11);column:supplier_price;comment:" json:"supplier_price,string"` 
    SupplierId int `gorm:"type:int(11);column:supplier_id;comment:" json:"supplier_id,string"` 

}

func (d *GrouponMerchtypeDao) GetGrouponMerchtype(id int) (grouponMerchtype GrouponMerchtype, err error)  {
	if err := d.db.Table(d.table).Model(GrouponMerchtype{}).Where("groupon_merchtype_id = ?", id).Find(&grouponMerchtype).Error; err != nil {
		return GrouponMerchtype{},err
	}
	return grouponMerchtype,nil
}

// GetGrouponMerchtypeList 获取商品下
func (d *GrouponMerchtypeDao) GetGrouponMerchtypeList(merchandiseId int) (grouponMerchtypeList []GrouponMerchtype,err error)  {
	err = d.db.Table("groupon_merchtype as gm").Select("gm.merchtype_id,gm.groupon_merchtype_id, m.merchtype_name").
		Joins("inner join merchtype as m on m.merchtypeid = gm.merchtype_id where gm.groupon_merchandise_id = ?",merchandiseId).
		Find(&grouponMerchtypeList).Error
	return grouponMerchtypeList,err
}

func (d *GrouponMerchtypeDao) GetListByGrouponMerchandiseId(grouponMerchandiseId []int) (grouponMerchtypeList []entity.GrouponMerchtype,err error)  {
	err = d.db.Table("groupon_merchtype as gm").Select("gm.*, m.merchtype_name").
		Joins("inner join merchtype as m on m.merchtypeid = gm.merchtype_id where gm.groupon_merchandise_id IN ?",grouponMerchandiseId).
		Find(&grouponMerchtypeList).Error
	return grouponMerchtypeList,err
}


package model

import (
	"context"
	"nicetuan_middle_groupon/src/dto/entity"
)

type GrouponMerchandiseDao struct {
	table string
	Dao
}

func NewGrouponMerchandiseDao(ctx context.Context) *GrouponMerchandiseDao {
	db := GetConnect("cms")
	db = db.WithContext(ctx)
	return &GrouponMerchandiseDao{
		table: "groupon_merchandise",
		Dao: Dao{
			connect: "cms",
			db: db,
		},
	}
}

type GrouponMerchandise struct {
    GrouponMerchandiseId int `gorm:"type:int(11);not null;comment:" json:"groupon_merchandise_id"` 
	GrouponId int `gorm:"type:int(11);not null;comment:" json:"groupon_id"`
	MerchandiseId int `gorm:"type:int(11);not null;comment:" json:"merchandise_id"`
	ActivityId int `gorm:"type:int(10);not null;comment:" json:"activity_id"`
	ActivityPrice int `gorm:"type:int(10) unsigned;not null;comment:" json:"activity_price"`
	Quantity int `gorm:"type:int(10);not null;comment:" json:"quantity"`
	MaxQuantity int `gorm:"type:int(10);not null;comment:" json:"max_quantity"`
	LimitQuantity int `gorm:"type:int(3) unsigned;not null;comment:" json:"limit_quantity"`
	Rank int `gorm:"type:int(10);not null;comment:" json:"rank"`
	Soldout int `gorm:"type:tinyint(1) unsigned;not null;comment:" json:"soldout"`
	Deleted int `gorm:"type:tinyint(4);not null;comment:" json:"deleted"`
	Dateline int `gorm:"type:int(11);not null;comment:" json:"dateline"`
	Description string `gorm:"type:varchar(50);not null;comment:" json:"description"`
	Deliveryday string `gorm:"type:date;not null;comment:" json:"deliveryday"`
	IsSpecial int `gorm:"type:tinyint(1);not null;comment:" json:"is_special"`
	UnUseCoupon int `gorm:"type:tinyint(1);not null;comment:" json:"un_use_coupon"`
	UpdateDateline int `gorm:"type:int(10);not null;comment:" json:"update_dateline"`
	SupplierId int `gorm:"type:int(10);not null;comment:" json:"supplier_id"`
	TagId int `gorm:"type:int(10);not null;comment:" json:"tag_id"`
	ProduceDay string `gorm:"type:varchar(15);not null;comment:" json:"produce_day"`
	IsHotSale int `gorm:"type:tinyint(1);not null;comment:" json:"is_hot_sale"`
	GrouponMerchandiseImg string `gorm:"type:varchar(256);not null;comment:" json:"groupon_merchandise_img"`
	IsSupcon int `gorm:"type:int(10) unsigned;not null;comment:" json:"is_supcon"`
	IsDirectPartner int `gorm:"type:tinyint(1) unsigned;not null;comment:" json:"is_direct_partner"`
	SaleCount int64 `gorm:"type:bigint(25);not null;comment:" json:"sale_count"`
	HotSaleTime int `gorm:"type:int(11);not null;comment:" json:"hot_sale_time"`
	SurplusQuantity int `gorm:"type:int(10);not null;comment:" json:"surplus_quantity"`
	SpecialEnter int `gorm:"type:tinyint(1);not null;comment:" json:"special_enter"`
	RealRank int `gorm:"type:int(11) unsigned;not null;comment:" json:"real_rank"`
	IsCenterPurchase int `gorm:"type:tinyint(1) unsigned;not null;comment:" json:"is_center_purchase"`
	StorageType int `gorm:"type:tinyint(4);not null;comment:" json:"storage_type"`
}


func (d *GrouponMerchandiseDao) GetGrouponMerchandise(id int) (grouponMerchandise GrouponMerchandise, err error)  {
	if err := d.db.Table("groupon_merchandise").Model(GrouponMerchandise{}).Where("groupon_merchandise_id = ?", id).Find(&grouponMerchandise).Error; err != nil {
		return GrouponMerchandise{},err
	}
	return grouponMerchandise,nil
}

// GetMerchandiseInfo
func (d *GrouponMerchandiseDao) GetMerchandiseInfo(grouponId []int) ( merchandise []entity.GrouponMerchandise, err error)  {
	if err := d.db.Table("groupon_merchandise as gm").Select("gm.groupon_merchandise_id,gm.merchandise_id,gm.groupon_id, m.title, m.coverimage, m.onsale, m.mtype, m.merchandise_mode_type").
		Joins("inner join merchandise as m on m.merchandiseid = gm.merchandise_id where gm.groupon_id IN ?",grouponId).Find(&merchandise).Error; err != nil {
		return merchandise,err
	}
	return merchandise,nil
}

package model

import (
	"context"
	
)

type GrouponMerchandiseSiteDao struct {
	table string
	Dao
}

func NewGrouponMerchandiseSiteDao(ctx context.Context) *GrouponMerchandiseSiteDao {
	db := GetConnect("cms")
	db = db.WithContext(ctx)
	return &GrouponMerchandiseSiteDao{
		table: "groupon_merchandise_site",
		Dao: Dao{
			connect: "cms",
			db: db,
		},
	}
}

type GrouponMerchandiseSite struct {
    GrouponMerchandiseSiteId int64 `gorm:"type:bigint(20);column:groupon_merchandise_site_id;primaryKey;autoIncrement;comment:" json:"groupon_merchandise_site_id,string"` 
    GrouponMerchandiseId int64 `gorm:"type:bigint(20);column:groupon_merchandise_id;comment:" json:"groupon_merchandise_id,string"` 
    SiteId int64 `gorm:"type:bigint(20);column:site_id;comment:" json:"site_id,string"` 
    GrouponId int64 `gorm:"type:bigint(20);column:groupon_id;comment:" json:"groupon_id,string"` 
    UpdateDateline int `gorm:"type:int(10);column:update_dateline;comment:" json:"update_dateline,string"` 
    GrouponMerchtypeId int `gorm:"type:int(10);column:groupon_merchtype_id;comment:" json:"groupon_merchtype_id,string"` 
    Dateline int `gorm:"type:int(10);column:dateline;comment:" json:"dateline,string"` 
    Price int `gorm:"type:int(10);column:price;comment:" json:"price,string"` 
    Rank int `gorm:"type:int(10);column:rank;comment:" json:"rank,string"` 
    Brokerage float64 `gorm:"type:decimal(5,2);column:brokerage;comment:" json:"brokerage,string"` 
    Status int `gorm:"type:tinyint(1);column:status;comment:" json:"status,string"` 
    YnSyncPrice int `gorm:"type:tinyint(1);column:yn_sync_price;comment:" json:"yn_sync_price,string"` 
    MerchandiseId int `gorm:"type:int(10);column:merchandise_id;comment:" json:"merchandise_id,string"` 
    MerchtypeId int `gorm:"type:int(10);column:merchtype_id;comment:" json:"merchtype_id,string"` 
    RecommendYn int `gorm:"type:int(10);column:recommend_yn;comment:" json:"recommend_yn,string"` 

}

func (d *GrouponMerchandiseSiteDao) GetGrouponMerchandiseSite(id int) (grouponMerchandiseSite GrouponMerchandiseSite, err error)  {
	if err := d.db.Table(d.table).Model(GrouponMerchandiseSite{}).Where("groupon_merchandise_site_id = ?", id).Find(&grouponMerchandiseSite).Error; err != nil {
		return grouponMerchandiseSite,err
	}
	return grouponMerchandiseSite,nil
}

func (d *GrouponMerchandiseSiteDao) GetSiteByGrouponMerchandiseIds(grouponId int,grouponMetchandiseIds []int,grouponMerchtypeIds []int) (grouponMerchandiseSite []GrouponMerchandiseSite, err error)  {
	if err := d.db.Table(d.table).Model(GrouponMerchandiseSite{}).
		Where("groupon_id = ?", grouponId).
		Where("groupon_merchandise_id IN ?",grouponMetchandiseIds).
		Where("groupon_merchtype_id IN ?",grouponMerchtypeIds).
		Find(&grouponMerchandiseSite).Error; err != nil {
		return grouponMerchandiseSite,err
	}
	return grouponMerchandiseSite,nil
}

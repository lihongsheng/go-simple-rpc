package model

import (
	"context"
	"nicetuan_middle_groupon/src/types"
)

type MerchandiseDao struct {
	table string
	Dao
}

func NewMerchandiseDao(ctx context.Context) *MerchandiseDao {
	db := GetConnect("cms")
	db = db.WithContext(ctx)
	return &MerchandiseDao{
		table: "merchandise",
		Dao: Dao{
			connect: "cms",
			db: db,
		},
	}
}

type Merchandise struct {
    Merchandiseid int `gorm:"type:int(10);column:merchandiseid;primaryKey;autoIncrement;comment:" json:"merchandiseid,string"` 
    Title string `gorm:"type:varchar(128);column:title;comment:" json:"title,string"` 
    Content string `gorm:"type:varchar(100);column:content;comment:" json:"content,string"` 
    Deliveryid int `gorm:"type:tinyint(3);column:deliveryid;comment:" json:"deliveryid,string"` 
    Deliverydetail string `gorm:"type:varchar(512);column:deliverydetail;comment:" json:"deliverydetail,string"` 
    Projecteddeliverytime string `gorm:"type:varchar(64);column:projecteddeliverytime;comment:" json:"projecteddeliverytime,string"` 
    Onsale int `gorm:"type:tinyint(3);column:onsale;comment:" json:"onsale,string"` 
    Recommended int `gorm:"type:tinyint(3);column:recommended;comment:" json:"recommended,string"` 
    Coverimage string `gorm:"type:varchar(256);column:coverimage;comment:" json:"coverimage,string"` 
    Covervideo string `gorm:"type:varchar(256);column:covervideo;comment:" json:"covervideo,string"` 
    Squarecoverimage string `gorm:"type:varchar(256);column:squarecoverimage;comment:" json:"squarecoverimage,string"` 
    HotCoverImage string `gorm:"type:varchar(256);column:hot_cover_image;comment:" json:"hot_cover_image,string"` 
    HotCoverVideo string `gorm:"type:varchar(256);column:hot_cover_video;comment:" json:"hot_cover_video,string"` 
    Deleted int `gorm:"type:tinyint(4);column:deleted;comment:" json:"deleted,string"` 
    Userid int `gorm:"type:int(10);column:userid;comment:" json:"userid,string"` 
    Dateline int `gorm:"type:int(11);column:dateline;comment:" json:"dateline,string"` 
    Abbreviation string `gorm:"type:varchar(60);column:abbreviation;comment:" json:"abbreviation,string"` 
    Rank int `gorm:"type:int(10);column:rank;comment:" json:"rank,string"` 
    OriginPrice int `gorm:"type:int(10);column:origin_price;comment:" json:"origin_price,string"` 
    Unit string `gorm:"type:varchar(20);column:unit;comment:" json:"unit,string"` 
    Brokerage float64 `gorm:"type:decimal(5,2);column:brokerage;comment:" json:"brokerage,string"` 
    Manualsetbuyertotal int `gorm:"type:int(11);column:manualsetbuyertotal;comment:" json:"manualsetbuyertotal,string"` 
    Salecount int `gorm:"type:int(11);column:salecount;comment:" json:"salecount,string"` 
    Shareicon string `gorm:"type:varchar(255);column:shareicon;comment:" json:"shareicon,string"` 
    Shareorderimage string `gorm:"type:varchar(255);column:shareorderimage;comment:" json:"shareorderimage,string"` 
    Classid int `gorm:"type:int(10);column:classid;comment:" json:"classid,string"` 
    Expressfee string `gorm:"type:varchar(500);column:expressfee;comment:" json:"expressfee,string"` 
    Expresscompany string `gorm:"type:varchar(500);column:expresscompany;comment:" json:"expresscompany,string"` 
    Expresspath string `gorm:"type:text;column:expresspath;comment:" json:"expresspath,string"` 
    Limiteddistrict string `gorm:"type:text;column:limiteddistrict;comment:" json:"limiteddistrict,string"` 
    Tagid string `gorm:"type:varchar(255);column:tagid;comment:" json:"tagid,string"` 
    Presell int `gorm:"type:tinyint(3);column:presell;comment:" json:"presell,string"` 
    Preselldeliverytime types.LocalDate `gorm:"type:date;column:preselldeliverytime;comment:" json:"preselldeliverytime,string"` 
    Growarea string `gorm:"type:varchar(20);column:growarea;comment:" json:"growarea,string"` 
    Despatchpath string `gorm:"type:varchar(32);column:despatchpath;comment:" json:"despatchpath,string"` 
    Description string `gorm:"type:text;column:description;comment:" json:"description,string"` 
    Images string `gorm:"type:text;column:images;comment:" json:"images,string"` 
    Carousels string `gorm:"type:text;column:carousels;comment:" json:"carousels,string"` 
    Despatchtype string `gorm:"type:varchar(255);column:despatchtype;comment:" json:"despatchtype,string"` 
    Saleitem int `gorm:"type:int(10);column:saleitem;comment:" json:"saleitem,string"` 
    Recommendlayoutid int `gorm:"type:int(10);column:recommendlayoutid;comment:" json:"recommendlayoutid,string"` 
    Supplychaintype int `gorm:"type:int(10);column:supplychaintype;comment:" json:"supplychaintype,string"` 
    Mtype int `gorm:"type:smallint(5);column:mtype;comment:" json:"mtype,string"` 
    Soldout int `gorm:"type:tinyint(4);column:soldout;comment:" json:"soldout,string"` 
    Smstmp string `gorm:"type:varchar(360);column:smstmp;comment:" json:"smstmp,string"` 
    Mergedelivery int `gorm:"type:tinyint(4);column:mergedelivery;comment:" json:"mergedelivery,string"` 
    Freetaxfee int `gorm:"type:tinyint(2);column:freetaxfee;comment:" json:"freetaxfee,string"` 
    CityId int `gorm:"type:mediumint(8);column:city_id;comment:" json:"city_id,string"` 
    SubsiteId int `gorm:"type:mediumint(8);column:subsite_id;comment:" json:"subsite_id,string"` 
    IsNetwork int `gorm:"type:tinyint(1);column:is_network;comment:" json:"is_network,string"` 
    Supplierid int `gorm:"type:int(10);column:supplierid;comment:" json:"supplierid,string"` 
    BigCoverimage string `gorm:"type:varchar(256);column:big_coverimage;comment:" json:"big_coverimage,string"` 
    UpdateDateline int `gorm:"type:int(10);column:update_dateline;comment:" json:"update_dateline,string"` 
    PickingType int `gorm:"type:tinyint(3);column:picking_type;comment:" json:"picking_type,string"` 
    IsSpecial int `gorm:"type:tinyint(1);column:is_special;comment:" json:"is_special,string"` 
    ExpirationDate string `gorm:"type:varchar(10);column:expiration_date;comment:" json:"expiration_date,string"` 
    Saveway string `gorm:"type:varchar(10);column:saveway;comment:" json:"saveway,string"` 
    SaleMethod int `gorm:"type:tinyint(1);column:sale_method;comment:" json:"sale_method,string"` 
    AfterSaleType int `gorm:"type:int(10);column:after_sale_type;comment:" json:"after_sale_type,string"` 
    IsCredit int `gorm:"type:tinyint(1);column:is_credit;comment:" json:"is_credit,string"` 
    CreditLimitTime int `gorm:"type:tinyint(2);column:credit_limit_time;comment:" json:"credit_limit_time,string"` 
    Channel int `gorm:"type:tinyint(3);column:channel;comment:" json:"channel,string"` 
    MerchandiseModeType int `gorm:"type:tinyint(3);column:merchandise_mode_type;comment:" json:"merchandise_mode_type,string"` 
    AfterSaleTag string `gorm:"type:varchar(100);column:after_sale_tag;comment:" json:"after_sale_tag,string"` 
    MerchandiseTag int `gorm:"type:int(11);column:merchandise_tag;comment:" json:"merchandise_tag,string"` 
    InventoryShared int `gorm:"type:tinyint(1);column:inventory_shared;comment:" json:"inventory_shared,string"` 
    OriginalProvenance int `gorm:"type:int(10);column:original_provenance;comment:" json:"original_provenance,string"` 

}

func (d *MerchandiseDao) GetMerchandise(id int) (merchandise Merchandise, err error)  {
	if err := d.db.Table(d.table).Model(Merchandise{}).Where("merchandiseid = ?", id).Find(&merchandise).Error; err != nil {
		return Merchandise{},err
	}
	return merchandise,nil
}

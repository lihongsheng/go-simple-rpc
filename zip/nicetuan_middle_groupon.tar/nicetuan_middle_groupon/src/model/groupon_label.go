package model

import (
	"context"
	
)

type GrouponLabelDao struct {
	table string
	Dao
}

func NewGrouponLabelDao(ctx context.Context) *GrouponLabelDao {
	db := GetConnect("cms")
	db = db.WithContext(ctx)
	return &GrouponLabelDao{
		table: "groupon_label",
		Dao: Dao{
			connect: "cms",
			db: db,
		},
	}
}

type GrouponLabel struct {
    Id int64 `gorm:"type:bigint(20);column:id;primaryKey;autoIncrement;comment:" json:"id,string"` 
    LabelId int64 `gorm:"type:bigint(20);column:label_id;comment:" json:"label_id,string"` 
    LabelName string `gorm:"type:varchar(32);column:label_name;comment:" json:"label_name,string"` 
    SiteId int `gorm:"type:int(11);column:site_id;comment:" json:"site_id,string"` 
    SmallUrl string `gorm:"type:varchar(255);column:small_url;comment:" json:"small_url,string"` 
    BigUrl string `gorm:"type:varchar(255);column:big_url;comment:" json:"big_url,string"` 
    Status int `gorm:"type:tinyint(1);column:status;comment:" json:"status,string"` 
    UserId int `gorm:"type:int(11);column:user_id;comment:" json:"user_id,string"` 
    UpdateTime int `gorm:"type:int(11);column:update_time;comment:" json:"update_time,string"` 
    CreateTime int `gorm:"type:int(11);column:create_time;comment:" json:"create_time,string"` 

}

func (d *GrouponLabelDao) GetGrouponLabel(id int) (grouponLabel GrouponLabel, err error)  {
	if err := d.db.Table(d.table).Model(GrouponLabel{}).Where("id = ?", id).Find(&grouponLabel).Error; err != nil {
		return grouponLabel,err
	}
	return grouponLabel,nil
}

func (d *GrouponLabelDao) GetGrouponLabelByLabelId(labelId int64) (grouponLabel GrouponLabel, err error)  {
	if err := d.db.Table(d.table).Model(GrouponLabel{}).Where("label_id = ?", labelId).Find(&grouponLabel).Error; err != nil {
		return grouponLabel,err
	}
	return grouponLabel,nil
}

func (d *GrouponLabelDao) Insert(grouponLabel GrouponLabel) (int64,error)  {
	result := d.db.Table(d.table).Create(&grouponLabel)
	return grouponLabel.Id,result.Error
}

func (d *GrouponLabelDao) ChangeStatus(labelIds []int64, status int) error  {
	result := d.db.Table(d.table).Where("label_id IN ?", labelIds).Update("status", status)
	return result.Error
}
package log

import (
	"context"
	"fmt"
	"github.com/natefinch/lumberjack"
	"go.uber.org/zap"
	"go.uber.org/zap/zapcore"
	"io"
	"nicetuan_middle_groupon/src/config"
	"nicetuan_middle_groupon/src/util"
	"os"
	"strings"
	"sync"
	"time"
)

var LogOut LogInterface
var ZapLogger *zap.Logger
var output io.WriteCloser
func InitLog(filepath string,filePrefixName string)  {
	LogOut,ZapLogger = NewZapFileLog(filepath,filePrefixName)
}

// LogInterface 对外提供接口,用于后续更改日志组件的时候，外部代码不用修改
type LogInterface interface {
	Debug(ctx context.Context,message string, content ...interface{})
	Info(ctx context.Context,message string, content ...interface{})
	Waring(ctx context.Context,message string, content ...interface{})
	Error(ctx context.Context,message string, content ...interface{})
	Panic(ctx context.Context,message string, content ...interface{})
}

// ZapLog 文件日志
type ZapLog struct {
	lg *zap.Logger
}

// NewZapFileLog 支持多输出源，这里先默认一个
func NewZapFileLog(p string,filePrefixName string) (*ZapLog,*zap.Logger) {
	zl := &ZapLog{}
	// 自定义输出源,及切割文件的方式
	//ws := zapcore.AddSync(&rotateLogs{
	//	path: p,
	//	filePrefixName: filePrefixName,
	//})
	// 使用lumberjack
	output = &lumberjack.Logger{
		Filename:   p + filePrefixName + ".log",
		MaxSize:    300,
		MaxBackups: 30,
		MaxAge:     30,
		Compress:   false,
	}
	ws := zapcore.AddSync(output)

	ec := zap.NewProductionEncoderConfig()
	// ec.EncodeTime = zapcore.ISO8601TimeEncoder
	ec.EncodeTime =  func(time time.Time, encoder zapcore.PrimitiveArrayEncoder) {
		encoder.AppendString(time.Format("2006-01-02 15:04:05"))
	}
	ec.CallerKey = "file" // 设置打印log的地方代码
	en := zapcore.NewJSONEncoder(ec)
	core := zapcore.NewCore(en, ws, zapcore.DebugLevel)
	logger := zap.New(core,
		zap.AddCaller(), // 记录调用位置
		zap.AddCallerSkip(1),// 日志封装了一层往上跳一级记录文件执行位置
		//zap.AddStacktrace(zapcore.PanicLevel),
		)
	zl.lg = logger
	return zl,logger
}

// 调用ZAP的核心log方法
//func (z *ZapLog) log(level Level,message string,content[] interface{})  {
//}

func (z *ZapLog) Debug(ctx context.Context,message string,content ...interface{})  {
	z.lg.Sugar().Debugw(message,"content",content,config.AppConfig.TraceId,util.GetTraceId(ctx,config.AppConfig.TraceId))
}

// Info 目前先用 zap的Sugar()写入
func (z *ZapLog) Info(ctx context.Context,message string,content ...interface{})  {
	z.lg.Sugar().Infow(message,"content",content,config.AppConfig.TraceId,util.GetTraceId(ctx,config.AppConfig.TraceId))
}

func (z *ZapLog) Waring(ctx context.Context,message string,content ...interface{})  {
	z.lg.Sugar().Warnw(message,"content",content,config.AppConfig.TraceId,util.GetTraceId(ctx,config.AppConfig.TraceId))
}

func (z *ZapLog) Error(ctx context.Context,message string,content ...interface{})  {
	z.lg.Sugar().Errorw(message,"content",content,config.AppConfig.TraceId,util.GetTraceId(ctx,config.AppConfig.TraceId))
}

func (z *ZapLog) Panic(ctx context.Context,message string,content ...interface{})  {

	z.lg.Sugar().Panicw(message,"content",content,config.AppConfig.TraceId,util.GetTraceId(ctx,config.AppConfig.TraceId))
}

func (z *ZapLog) getFile() {
	//_, file, line, _ := runtime.Caller(3)
}


// 文件按日期分割写入，写入源
type rotateLogs struct {
	path string  // 日志路径
	fileTime int64 // 当前日志时间
	filePrefixName string
	writer *os.File
	lock sync.Mutex
}

// 按照日期分割文件记录日志
func (r *rotateLogs) fileName() string {
	if r.fileTime == 0 || (time.Now().Unix() - r.fileTime) >= 864000 {
		currentTime := time.Now()
		r.fileTime = time.Date(currentTime.Year(), currentTime.Month(), currentTime.Day(), 0, 0, 0, 0, currentTime.Location()).Unix()
	}
	var sb strings.Builder
	sb.WriteString(r.path)
	sb.WriteString(r.filePrefixName)
	sb.WriteString("-")
	sb.WriteString(fmt.Sprintf("%d-%d-%d.log",time.Now().Year(),time.Now().Month(),time.Now().Day()))
	return sb.String()
}

// 判断是否需要打开新的文件句柄
func (r *rotateLogs) openExistingOrNew() error {
	fn := r.fileName()
	// 获取文件信息
	_,err := os.Stat(fn)
	// 文件不存在
	if os.IsNotExist(err) {
		err := os.MkdirAll(r.path, 0755)
		if err != nil {
			return fmt.Errorf("can't make directories for new logfile: %s", err)
		}
		//os.O_APPEND|os.O_WRONLY, 0644)
		f, err := os.OpenFile(fn, os.O_CREATE|os.O_APPEND|os.O_WRONLY|os.O_TRUNC, 0644)
		if err != nil {
			return fmt.Errorf("can't open new logfile: %s", err)
		}
		r.writer = f
	} else if r.writer == nil {
		f, err := os.OpenFile(fn, os.O_CREATE|os.O_APPEND|os.O_WRONLY, 0644)
		if err != nil {
			return fmt.Errorf("can't open new logfile: %s", err)
		}
		r.writer = f
	}
	return nil
}

// 加锁写入，防止日志写串
func (r *rotateLogs) Write(p []byte) (n int, err error)  {
	defer r.lock.Unlock()
	r.lock.Lock()
	//创建新的日志文件，后续参考 https://github.com/natefinch/lumberjack/blob/v2.0/lumberjack.go 实现一个
	fmt.Println(string(p))
	if err := r.openExistingOrNew(); err != nil {
		return 0,err
	}

	l, e := r.writer.Write(p)
	return l,e
}

func Close() {
	if output != nil {
		output.Close()
	}
}
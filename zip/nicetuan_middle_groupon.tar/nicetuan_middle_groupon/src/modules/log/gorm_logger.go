package log
// 设置 gorm 的logger
import (
	"context"
	"fmt"
	"go.uber.org/zap"
	"gorm.io/gorm/logger"
	"nicetuan_middle_groupon/src/util"
	"time"
)

type SqlLog struct {
	level         Level
	SlowThreshold time.Duration
}
// NewSqlLog 需要返回 gorm.logger.Interface 的接口类
func NewSqlLog(level Level) *SqlLog {
	return &SqlLog{
		level: level,
	}
}
func (s *SqlLog) LogMode(level logger.LogLevel) logger.Interface {
	switch level {
		case logger.Info:
			s.level = InfoLevel
		case logger.Warn:
			s.level = WarnLevel
		case logger.Error:
			s.level = ErrorLevel
		case logger.Silent:
			s.level = DebugLevel
	}
	return s
}

func (s *SqlLog) Info(ctx context.Context, msg string, data ...interface{}) {
	if s.level >= InfoLevel {
		LogOut.Info(ctx,"GORM-SQL-INFO", struct {
			SqlMsg string
			File string
			SqlData []interface{}
		}{
			SqlMsg: msg,
			File: util.FileWithLineNumToStr(3),
			SqlData: data,
		})
	}
}

func (s *SqlLog) Warn(ctx context.Context, msg string, data ...interface{}) {
	if s.level >= WarnLevel {
		LogOut.Info(ctx,"GORM-SQL-WARING", struct {
			SqlMsg string
			File string
			SqlData []interface{}
		}{
			SqlMsg: msg,
			File: util.FileWithLineNumToStr(3),
			SqlData: data,
		})
	}
}

func (s *SqlLog) Error(ctx context.Context, msg string, data ...interface{}) {
	if s.level >= WarnLevel {
		LogOut.Info(ctx,"GORM-SQL-ERROR", struct {
			SqlMsg string
			File string
			SqlData []interface{}
		}{
			SqlMsg: msg,
			File: util.FileWithLineNumToStr(3),
			SqlData: data,
		})
	}
}

// Trace 捕获trace信息
func (s *SqlLog) Trace(ctx context.Context, begin time.Time, fc func() (sql string, rowsAffected int64), err error) {
	if s.level >= DebugLevel {
		elapsed := time.Since(begin)
		switch {
		case err != nil && s.level >= ErrorLevel:
			sql, rows := fc()
			LogOut.Error( ctx,"SQL-TRACE-ERR",
				zap.String("elapsed", fmt.Sprintf("%.3fms", float64(elapsed.Nanoseconds())/1e6)),
				zap.String("error", err.Error()),
				zap.Int64("rows", rows),
				zap.String("sql_file", util.FileWithLineNumToStr(3)),
				zap.String("sql", sql),
			)
		case s.level >= WarnLevel:
			sql, rows := fc()
			slowLog := fmt.Sprintf("SLOW SQL >= %v", s.SlowThreshold)
			LogOut.Info( ctx,"SQL-TRACE-WARN",
				zap.String("slowLog", slowLog),
				zap.String("sql", sql),
				zap.String("elapsed", fmt.Sprintf("%.3fms", float64(elapsed.Nanoseconds())/1e6)),
				zap.Int64("rows", rows),
				zap.String("sql_file", util.FileWithLineNumToStr(3)),
			)
		case s.level == InfoLevel:
			sql, rows := fc()
			if rows != -1 {
				// info 级别sql输出
				LogOut.Info(ctx,"SQL-TRACE-INFo",
					zap.String("elapsed", fmt.Sprintf("%.3fms", float64(elapsed.Nanoseconds())/1e6)),
					zap.String("elapsed", sql),
					zap.Int64("rows", rows),
					zap.String("sql_file", util.FileWithLineNumToStr(3)),
				)
			}
		}
	}
}

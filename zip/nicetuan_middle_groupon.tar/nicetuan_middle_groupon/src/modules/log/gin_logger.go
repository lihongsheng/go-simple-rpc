package log

import (
	"github.com/gin-gonic/gin"
	"go.uber.org/zap"
	"net"
	"net/http"
	"net/http/httputil"
	"nicetuan_middle_groupon/src/constant"
	"nicetuan_middle_groupon/src/config"
	"nicetuan_middle_groupon/src/util"
	"os"
	"runtime/debug"
	"strings"
	"time"
)

// 设置gin 的logger

func GinRequestLog() gin.HandlerFunc {
	return func(c *gin.Context) {
		start := time.Now()
		// some evil middlewares modify this values
		path := c.Request.URL.Path
		query := c.Request.URL.RawQuery
		c.Next()
		end := time.Now()
		latency := end.Sub(start)
		end = end.UTC()

		if len(c.Errors) > 0 {
			// Append error field if this is an erroneous request.
			for _, e := range c.Errors.Errors() {
				LogOut.Error(c.Request.Context(),"error",e)
			}
		} else {
			LogOut.Info(c.Request.Context(),"path",
				zap.Int("status", c.Writer.Status()),
				zap.String("method", c.Request.Method),
				zap.String("path", path),
				zap.String("query", query),
				zap.String("ip", c.ClientIP()),
				zap.String("user-agent", c.Request.UserAgent()),
				zap.String("time", end.Format("2006-01-02 15:04:05")),
				zap.Duration("latency", latency),
				zap.String("trace_id", util.GetTraceId(c.Request.Context(),config.AppConfig.TraceId)),
			)
		}
	}
}

func RecoveryWithZap() gin.HandlerFunc {
	return func(c *gin.Context) {
		// 捕获异常
		defer func() {
			if err := recover(); err != nil {
				// Check for a broken connection, as it is not really a
				// condition that warrants a panic stack trace.
				var brokenPipe bool
				if ne, ok := err.(*net.OpError); ok {
					if se, ok := ne.Err.(*os.SyscallError); ok {
						if strings.Contains(strings.ToLower(se.Error()), "broken pipe") || strings.Contains(strings.ToLower(se.Error()), "connection reset by peer") {
							brokenPipe = true
						}
					}
				}

				httpRequest, _ := httputil.DumpRequest(c.Request, false)
				if brokenPipe {
					LogOut.Error(c.Request.Context(),c.Request.URL.Path,
						zap.Any("error", err),
						zap.String("request", string(httpRequest)),
						zap.String("trace_id", util.GetTraceId(c.Request.Context(),config.AppConfig.TraceId)),
					)
					// If the connection is dead, we can't write a status to it.
					c.Error(err.(error)) // nolint: errcheck
					c.Abort()
					return
				}

				LogOut.Error(c.Request.Context(),c.Request.URL.Path,
					zap.Time("time", time.Now()),
					zap.Any("error", err),
					zap.String("request", string(httpRequest)),
					zap.String("stack", string(debug.Stack())),
					zap.String("trace_id", util.GetTraceId(c.Request.Context(),config.AppConfig.TraceId)),
				)
				//c.AbortWithStatus(http.StatusInternalServerError)
				c.AbortWithStatusJSON(http.StatusInternalServerError,constant.Response{
					Code: constant.ResponseSystemError,
					Msg: constant.Tips.SystemErrorMsg,
				})
			}
		}()
		c.Next()
	}
}

package kafka

import (
	"fmt"
	"nicetuan_middle_groupon/src/libaray/queue"
)

// 加入到消费者列表
func init()  {
	RegisterConsumer("test", testHandler)
}
// 定义消费者
func testHandler(message queue.MessageInfoInterface) error {
	fmt.Println(":::::::"+message.GetMessage()+":::::::::")
	//if strings.Contains(message.GetMessage(),"Index::100") {
	//	return errors.New(" :::::::::test error Index::100::::::::")
	//}
	return nil
}




package kafka
// kafka消费者 基础类型定义

import (
	"errors"
	"github.com/spf13/viper"
	"nicetuan_middle_groupon/src/libaray/queue"
)

type Conf struct {
	Topic string `yaml:"topic"`
	GroupId string `yaml:"group_id"`
	Partition int `yaml:"partition"`
	Connect string `yaml:"connect"`
	AutoCommit bool `yaml:"autoCommit"`
}


// 存储消费者
var consumerList = make(map[string] queue.ConsumerHandler)

// GetConf 获取消费者配置项
func GetConf(key string) Conf  {
	conf := Conf{}
	viper.UnmarshalKey("consumer." + key,&conf)
	return conf
}

// RegisterConsumer 注册消费者
func RegisterConsumer(key string,consumer queue.ConsumerHandler) {
	consumerList[key] = consumer
}

// GetConsumer 获取消费者
func GetConsumer(key string) (queue.ConsumerHandler,error) {
	k,ok := consumerList[key]
	if !ok   {
		return nil,errors.New(key + "not find")
	}
	return k,nil
}

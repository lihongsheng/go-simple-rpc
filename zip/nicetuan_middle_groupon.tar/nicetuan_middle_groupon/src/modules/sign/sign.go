// Package sign go 参数加密示例
package sign

import (
	"crypto/sha256"
	"encoding/hex"
	"fmt"
	"github.com/google/uuid"
	"sort"
	"strings"
	"time"
)


// AssemblyParams 拼装请求参数(带签名)
func AssemblyParams(params map[string]interface{}, appKey string, secretKey string) map[string]interface{} {
	params["app_key"] = appKey
	params["ts"] = time.Now().Unix()
	params["rd"] = uuid.New().String()
	paramsSign := sign(params, secretKey)
	params["sign"] = paramsSign
	return params
}

// 参数签名
func sign(params map[string]interface{}, secretKey string) string {
	signParams := map[string]string{}
	for k, v := range params {
		if k != "sign" {
			signParams[k] = fmt.Sprintf("%v", v)
		}
	}
	paramsString := ParamsSort(signParams)
	secretSting := fmt.Sprintf("%s%s%s", secretKey, paramsString, secretKey)
	bytes := sha256.Sum256([]byte(secretSting)) //计算哈希值，返回一个长度为32的数组
	secretSign := hex.EncodeToString(bytes[:])  //将数组转换成切片，转换成16进制，返回字符串
	return secretSign
}

// ParamsSort 获取参数排序字符串
func ParamsSort(params map[string]string) string {
	var dataParams strings.Builder
	var keys []string
	for k := range params {
		keys = append(keys, k)
	}
	sort.Strings(keys)
	//拼接
	for _, k := range keys {
		dataParams.WriteString(k)
		dataParams.WriteString(params[k])
	}
	return dataParams.String()
}
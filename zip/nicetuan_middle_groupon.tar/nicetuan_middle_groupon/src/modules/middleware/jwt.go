package middleware

import (
	"github.com/gin-gonic/gin"
	"net/http"
	"nicetuan_middle_groupon/src/config"
	"nicetuan_middle_groupon/src/libaray/jwt"
)

// jwt 中间件

func Jwt() gin.HandlerFunc {
	return func(c *gin.Context) {
		auth := c.GetHeader("Authorization")
		if config.AppConfig.JwtSwitch == true {
			user,err := jwt.ParseToken(auth,config.AppConfig.JwtKey)
			if err != nil {
				c.JSON(http.StatusOK,gin.H{"code":-1,"message":"error token"})
				c.Abort()
				return
			}
			c.Set("user",user)
		}


		c.Next()
	}
}

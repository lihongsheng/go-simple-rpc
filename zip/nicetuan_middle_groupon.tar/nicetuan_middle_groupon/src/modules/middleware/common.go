package middleware

import (
	"context"
	"github.com/gin-gonic/gin"
	"nicetuan_middle_groupon/src/config"
	"nicetuan_middle_groupon/src/util"
)

func init() {
	RegisterMiddle("/",CreatTraceId)
}

// CreatTraceId 给 gin 的上下文加上 traceID
func CreatTraceId() gin.HandlerFunc {
	return func(c *gin.Context) {
		// 接受外部和自定义 tag
		c.Request = c.Request.WithContext(context.WithValue(c.Request.Context(),config.AppConfig.TraceId,util.GenerateTraceId()))
		c.Next()
	}
}

package middleware

import (
	"github.com/gin-gonic/gin"
)

// 签名验证

func Sign() gin.HandlerFunc {
	return func(c *gin.Context) {
		c.Next()
	}
}

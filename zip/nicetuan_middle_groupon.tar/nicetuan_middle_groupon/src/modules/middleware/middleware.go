package middleware

import (
	"github.com/gin-gonic/gin"
)

var middle = make(map[string][]func() gin.HandlerFunc)

// RegisterMiddle 注册中间件
func RegisterMiddle(path string,handler func() gin.HandlerFunc) {
	middle[path] = append(middle[path],handler)
}

// LoadMiddle 加载中间件
func LoadMiddle(engine *gin.Engine)  {
	for path, handlerList := range middle {
		for _,handler := range handlerList {
			if path == "/" || path == "" {
				engine.Use(handler())
			} else {
				engine.Group(path,handler())
			}
		}
	}
}

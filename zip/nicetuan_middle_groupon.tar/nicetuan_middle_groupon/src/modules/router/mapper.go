package router

import (
	"fmt"
	"github.com/gin-gonic/gin"
	"net/http"
	"nicetuan_middle_groupon/src/service"
	"nicetuan_middle_groupon/src/util"
	"reflect"
)

type ApiMethod int

const (
	 GET  ApiMethod = iota
	 POST
	 PUT
	 ANY
)

func (a ApiMethod) String() string {
	switch a {
	case GET:
		return "GET"
	case POST:
		return "POST"
	case PUT:
		return "PUT"
	case ANY:
		return "ANY"
	default:
		return fmt.Sprintf("ApiMethod(%d)", a)
	}
}

// ConsumerHandler 定义消费者类型
type apiParamHandler func(interface{},*gin.Context)


type routerStruct struct {
	api gin.HandlerFunc
	path string
}

type routerParamStruct struct {
	api interface{}
	path string
}
// 存储消费者
var paramRouters = make(map[string][]routerParamStruct)
var routers =  make(map[string][]routerStruct)

func RegisterApiNoParam(api gin.HandlerFunc,apiMethod ApiMethod,urlPath  string)  {
	rs := routerStruct{
		api: api,
		path: urlPath,
	}
	routers[apiMethod.String()] = append(routers[apiMethod.String()],rs)
}

func RegisterApiParam(api interface{}, apiMethod ApiMethod, urlPath  string)  {
	rs := routerParamStruct{
		api: api,
		path: urlPath,
	}
	paramRouters[apiMethod.String()] = append(paramRouters[apiMethod.String()],rs)
}

func InitRouter(engine *gin.Engine) {
	// 默认 gin.context参数的
	for key, apiList := range routers {
		switch key {
		case "POST":
			for _,api := range apiList {
				engine.POST(api.path,api.api)
			}
		case "GET":
			for _,api := range apiList {
				engine.GET(api.path,api.api)
			}
		case "PUT":
			for _,api := range apiList {
				engine.PUT(api.path,api.api)
			}
		case "ANY":
			for _,api := range apiList {
				engine.Any(api.path,api.api)
			}
		}
	}

	// 默认 gin.context参数的
	for key, apiList := range paramRouters {
		switch key {
		case "POST":
			for _,api := range apiList {
				engine.POST(api.path, proxyHandler(api))
			}
		case "GET":
			for _,api := range apiList {
				engine.GET(api.path, proxyHandler(api))
			}
		case "PUT":
			for _,api := range apiList {
				engine.GET(api.path, proxyHandler(api))
			}
		case "ANY":
			for _,api := range apiList {
				engine.GET(api.path, proxyHandler(api))
			}
		}
	}
}

// 代理处理
func proxyHandler(paramStruct routerParamStruct) func(*gin.Context) {
	// 代码待优化，不放到每次请求做一次反射，在注册路由处理的时候反射好
	tOf := reflect.TypeOf(paramStruct.api)
	vOf := reflect.ValueOf(paramStruct.api)
	if tOf.Kind() != reflect.Func {
		panic("path not find api")
	}
	if tOf.NumIn() <= 2 {
		panic("parameter must is  three")
	}
	// 获取参数示例，目前只支持指针类型的参数
	if tOf.In(0).Kind() != reflect.Ptr {
		panic("parameter must is  Pointer Type")
	}
	// 获取指针类型参数,变量会逃逸到堆内存
	typeParam := tOf.In(0).Elem()
	serviceParam := tOf.In(1).Elem()
	return func(ctx *gin.Context) {
		paramHandler(ctx,vOf,typeParam,serviceParam)
	}
}

// 带参数的接口统一检验参数,和带service注入的
func paramHandler(ctx *gin.Context, value reflect.Value, param reflect.Type, ser reflect.Type)  {
	// 创建参数实例，想当于 var b = New(struct) 所以返回的是引用
	params := reflect.New(param).Interface()
	// 参数校验
	if err := ctx.ShouldBind(&params); err != nil {
		err = util.FormatValidateError(err)
		ctx.JSON(http.StatusOK, struct{
			Code int           `json:"code"`
			Msg  string        `json:"msg"`
			Data interface{} `json:"data"`
		}{
			Code:1,
			Msg:err.Error(),
			Data:nil,
		})
		return
	}

	serviceParam := reflect.New(ser).Interface().(service.ServiceInterface)
	serviceParam.Init(ctx.Request.Context())
	// 构造参数
	funcParam := make([]reflect.Value,0)
	funcParam = append(funcParam,reflect.ValueOf(params))
	funcParam = append(funcParam,reflect.ValueOf(serviceParam))
	funcParam = append(funcParam,reflect.ValueOf(ctx))
	// 调用方法
	value.Call(funcParam)
}


package router

import (
	"nicetuan_middle_groupon/src/controller/api"
)

func init()  {
	a := &api.Api{}
	RegisterApiParam(a.GetGroupon,POST,"/api/robotAllocation/getGroupon")
	RegisterApiParam(a.GrouponMerchandise,POST,"/api/robotAllocation/grouponMerchandise")
	RegisterApiParam(a.ChangeStatus,POST,"/api/groupon/label/status")
	// biw获取团购信息
	//RegisterApiParam(a.BiwGroupon,POST,"/api/biw/biwGroupon")
	//RegisterApiParam(a.RobotGrouponMerchandise,POST,"/api/robotAllocation/getGrouponMerchandise")

}


package entity

type GrouponMerchandise struct {
	GrouponMerchandiseId int `gorm:"column:groupon_merchandise_id;" json:"groupon_merchandise_id"`
	MerchandiseId int `gorm:"column:merchandise_id;" json:"merchandise_id"`
	Title string `gorm:"column:title;" json:"title"`
	Coverimage string `gorm:"column:coverimage;" json:"coverimage"`
	GrouponId int `gorm:"column:groupon_id;" json:"groupon_id"`
	Onsale int `gorm:"type:tinyint(3);column:onsale;comment:" json:"onsale,string"`
	Mtype int `gorm:"type:smallint(5);column:mtype;comment:" json:"mtype,string"`
	MerchandiseModeType int `gorm:"type:tinyint(3);column:merchandise_mode_type;comment:" json:"merchandise_mode_type,string"`
}

// GrouponMerchtype 团规格信息
type GrouponMerchtype struct {
	MerchtypeName string `gorm:"column:merchtype_name;" json:"merchtype_name"`
	GrouponMerchtypeId int `gorm:"column:groupon_merchtype_id;primaryKey;autoIncrement;comment:" json:"groupon_merchtype_id"`
	GrouponMerchandiseId int `gorm:"column:groupon_merchandise_id;comment:" json:"groupon_merchandise_id"`
	GrouponId int `gorm:"column:groupon_id;comment:" json:"groupon_id"`
	MerchtypeId int `gorm:"column:merchtype_id;comment:" json:"merchtype_id"`
	Price int `gorm:"column:price;comment:" json:"price"`
	Brokerage float64 `gorm:"column:brokerage;comment:" json:"brokerage"`
	Quantity int `gorm:"column:quantity;comment:" json:"quantity"`
	MaxQuantity int `gorm:"column:max_quantity;comment:" json:"max_quantity"`
	LimitQuantity int `gorm:"column:limit_quantity;comment:" json:"limit_quantity"`
	Soldout int `gorm:"column:soldout;comment:" json:"soldout"`
	Dateline int `gorm:"column:dateline;comment:" json:"dateline"`
	UpdateDateline int `gorm:"column:update_dateline;comment:" json:"update_dateline"`
	MerchandiseId int `gorm:"column:merchandise_id;comment:" json:"merchandise_id"`
	SupplierPrice int `gorm:"column:supplier_price;comment:" json:"supplier_price"`
	SupplierId int `gorm:"column:supplier_id;comment:" json:"supplier_id"`
}


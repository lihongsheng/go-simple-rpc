package request

type BiwDto interface {
	GetDate() string
	GetCityId() int
	GetGroupType() int
}

type BiwGroupon struct {
	Date   string `form:"date" json:"date" binding:"required" time_format:"2006-01-02"`
	CityId     int `form:"city_id" json:"city_id" binding:"gte=0"`
	GroupType  int `form:"group_type" json:"group_type" binding:"gte=0"`
}

func (biw BiwGroupon) GetDate()  string {
	return biw.Date
}

func (biw BiwGroupon) GetCityId() int {
	return biw.CityId
}

func (biw BiwGroupon) GetGroupType() int {
	return biw.GroupType
}


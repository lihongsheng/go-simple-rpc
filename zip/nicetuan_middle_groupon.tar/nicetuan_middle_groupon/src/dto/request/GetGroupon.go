package request

type GrouponDto interface {
	 GetDateStart() string
	 GetDateEnd() string
	 GetCityId() int
	 GetGroupType() int
	 GetClientType() int
}

//
type GetGroupon struct {
	RequestId  string `form:"request_id" uri:"request_id" json:"request_id" binding:"required"`
	DateStart  string `form:"date_start" json:"date_start" binding:"required" time_format:"2006-01-02"`
	DateEnd    string `form:"date_end" json:"date_end" binding:"required" time_format:"2006-01-02"`
	CityId     int `form:"city_id" json:"city_id" binding:"gte=0"`
	GroupType  int `form:"group_type" json:"group_type" binding:"gte=0"`
	ClientType int `form:"client_type" json:"client_type" binding:"gte=0"`
}

func (g GetGroupon) GetDateStart()  string {
	return g.DateStart
}

func (g GetGroupon) GetDateEnd()  string {
	return g.DateEnd
}

func (g GetGroupon) GetCityId() int {
	return g.CityId
}

func (g GetGroupon) GetGroupType() int {
	return g.GroupType
}

func (g GetGroupon) GetClientType() int {
	return g.ClientType
}

// RobotGrouponMerchandiseDto 机器人获取团购商品
type RobotGrouponMerchandiseDto interface {
	GetGrouponId() int
	GetGrouponMerchandiseId() int
}

type RobotGrouponMerchandise struct {
	RequestId            string `form:"request_id" uri:"request_id" json:"request_id" binding:"required"`
	GrouponId            int    `form:"groupon_id" uri:"groupon_id"  json:"groupon_id" binding:"required,gt=0"`
	GrouponMerchandiseId int    `form:"groupon_merchandise_id" json:"groupon_merchandise_id" binding:"required"`
}
func (r RobotGrouponMerchandise) GetGrouponId()  int {
	return r.GrouponId
}

func (r RobotGrouponMerchandise) GetGrouponMerchandiseId()  int {
	return r.GrouponMerchandiseId
}







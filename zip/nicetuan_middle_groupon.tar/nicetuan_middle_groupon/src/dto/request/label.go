package request

// AddLabel 添加标签数据结构
type AddLabel struct {
	SaleLabelId int64    `form:"sale_label_id" uri:"sale_label_id"  json:"sale_label_id" binding:"required,gt=0"`
	Name string    `form:"name" uri:"name"  json:"name" binding:"required,min=1"`
	SiteId int    `form:"site_id" uri:"site_id"  json:"site_id" binding:"required,gt=0"`
	Status int    `form:"status" uri:"status"  json:"status" binding:"required,gt=0"`
}
// ChangeLabelStatus 改变标签状态
type ChangeLabelStatus struct {
	SaleLabelIds []int64 `form:"sale_label_ids" uri:"sale_label_ids"  json:"sale_label_ids"`
	Status int    `form:"status" uri:"status"  json:"status" `
}

package response

type RobotResponseMerchandise struct {
	GrouponMerchandiseId int `gorm:"column:groupon_merchandise_id;" json:"groupon_merchandise_id"`
	MerchandiseId int `gorm:"column:merchandise_id;" json:"merchandise_id"`
	Title string `gorm:"column:title;" json:"title"`
	Coverimage string `gorm:"column:coverimage;" json:"coverimage"`
	GrouponId int `gorm:"column:groupon_id;" json:"-"` // 序列化的时候不输出
}

type RobotResponseGrouponAndMerchandise struct {
	GrouponId int `json:"groupon_id"`
	CityId int `json:"city_id"`
	GrouponDate string `json:"groupon_date"`
	StartTime int `json:"start_time"`
	EndTime int `json:"end_time"`
	IsStop int `json:"is_stop"`
	GroupType int `json:"group_type"`
	GrouponMerchandise []RobotResponseMerchandise
}

type RobotResponseGrouponMerchtypeAndSite struct {
	MerchtypeId int `json:"merchtype_id"`
	GrouponMerchtypeId int `json:"groupon_merchtype_id"`
	MerchtypeName string `json:"merchtype_name"`
	MerchtypeSite []RobotResponseGrouponMerchtypeSite `json:"merchtype_site"`
}

type RobotResponseGrouponMerchtypeSite struct {
	SiteId int64 `json:"site_id"`
	Price int `json:"price"`
	GrouponMerchandiseSiteId int64 `json:"groupon_merchandise_site_id"`
}

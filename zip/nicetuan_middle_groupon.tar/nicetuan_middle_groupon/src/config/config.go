package config

type MysqlConf struct {
	User            string `yaml:"user"`
	Password        string `yaml:"password"`
	Port            int    `yaml:"port"`
	Chart           string `yaml:"chart"`
	Host            string `yaml:"host"`
	DbName          string `yaml:"db_name"`
	MaxIdleConn     int    `yaml:"max_idle_conn"`
	MaxOpenConn     int    `yaml:"max_open_conn"`
	ConnMaxLifetime int    `yaml:"conn_max_lifetime"`
}
type Redis struct {
	User            string            `yaml:"user"`
	Password        string            `yaml:"password"`
	Host            string            `yaml:"host"`
	Port            int               `yaml:"port"`
	Optins          map[string]string `yaml:"optins"`
	Db              int               `yaml:"db"`
	MaxIdleConn     int               `yaml:"max_idle_conn"`
	MaxOpenConn     int               `yaml:"max_open_conn"`
	ConnMaxLifetime int               `yaml:"conn_max_lifetime"`
	ConnectTimeout  int               `yaml:"connect_timeout"`
	ReadTimeout     int               `yaml:"read_timeout"`
	WriteTimeout    int               `yaml:"write_timeout"`
}
type Kafka struct {
	Host string `yaml:"host"`
	Port int    `yaml:"port"`
}
type AppConfigInfo struct {
	TraceId           string      `yaml:"trace_id"`
	Port              int         `yaml:"port"`
	TimeOut           int         `yaml:"timeout"`
	Mode              string      `yaml:"mode"`
	LogPath           string      `yaml:"log_path"`
	LogFilePrefixName string      `yaml:"log_file_prefix_name"`
	JwtSwitch         bool        `yaml:"jwt_switch"`
	JwtKey            string      `yaml:"jwt_key"`
	JwtExp            string      `yaml:"jwt_exp"`
	Version           string      `yaml:"version"`
	env               string
}

func (a *AppConfigInfo) SetEnv(env string)  {
	a.env = env
}

func (a *AppConfigInfo) GetEnv() string  {
	return a.env
}

var AppConfig *AppConfigInfo



package config

import jwtgo "github.com/dgrijalva/jwt-go"

type UserToken struct {
	jwtgo.StandardClaims
	UserId int
}

package constant

const (
	ResponseSystemError = -1
	ResponseSuccess = 0
	SIGN_FAIL = 110
	PARAMS_NULL = 120
	ResponseError = 1
)


type Response struct {
	Code int           `json:"code"`
	Msg  string        `json:"msg"`
	Data interface{} `json:"data"`
}

var Tips = struct {
	SystemErrorMsg string
}{
	SystemErrorMsg: "系统异常",
}

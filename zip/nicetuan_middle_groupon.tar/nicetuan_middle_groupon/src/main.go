package main

import (
	"nicetuan_middle_groupon/src/cmd"
)

func main() {
	cmd.Execute()
	//config.InitConfig("./conf/config.yml")
	//ss := sync.WaitGroup{}
	//ss.Add(1)
	//go func() {
	//	defer ss.Done()
	//	index := 0
	//	for  {
	//		index++
	//		partition ,offset ,err := kafka.SendMsg("cms","test","{\"hello\":\"hello\"}:Index::" + strconv.Itoa(index))
	//		fmt.Printf("partition:%d :::: offset:%d ",partition,offset)
	//		if err != nil {
	//			fmt.Println(err.Error())
	//		}
	//		if index > 1000 {
	//			return
	//		}
	//	}
	//}()
	//
	//ss.Wait()
	//err := config.LoadConfig("./conf/kafka_consumer.yml")
	//if err != nil {
	//	fmt.Println(err.Error())
	//	os.Exit(1)
	//}

	//conf := kafka2.GetConf("test")
	//if err != nil {
	//	fmt.Println("not find consumer by ")
	//	os.Exit(1)
	//}
}


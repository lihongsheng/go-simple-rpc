package cmd

import (
	"context"
	"fmt"
	"github.com/gin-gonic/gin"
	"github.com/spf13/cobra"
	"net/http"
	"nicetuan_middle_groupon/src/config"
	"nicetuan_middle_groupon/src/modules/log"
	"nicetuan_middle_groupon/src/modules/middleware"
	"nicetuan_middle_groupon/src/modules/router"
	"nicetuan_middle_groupon/src/util"
	"os"
	"os/signal"
	"strconv"
	"syscall"
	"time"
)

var start = &cobra.Command{
	Use:   "web",
	Short: "A brief description of your command",
	Long: `A longer description that spans multiple lines and likely contains examples
and usage of using your command. For example:

Cobra is a CLI library for Go that empowers applications.
This application is a tool to generate the needed files
to quickly create a Cobra application.`,
	Run: func(cmd *cobra.Command, args []string) {
		bootStart()
	},
}

func init()  {
	appCmd.AddCommand(start)
}

// bootStart 启动web程序
func bootStart() {
	// 监听的服务IP和地址，0.0.0.0表示监控所有IP
	addr := "0.0.0.0:"+ strconv.Itoa(config.AppConfig.Port)
	timeOut := time.Duration(config.AppConfig.TimeOut) * time.Second
	// 启动 go自带的HTTP_SERVER
	httpServer := &http.Server{
		Addr:         addr,
		Handler:      httpHandlers(), // 返回 gin实现的 serverHttp 接口
		WriteTimeout: timeOut,
		ReadTimeout:  timeOut,
	}
	// 启动程序
	util.Go(func() {
		fmt.Println("start by "+ addr + " success")
		if err := httpServer.ListenAndServe(); err != nil && err != http.ErrServerClosed {
			panic(err)
		}
	})
	// 监听系统信号，如 control + c的中断信号
	quit := make(chan os.Signal, 1)
	signal.Notify(quit, syscall.SIGINT, syscall.SIGTERM, syscall.SIGCHLD)
	// 阻塞等待系统信号
	<-quit
	// 处理未完成的请求, 响应超时
	now := time.Now()
	ctx, cancel := context.WithTimeout(context.Background(), 15*time.Second)
	defer cancel()
	// 关闭 http server
	if err := httpServer.Shutdown(ctx); err != nil {
		fmt.Println(err)
	}
	log.Close()
	fmt.Println("exit elapsed time: "+time.Since(now).String(),"red")
}

// httpHandlers 处理http请求
func httpHandlers() *gin.Engine{
	gin.SetMode(config.AppConfig.Mode)
	engine := gin.New()
	gin.DisableConsoleColor()
	// 给gin的每个请求赋予traceID
	// 其他公共中间件
	middleware.LoadMiddle(engine)
	// 替换 gin的log
	engine.Use(log.GinRequestLog(),log.RecoveryWithZap())
	// 注册路由
	router.InitRouter(engine)
	//gin.DefaultWriter = log.LogOut
	engine.GET("/", func(c *gin.Context) {
		c.JSON(200, struct {
			Name string `json:"name"`
		}{Name: "hello"})
		log.LogOut.Info(context.TODO(),"request1","hello word111")
	})
	return engine
}


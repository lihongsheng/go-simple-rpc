/*
Copyright © 2021 NAME HERE <EMAIL ADDRESS>

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
*/
package cmd

import (
	"errors"
	"fmt"
	"nicetuan_middle_groupon/src/config"
	"nicetuan_middle_groupon/src/libaray/config_interface"
	"nicetuan_middle_groupon/src/modules/log"
	"nicetuan_middle_groupon/src/util"
	"os"

	"github.com/spf13/cobra"
)

var AppPath string
var appCmd *cobra.Command
// appCmd represents the app command

var cfgPath string
var env string

func init() {
	appCmd = &cobra.Command{
		Use:   "app",
		Short: "A brief description of your command",
		Long: ``,
		TraverseChildren: true,
		Run: func(cmd *cobra.Command, args []string) {
		},
	}
	AppPath,_ = os.Getwd()
	if AppPath != "" {
		AppPath += "/"
	}
	cobra.OnInitialize(initConfig)
	// 在此可以定义自己的flag或者config设置，Cobra支持持久标签(persistent flag)，它对于整个应用为全局
	// 在StringVarP中需要填写`shorthand`，详细见pflag文档
	appCmd.PersistentFlags().StringVarP(&cfgPath, "config", "c","", "config file (defalut in $HOME/config.yml)")
	appCmd.PersistentFlags().StringVarP(&env, "env", "env","dev", "config file (defalut in $HOME/config.yml)")
}

func findConfigFile(originFile *string,fileName string) error  {
	if *originFile == "" {
		if *originFile == "" {
			if util.FileExists(AppPath+"conf/" + fileName) {
				*originFile = AppPath+"conf/"
			} else if util.FileExists(AppPath+"../conf/" + fileName) {
				*originFile = AppPath+"../conf/"
			} else {
				return errors.New("can not find config in the path "+ *originFile)
			}
		}
		return nil
	} else {
		str := *originFile
		last := str[len(str)-2:]
		if last == "/" {
			if util.FileExists(str + fileName) {
				return nil
			}
		} else {
			if util.FileExists(str + "/" + fileName) {
				*originFile = str + "/"
				return nil
			}
		}
		return errors.New("can not find config in the path "+ *originFile)

	}
	return nil
}

// initConfig 初始化配置
func initConfig() {
	// 查找配置
	cfgFile :=  "config-" + env + ".yml"
	if err := findConfigFile(&cfgPath,cfgFile); err != nil {
		fmt.Println(err.Error())
		os.Exit(1)
	}
	config.AppConfig = &config.AppConfigInfo{}
	config_interface.Config = &config_interface.ConfigStruct{}
	if err := config_interface.Config.InitConfig(cfgPath + cfgFile);err != nil {
		panic("加载配置出错" + err.Error())
	}
	config_interface.Config.UnmarshalKey("application",config.AppConfig)
	log.InitLog(config.AppConfig.LogPath,config.AppConfig.LogFilePrefixName)
}
func Execute() {
	appCmd.Execute()
}

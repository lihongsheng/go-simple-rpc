package cmd

import (
	"fmt"
	"github.com/spf13/cobra"
	model2 "nicetuan_middle_groupon/src/model"
	"nicetuan_middle_groupon/src/util"
	"os"
	"strings"
)
var table, source, name, desc string
func init() {
	model.Flags().StringVarP(&table,"table","t","","table 表名")
	model.Flags().StringVarP(&source,"source","s","cms","链接的数据源")
	model.Flags().StringVarP(&name,"name","n","","model名字")
	model.Flags().StringVarP(&desc,"desc","d","","model名字")
	appCmd.AddCommand(model)

}
// 创建model命令
var model = &cobra.Command{
	Use:   "model",
	Short: "A brief description of your command",
	Long: `创建model类`,
	Run: func(cmd *cobra.Command, args []string) {
		if table =="" {
			fmt.Println("table is not empty")
			os.Exit(1)
		}
		if name == "" {
			name = util.Case2Camel(table)
		}
		createModel()
	},
}

type Columns struct {
	Field string `gorm:"type:varchar(200);" json:"Field"`
	Type string `gorm:"type:varchar(200);" json:"Type"`
	Null string `gorm:"type:varchar(200);" json:"Null"`
	Key string `gorm:"type:varchar(200);" json:"Key"`
	Default string `gorm:"type:varchar(200);" json:"Default"`
	Extra string `gorm:"type:varchar(200);" json:"Extra"`
}

var privateType = ""

var tpl = `package model

import (
	"context"
	#privateType#
)

type #name#Dao struct {
	table string
	Dao
}

func New#name#Dao(ctx context.Context) *#name#Dao {
	db := GetConnect("#source#")
	db = db.WithContext(ctx)
	return &#name#Dao{
		table: "#table#",
		Dao: Dao{
			connect: "#source#",
			db: db,
		},
	}
}

type #name# struct {
#field#
}

func (d *#name#Dao) Get#name#(id int) (#LowName# #name#, err error)  {
	if err := d.db.Table(d.table).Model(#name#{}).Where("#AutoId# = ?", id).Find(&#LowName#).Error; err != nil {
		return #LowName#{},err
	}
	return #LowName#,nil
}
`

func createModel() {
	 //res := &Columns{}
	 res := &Columns{}
	db := model2.GetConnect(source)
	rows,_ := db.Raw("SHOW COLUMNS FROM  `" + table + "`").Rows()
	if rows.Err() != nil {
		fmt.Println("Error " + rows.Err().Error())
		os.Exit(1)
	}
	var fields = strings.Builder{}
	defer rows.Close()
	 priKey := ""
	autoIncrement := ""
	primaryKey := ""
    column := ""

	for rows.Next() {
		db.ScanRows(rows,res)
		//var nullTag = ""
		//if res.Null != "null" {
		//	nullTag = "not null;"
		//}
		if res.Key == "PRI" {
			primaryKey = "primaryKey;"
			priKey = res.Field
		} else {
			primaryKey = ""
		}
		column = "column" + ":" + res.Field + ";"
		if res.Extra == "auto_increment" {
			autoIncrement = "autoIncrement;"
		} else {
			autoIncrement = ""
		}
		fType := strings.ReplaceAll(res.Type," unsigned","")
		// + nullTag
		goType := typeToGo(res.Type)
		if goType == "types." {
			privateType = "\"nicetuan_middle_groupon/src/types\""
		}
		fields.WriteString("    " + util.Case2Camel(res.Field) + " " + goType + " `gorm:\"type:" + fType + ";"  + column + primaryKey  + autoIncrement + "comment:\" " + "json:\""+res.Field+",string\"` \n")
	}

	var FieldStr = fields.String()
	if FieldStr == "" {
		fmt.Println("Error NOT FIND " + table + " field" )
		os.Exit(1)
	}

	tmp := tpl
	LowName := util.Lcfirst(name)
	tmp = strings.ReplaceAll(tmp,"#source#",source)
	tmp = strings.ReplaceAll(tmp,"#name#",name)
	tmp = strings.ReplaceAll(tmp,"#LowName#",LowName)
	tmp = strings.ReplaceAll(tmp,"#field#",fields.String())
	tmp = strings.ReplaceAll(tmp,"#AutoId#",priKey)
	tmp = strings.ReplaceAll(tmp,"#table#",table)
	tmp = strings.ReplaceAll(tmp,"#privateType#",privateType)

	var f *os.File
	var err error
	if util.FileExists(AppPath + "model/") {
		f, err = os.OpenFile(AppPath + "model/" + table + ".go", os.O_CREATE|os.O_APPEND|os.O_WRONLY|os.O_TRUNC, 0644)
	} else {
		f, err = os.OpenFile(AppPath + "src/model/" + table + ".go", os.O_CREATE|os.O_APPEND|os.O_WRONLY|os.O_TRUNC, 0644)
	}

	if err != nil {
		fmt.Println("can't open new logfile: %s"+ err.Error(),"red")
		os.Exit(1)
	}
	fmt.Println(" write " + "model/" + table + ".go")
	f.WriteString(tmp)
	f.Close()
	fmt.Println("success")
}
// 数据类型和go类型做转换 待完善
func typeToGo(string2 string) string {
	if strings.HasPrefix(string2,"varchar") {
		return "string"
	} else if strings.HasPrefix(string2,"text") {
		return "string"
	} else if strings.HasPrefix(string2,"int") {
		return "int"
	} else if strings.HasPrefix(string2,"tinyint") {
		return "int"
	} else if strings.HasPrefix(string2,"smallint") {
		return "int"
	} else if strings.HasPrefix(string2,"mediumint") {
		return "int"
	}  else if strings.HasPrefix(string2,"bigint") {
		return "int64"
	}  else if strings.HasPrefix(string2,"date") {
		return "types.LocalDate"
	}  else if strings.HasPrefix(string2,"datetime") {
		return "types.LocalDateTime"
	} else if strings.HasPrefix(string2,"float") {
		return "float64"
	} else if strings.HasPrefix(string2,"double") {
		return "float64"
	} else if strings.HasPrefix(string2,"decimal") {
		return "float64"
	}
	return "string"
}



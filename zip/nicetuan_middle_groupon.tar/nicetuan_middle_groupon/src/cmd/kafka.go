package cmd

import (
	"fmt"
	"github.com/spf13/cobra"
	"nicetuan_middle_groupon/src/libaray/config_interface"
	kafkaManager "nicetuan_middle_groupon/src/libaray/kafka"
	kafkaConfig "nicetuan_middle_groupon/src/modules/kafka"
	"os"
)
var consumer = ""
var kafkaCfg = ""
//
func init() {
	// 注册 消费者
	// 执行示例 go run src/main.go kafka --consumer test
	// 后续放到单独的目录里
	kafka.Flags().StringVar(&consumer,"consumer","","需要执行命令的标签")
	appCmd.AddCommand(kafka)
}
// 创建model命令
var kafka = &cobra.Command{
	Use:   "kafka",
	Short: "A brief description of your command",
	Long: `kafka 执行`,
	Run: func(cmd *cobra.Command, args []string) {
		// 消费者标签
		if consumer =="" {
			fmt.Println("consumer is not empty")
			os.Exit(1)
		}
		// 加载在kafka配置
		initKafkaConfig()
		// 基于消费者标签，获取消费者和消费者的配置
		csr,err := kafkaConfig.GetConsumer(consumer)
		conf := kafkaConfig.GetConf(consumer)
		// 如果获取错误，直接退出
		if err != nil {
			fmt.Println("not find consumer by "+consumer)
			os.Exit(1)
		}
		// 执行消费者
		manager := kafkaManager.ConsumerManager{}
		manager.Run(conf,csr)

	},
}

func initKafkaConfig() {
	// 查找配置
	if err := findConfigFile(&cfgPath,"kafka_consumer.yml"); err != nil {
		fmt.Println(err.Error())
		os.Exit(1)
	}
	if err := config_interface.Config.AddConfig(kafkaCfg); err != nil {
		fmt.Println(err.Error())
		os.Exit(1)
	}
}



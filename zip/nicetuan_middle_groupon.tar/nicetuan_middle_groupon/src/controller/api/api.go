package api

import (
	"github.com/gin-gonic/gin"
	"net/http"
	"nicetuan_middle_groupon/src/constant"
)



type Api struct {
}

func  ResponseSignErr(c *gin.Context)  {
	c.JSON(http.StatusOK, constant.Response{
		Code:constant.SIGN_FAIL,
		Msg:"验签验证失败",
	})
	c.Writer.CloseNotify()
}

func  ResponseParamErr(c *gin.Context,msg string)  {
	c.JSON(http.StatusOK, constant.Response{
		Code:constant.PARAMS_NULL,
		Msg:msg,
	})
	c.Writer.CloseNotify()
}

func (a Api) ResponseJsonErr(c *gin.Context,msg string)  {
	c.JSON(http.StatusOK, constant.Response{
		Code:constant.ResponseError,
		Msg:msg,
	})
	c.Writer.CloseNotify()
}

func (a Api) ResponseJson(c *gin.Context,data interface{})  {
	c.JSON(http.StatusOK, constant.Response{
		Code:constant.ResponseSuccess,
		Msg:"success",
		Data: data,
	})
}

func (a Api) ResponseJsonNoData(c *gin.Context,msg string)  {
	c.JSON(http.StatusOK, constant.Response{
		Code:constant.ResponseSuccess,
		Msg:msg,
	})
}

func (a Api) ResponseJsonMsg(c *gin.Context,data interface{},msg string)  {
	c.JSON(http.StatusOK, constant.Response{
		Code:constant.ResponseSuccess,
		Msg: msg,
		Data: data,
	})
}
package api

import (
	"github.com/gin-gonic/gin"
	"nicetuan_middle_groupon/src/dto/request"
	"nicetuan_middle_groupon/src/modules/log"
	"nicetuan_middle_groupon/src/service"
)

// AddLabel 增加 groupon_label 标签接口
func (a Api) AddLabel(param *request.AddLabel, serviceContext *service.ServiceContext,c *gin.Context)  {
	err := serviceContext.GetLabelService().Save(*param)
	if err != nil {
		a.ResponseJsonErr(c,err.Error())
		return
	}
	a.ResponseJsonNoData(c,"添加成功")
}


func (a Api) ChangeStatus(param *request.ChangeLabelStatus, serviceContext *service.ServiceContext,c *gin.Context)  {
	// 尽量不要暴露dao层到controller
	//err := serviceContext.GetLabelService().GrouponLabelDao.ChangeStatus(param.SaleLabelIds,param.Status)
	err := serviceContext.GetLabelService().ChangeStatus(param.SaleLabelIds,param.Status)
	if err != nil {
		a.ResponseJsonErr(c,"更新出错" + err.Error())
		log.LogOut.Error(c.Request.Context(),"change-label",param,err.Error())
		return
	}
	a.ResponseJsonNoData(c,"更新成功")
}

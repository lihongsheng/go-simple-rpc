package api

//
//func (api Api) BiwGroupon(param *dto.BiwGroupon,c *gin.Context) {
//	service := service2.BiwGroupon{}
//	service.WithContext(c.Request.Context())
//	list,err := service.BiwGrouponList(param)
//	if err != nil {
//		api.ResponseJsonErr(c,err.Error())
//	}
//	api.ResponseJson(c,list)
//	return
//}
package api

import (
	"fmt"
	"github.com/gin-gonic/gin"
	"nicetuan_middle_groupon/src/controller"
	"nicetuan_middle_groupon/src/dto/request"
	"nicetuan_middle_groupon/src/dto/response"
	"nicetuan_middle_groupon/src/modules/log"
	service "nicetuan_middle_groupon/src/service"
)
// GetGroupon 机器人分发 改名字
// 注入参数
// 注入需要的service
func (a Api) GetGroupon(param *request.GetGroupon, serviceContext *service.ServiceContext,c *gin.Context) {
	list,err := serviceContext.Groupon.GetGrouponList(param)

	if len(list) <= 0 {
		a.ResponseJson(c,make([]interface{},0))
		return
	}
	if err != nil {
		a.ResponseJsonErr(c,err.Error())
		return
	}
	gIds := make([]int,0)

	for _,v := range list {
		gIds = append(gIds,v.GrouponId)
	}

	ms,err := serviceContext.GrouponMerchandise.GrouponRobotMerchandise(gIds)
	if err != nil {
		a.ResponseJsonErr(c,err.Error())
		return
	}
	result := make([]response.RobotResponseGrouponAndMerchandise,0)
	for _,v := range list {
		r := response.RobotResponseGrouponAndMerchandise{}
		controller.FormatRobotGroupon(&r,v)
		controller.FormatRobotGrouponMerchandise(&r,ms)
		result = append(result,r)
	}
	a.ResponseJson(c,result)
	return
}

// GrouponMerchandise API 全国机器人分配-获取团购商品规格-规格对应站点价格对信息-对外API
func (a Api) GrouponMerchandise(param *request.RobotGrouponMerchandise, serviceContext *service.ServiceContext,c *gin.Context) {
	log.LogOut.Info(c.Request.Context(),"PARAM",param)
	merList,siteList,err := serviceContext.
		GrouponMerchandise.
		GetMerchandiseMerchtype(param.GrouponId,[]int{param.GetGrouponMerchandiseId()},true)
	if len(merList) <= 0 {
		fmt.Println("未查询到有效团商品信息")
		a.ResponseJsonMsg(c,make([]interface{},0),"未查询到有效团商品信息")
		return
	}
	if err != nil {
		a.ResponseJsonErr(c,err.Error())
		return
	}
	result := controller.FormatRobotGrouponMerchtypeAndSite(merList,siteList)
	a.ResponseJson(c,result)
	return
}

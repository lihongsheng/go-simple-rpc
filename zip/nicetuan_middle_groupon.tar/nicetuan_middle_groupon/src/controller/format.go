package controller

import (
	"nicetuan_middle_groupon/src/dto/entity"
	"nicetuan_middle_groupon/src/dto/response"
	"nicetuan_middle_groupon/src/model"
)
// dao -> entity/model -> dto -> vo
// service -> BO [dto,前端交互逻辑如业务上的判断] -> vo
// 转换service返回的结果集到 http.response

// FormatRobotGroupon 转换
func  FormatRobotGroupon(r *response.RobotResponseGrouponAndMerchandise,groupon model.Groupon)  {
	r.GrouponId = groupon.GrouponId
	r.CityId = groupon.CityId
	r.GrouponDate = groupon.GrouponDate.String()
	r.StartTime = groupon.StartTime
	r.EndTime = groupon.EndTime
	r.IsStop = groupon.IsStop
	r.GroupType = groupon.GroupType
}
// FormatRobotGrouponMerchandise 转换
func FormatRobotGrouponMerchandise(r *response.RobotResponseGrouponAndMerchandise,ms []entity.GrouponMerchandise)  {
	for _,v := range ms{
		if v.GrouponId == r.GrouponId {
			tmp := response.RobotResponseMerchandise{
				MerchandiseId: v.MerchandiseId,
				Title: v.Title,
				Coverimage: v.Coverimage,
				GrouponId: v.GrouponId,
				GrouponMerchandiseId: v.GrouponMerchandiseId,
			}
			r.GrouponMerchandise = append(r.GrouponMerchandise,tmp)
		}
	}
	if r.GrouponMerchandise == nil{
		r.GrouponMerchandise = make([]response.RobotResponseMerchandise,0)
	}
}
// FormatRobotGrouponMerchtypeAndSite 转换给机器人接口数据
func FormatRobotGrouponMerchtypeAndSite(merList []entity.GrouponMerchtype,siteList []model.GrouponMerchandiseSite) (result []response.RobotResponseGrouponMerchtypeAndSite){
	for _,m := range merList {
		merchtype := response.RobotResponseGrouponMerchtypeAndSite{
			MerchtypeId: m.MerchtypeId,
			GrouponMerchtypeId: m.GrouponMerchtypeId,
			MerchtypeName: m.MerchtypeName,
		}
		merchtype.MerchtypeSite = make([]response.RobotResponseGrouponMerchtypeSite,0)
		for _, site := range siteList {
			if site.GrouponMerchtypeId == m.GrouponMerchtypeId {
				merchtype.MerchtypeSite = append(merchtype.MerchtypeSite,response.RobotResponseGrouponMerchtypeSite{
					SiteId: site.SiteId,
					Price: site.Price,
					GrouponMerchandiseSiteId: site.GrouponMerchandiseSiteId,
				})
			}
		}
		result = append(result,merchtype)
	}
	return result
}
package rabbit

import (
	"context"
	"github.com/streadway/amqp"
	"nicetuan_middle_groupon/src/libaray/queue"
)

// rabbit的发送消息模式有四种
// direct 直连模式 ，推荐使用。支持路由的设置。此模式下一个exchange可以对应多个queue，而消息发送到那个queue是根据路由来匹配的
// topic 主题模式，支持路由的设置，且支持正则匹配的方式是匹配路由。其他与直连模式一样
// header模式 不推荐使用。基于header头里来匹配发送到那个queue。路由在此模式下无用
// pub/sub 发布订阅模式，路由建无用，消息发送到exchange下所有的queue

// rabbit 支持延迟消息需要设置过期时间和过期转移的exchange和路由键。所有一些需要延迟的消息可以使用rabbitMQ的延迟特性

// **********
// 看到这个sdk里是有起一个go，去维护链接的
// **********

// rabbit的channel是用来支持复用TCP链接的，也即是一个TCP链接上可以有多个channel

const (
	DIRECT = "direct"
	TOPIC = "topic"
	FANOUT = "fanout"
	HEADERS = "headers"
)

type Template struct {
	Encode func(v interface{}) []byte //消息编码
	Decode func(v []byte) string //消息解码
	Channel func() (amqp.Channel,error)

}

func (t Template) CreateDirectQueue(exchange string,route string,queue string) error  {
	return t.createQueue(exchange,route,queue,DIRECT)
}

func (t Template) createQueue(exchange string,route string,queue string,kind string) error  {
	ch,err := t.Channel()
	if (err!= nil) {
		return err
	}
	err = ch.ExchangeDeclare(exchange,kind,true,false,false,true,nil)
	_,err = ch.QueueDeclare(queue,true,false,false,true,nil)
	err = ch.QueueBind(queue,route,exchange,false,nil)
	return err
}

// Send 发送消息
func (t Template) Send(exchange string,router string,msg []byte) error {
	ch,err := t.Channel()
	if err!= nil {
		return err
	}
	return ch.Publish(exchange,router,false,false,amqp.Publishing{
		ContentType: "text/plain",
		Body:        msg,
		DeliveryMode: amqp.Persistent,
	})
}

// SendAndCovert 依据自定义的编码方法发送
func (t Template) SendAndCovert(exchange string,router string,msg interface{}) error {
	msgBody := t.Encode(msg)
	return t.Send(exchange,router,msgBody)
}

// DelayQueue 延迟队列
func (t Template) DelayQueue(second int, msg string, exchange string, routingKey string) error {
	ch,err := t.Channel()
	if (err != nil) {
		return err
	}
	queueName := "delay." + exchange + "." + routingKey + "." + string(second)
	exchangeName := "delay." + exchange
	// 自动创建延迟队列
	err = ch.ExchangeDeclare(exchangeName,DIRECT,true,false,false,true,nil)
	_,err = ch.QueueDeclare(queueName,true,false,false,true,amqp.Table{
		"x-message-ttl":second* 1000, // 延迟的时间
		"x-dead-letter-exchange":exchange, // 到达时间后转发的exchange
		"x-dead-letter-routing-key":routingKey,// 到达时间后转发的exchange的路由键
	})
	err = ch.QueueBind(queueName,queueName,exchangeName,true,nil)
	// 发布延迟消息
	return ch.Publish(exchangeName,queueName,false,false,amqp.Publishing{
		ContentType: "text/plain",
		Body:        []byte(msg),
		DeliveryMode: amqp.Persistent,
	})
}

// ReceiveAndCovert 接受消息
func (t Template) ReceiveAndCovert(queueName string,handler queue.ConsumerHandler) error {
	ch,err := t.Channel()
	if (err != nil) {
		return err
	}
	msgs,err := ch.Consume(queueName,"",false,false,false,false,nil)
	if (err != nil) {
		return err
	}
	for d := range msgs {
		body := d.Body
		msg := t.Decode(body)
		err := handler(queue.MessageInfo{
			Message: msg,
			Ctx: context.Background(),
			TraceId: "",
		})
		if (err != nil) {
			d.Ack(false)
		} else {
			d.Nack(false,true)
		}
	}
	return nil
}



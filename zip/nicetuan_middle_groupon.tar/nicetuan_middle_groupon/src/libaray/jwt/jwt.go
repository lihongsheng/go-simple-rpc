package jwt

import (
	"errors"
	jwtgo "github.com/dgrijalva/jwt-go"
	"nicetuan_middle_groupon/src/config"
	"time"
)


// GenerateToken 生成token
func GenerateToken(userToken config.UserToken,key string,expire int) (string,error) {
	nowTime := time.Now()
	expireTime := nowTime.Add(time.Duration(expire) * time.Second)
	// 到期时间
	userToken.IssuedAt = nowTime.Unix()
	userToken.ExpiresAt = expireTime.Unix()
	token := jwtgo.NewWithClaims(jwtgo.SigningMethodHS256, userToken)
	// 签署
	mySigningKey := []byte(key)
	tokenStr, err := token.SignedString(mySigningKey)
	if err != nil {
		return "", err
	}
	return tokenStr, nil
}

// ParseToken 返回token
func ParseToken(tokenStr string,key string) (*config.UserToken,error) {
	token, err := jwtgo.ParseWithClaims(tokenStr, &config.UserToken{}, func(token *jwtgo.Token) (interface{}, error) {
		return []byte(key), nil
	})
	if err != nil {
		return &config.UserToken{}, err
	}
	claims, ok := token.Claims.(*config.UserToken)
	err = errors.New("token")
	if !ok || !token.Valid {
		return claims, err
	}
	return claims, nil
}
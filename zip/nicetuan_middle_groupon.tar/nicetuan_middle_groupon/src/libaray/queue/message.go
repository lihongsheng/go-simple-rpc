package queue

import "context"

// 通用的队列消息处理类型

// ConsumerHandler 定义消费者类型
type ConsumerHandler func(message MessageInfoInterface) error

// MessageInfoInterface 消息体接口
type MessageInfoInterface interface {
	GetMessage() string
	GetContext() context.Context
	GetTraceId() string
}
// MessageInfo 消息实体
type MessageInfo struct {
	Message string
	Ctx context.Context
	TraceId string
}

func (m MessageInfo) GetMessage() string {
	return m.Message
}

func (m MessageInfo) GetContext() context.Context {
	return m.Ctx
}

func (m MessageInfo) GetTraceId() string {
	return m.TraceId
}
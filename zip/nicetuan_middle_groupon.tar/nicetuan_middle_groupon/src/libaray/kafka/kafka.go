package kafka

import (
	"errors"
	"fmt"
	"github.com/Shopify/sarama"
	"nicetuan_middle_groupon/src/libaray/pool"
)

var producerMap = &pool.ConnectMapPool{
	Factory: func(connectName string) (pool.CloseInterface, error) {
		newConfig := sarama.NewConfig()
		// 写到随机分区中，默认设置8个分区
		//newConfig.Producer.Partitioner = sarama.NewRandomPartitioner
		// 赋值为-1：这意味着producer在follower副本确认接收到数据后才算一次发送完成。
		newConfig.Producer.RequiredAcks = sarama.WaitForAll // Wait for all in-sync replicas to ack the message
		newConfig.Producer.Retry.Max = 10                   // Retry up to 10 times to produce the message
		newConfig.Producer.Return.Successes = true

		addStr,err := GetAddress(connectName)
		if err != nil {
			return nil,err
		}
		// 生成同步发送消息 对象
		client, cliErr := sarama.NewSyncProducer(addStr, newConfig)
		if cliErr != nil {
			return nil,errors.New("not find config by" + connectName)
		}
		fmt.Println("connect kafka success")
		return client,nil
	},
}

// SendMsg 发消息到kafka
// 修改 不必每次关闭链接，原因如下。
// see https://github.com/Shopify/sarama/blob/master/examples/http_server/http_server.go#L45
// see https://github.com/Shopify/sarama/blob/master/examples/http_server/http_server.go#L83
// see https://github.com/Shopify/sarama/blob/master/examples/http_server/http_server.go#L113
// see https://github.com/Shopify/sarama/blob/master/examples/http_server/http_server.go#L122
// see https://github.com/Shopify/sarama/blob/master/examples/http_server/http_server.go#L190
// SendMsg 发送消息
// connectName config.yml下的kafka的配置
// 返回发送的分区，当前消息的偏移量，发送是否发生错误
func SendMsg(connectName string,topic, message string) (partition int32,offset int64,err error) {
	// 获取发送消息客户端
	client, cliErr := producerMap.Get(connectName)
	if cliErr != nil {
		// 删除 ，外部重试的时候，重新建立新的链接
		producerMap.Delete(connectName)
		return 0,0,cliErr
	}
	clt := client.(sarama.SyncProducer)
	// 设置 sarama 独有的消息体
	msg := sarama.ProducerMessage{}
	msg.Topic = topic
	msg.Value = sarama.StringEncoder(message)

	partition,offset, err = clt.SendMessage(&msg)
	if err != nil {
		// 删除 ，外部重试的时候，重新建立新的链接
		producerMap.Delete(connectName)
		return 0,0,err
	}
	return partition,offset, err
}

// SendMsgTry 带有重试的发送队列
func SendMsgTry(connectName string,topic, message string,try int) (partition int32,offset int64,err error) {
	for try > 0 {
		try--
		partition,offset,err = SendMsg(connectName,topic,message)
		if err == nil {
			return partition,offset,err
		}
	}
	return partition,offset,err
}



// Close 关闭所有链接
func Close() {
	producerMap.Close()
}


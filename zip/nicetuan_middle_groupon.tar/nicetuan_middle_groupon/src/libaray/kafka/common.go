package kafka

import (
	"errors"
	"nicetuan_middle_groupon/src/config"
	"nicetuan_middle_groupon/src/libaray/config_interface"
	"strconv"
)

func GetAddress(connectName string) ([]string,error)  {
	// 格式化地址
	address := make([]config.Kafka,3)
	config_interface.Config.UnmarshalKey("kafka." + connectName ,&address)
	if len(address) <= 0 {
		return nil,errors.New("not find config by" + connectName)
	}
	addStr := make([]string,3)
	for _,v :=range address {
		addStr = append(addStr,v.Host + ":" + strconv.Itoa(v.Port))
	}
	return addStr,nil
}

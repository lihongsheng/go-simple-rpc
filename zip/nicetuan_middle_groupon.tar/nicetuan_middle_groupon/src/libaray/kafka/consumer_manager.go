package kafka

import (
	"context"
	"fmt"
	"github.com/Shopify/sarama"
	"nicetuan_middle_groupon/src/libaray/queue"
	"nicetuan_middle_groupon/src/modules/kafka"
	"nicetuan_middle_groupon/src/modules/log"
	"os"
	"sync"
	"time"
)

// consumer manager 管理消费者

type ConsumerManager struct {
	consumerHandler queue.ConsumerHandler
	conf            kafka.Conf
}

func (c *ConsumerManager) Run(conf kafka.Conf, consumerHandler queue.ConsumerHandler) {
	c.consumerHandler = consumerHandler
	c.conf = conf
	addr,err := GetAddress(c.conf.Connect)
	if err != nil {
		fmt.Println("not find config by" + c.conf.Connect)
		os.Exit(1)
	}
	if len(addr) <= 0 {
		fmt.Println("not find config by" + c.conf.Connect)
		os.Exit(1)
	}

	// 生成sarama 的kafka 配置
	config := sarama.NewConfig()
	config.Consumer.Offsets.Initial = sarama.OffsetOldest
	config.Consumer.Group.Rebalance.Strategy = sarama.BalanceStrategyRange
	//config.Consumer.Fetch.Default = 8 * 1024 * 1024
	config.Consumer.Return.Errors = true
	config.Net.DialTimeout = 10 * time.Second
	config.Net.ReadTimeout = 10 * time.Second
	config.Net.WriteTimeout = 10 * time.Second
	config.Consumer.Group.Rebalance.Timeout = 10 * time.Second
	// 自动提交,sarama 默认自动提交，【组模式不支持不自动提交，测试发现】
	//if !c.conf.AutoCommit && c.conf.GroupId == ""  {
	//	config.Consumer.Offsets.AutoCommit.Enable = false
	//} else {
	//	config.Consumer.Offsets.AutoCommit.Enable = true
	//}
	// 组模式
	if c.conf.GroupId != "" {
		c.groupMode(addr,config)
	}
	panic("must is groupMode")

}

// 组模式提交
func (c *ConsumerManager) groupMode(addr []string, config *sarama.Config) {
	ctx, cancel := context.WithCancel(context.Background())
	// group_id 为空则退出
	// 使用组模式，如果有新增的 分区，组模式可以自动调节并消费新的分区
	// 这个是 sarama 包要求的接口实现，用来处理消息
	handler := &ConsumerGroupHandle{KafkaHandler: c.consumerHandler, Ctx: ctx}
	// 等消费者go启动
	wg := &sync.WaitGroup{}
	wg.Add(1)
	// sarama 自动根据分区，建立go
	// see https://github.com/Shopify/sarama/blob/master/consumer_group.go#L171
	// see https://github.com/Shopify/sarama/blob/master/consumer_group.go#L339
	// see https://github.com/Shopify/sarama/blob/master/consumer_group.go#L591
	// see https://github.com/Shopify/sarama/blob/master/consumer_group.go#L655 根据topic 下的分区数量建立go去消费
	go func() {
		defer wg.Done()
		// 创建消费组
		client, err := sarama.NewConsumerGroup(addr, c.conf.GroupId, config)
		if err != nil {
			panic("init fail error : " + err.Error())
		}

		for {
			// 实际消费数据
			err = client.Consume(ctx, []string{c.conf.Topic}, handler)
			if err != nil {
				fmt.Println("init fail error : " + err.Error())
				log.LogOut.Error(ctx, "kafka-"+c.conf.Topic, err.Error())
				return
			}
			if ctx.Err() != nil {
				fmt.Println("init fail error : " + ctx.Err().Error())
				log.LogOut.Error(ctx, "kafka-"+c.conf.Topic, err.Error())
				return
			}
		}
	}()

	wg.Wait()
	// 告诉 kafka 取消消费者
	cancel()

}

// 单连 分区消费，占时未找到 提交偏移量的方式
//func kafka3(sonsumerKey string) {
//	fmt.Println(";;;1;;;")
//	config := sarama.NewConfig()
//	config.Consumer.Offsets.Initial = sarama.OffsetOldest
//	config.Consumer.Offsets.AutoCommit = struct {
//		Enable   bool
//		Interval time.Duration
//	}{Enable: true, Interval: time.Second }
//	con,err := sarama.NewConsumer([]string{"127.0.0.1:9092"},config)
//	if err != nil {
//		fmt.Println(err.Error())
//	}
//	pc, err := con.ConsumePartition("test",0,sarama.OffsetOldest)
//	pc.HighWaterMarkOffset()
//	// 运行完毕记得关闭
//	defer pc.AsyncClose()
//	if err != nil {
//		fmt.Println(err.Error())
//	}
//
//	for msg := range pc.Messages(){
//
//		fmt.Printf("ConsumeKey:%s Partition:%d Offset:%d Key:%v Value:%s \n", sonsumerKey,msg.Partition, msg.Offset, msg.Key, string(msg.Value))
//	}
//}



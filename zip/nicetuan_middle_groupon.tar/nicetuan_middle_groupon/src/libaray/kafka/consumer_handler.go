package kafka

import (
	"context"
	"fmt"
	"github.com/Shopify/sarama"
	"nicetuan_middle_groupon/src/libaray/queue"
	"nicetuan_middle_groupon/src/modules/kafka"
	"nicetuan_middle_groupon/src/modules/log"
	"nicetuan_middle_groupon/src/util"
)

type ConsumerGroupHandle struct {
	KafkaHandler queue.ConsumerHandler
	Conf kafka.Conf
	Ctx context.Context
}

// Setup is run at the beginning of a new session, before ConsumeClaim
func (consumer *ConsumerGroupHandle) Setup(sarama.ConsumerGroupSession) error {
	// Mark the consumer as ready
	return nil
}

// Cleanup is run at the end of a session, once all ConsumeClaim goroutines have exited
func (consumer *ConsumerGroupHandle) Cleanup(sarama.ConsumerGroupSession) error {
	return nil
}

// ConsumeClaim must start a consumer loop of ConsumerGroupClaim's Messages().
func (consumer *ConsumerGroupHandle) ConsumeClaim(session sarama.ConsumerGroupSession, claim sarama.ConsumerGroupClaim) error {
	// NOTE:
	// Do not move the code below to a goroutine.
	// The `ConsumeClaim` itself is called within a goroutine, see:
	// https://github.com/Shopify/sarama/blob/master/consumer_group.go#L27-L29
	for message := range claim.Messages() {
		// 处理消息
		fmt.Printf(" Partition:%d Offset:%d Key:%v Value:%s ::::GO::::::: \n",message.Partition, message.Offset, message.Key, string(message.Value))
		// 生成消息实体
		TraceId := util.GenerateTraceId()
		ctx := context.WithValue(context.Background(),"trace_id",TraceId)
		msg := queue.MessageInfo{
			Message: string(message.Value),
			Ctx: ctx,
			TraceId: TraceId,
		}
		// 具体执行消息处理的 handler
		err := consumer.KafkaHandler(msg)
		// 如果返回错误，不提交偏移量
		if err != nil {
			// 记录日志
			log.LogOut.Error(ctx,"kafka-"+consumer.Conf.Topic,err.Error())
			//session.Context().Done()
			// 抛出异常
			panic(err.Error())
			return err
		}
		// 提交偏移量
		session.MarkMessage(message,"")
	}

	return nil
}

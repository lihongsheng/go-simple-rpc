package pool_test

import (
	"errors"
	"github.com/streadway/amqp"
	"nicetuan_middle_groupon/src/libaray/pool"
	"strconv"
	"sync"
	"testing"
	"time"
)

func TestPool(t *testing.T) {
	connect,err := amqp.Dial("amqp://guest:guest@localhost:5672/")
	if err != nil {
		t.Log("测试rabbitmq无法打开，无法测试")
		t.SkipNow()
		return
	}
	connect.Close()

	c := &pool.Config{
		MaxIdleConn: 10,
		MaxOpenConn: 20,
		Factory: func() (interface{}, error) {
			return amqp.Dial("amqp://guest:guest@localhost:5672/")
		},
		Close: func(i interface{}) error {
			c := i.(*amqp.Connection)
			return c.Close()
		},
		Ping: func(i interface{}) error {
			c := i.(*amqp.Connection)
			if c.IsClosed() {
				return errors.New("链接已经关闭")
			}
			return nil
		},
		IdleTimeout: 60 * time.Second,
		WaitTime: 3 * time.Second,
	}
	p,err := pool.NewPool(c)
	if (err != nil) {
		t.Error("打开连接池失败")
		return
	}
	wg := sync.WaitGroup{}
	wg.Add(30)
	for i := 0; i < 30; i++ {
		go func(goIndex int) {
			defer wg.Done()
			indeCount := 0
			for {
				if indeCount > 100 {
					break
				}
				con, errs := p.Get()
				goIndexStr := strconv.Itoa(goIndex)
				if (errs != nil) {
					t.Log(errs.Error() + ":获取链接出错" + "realCount:" + strconv.Itoa(p.GetRealConCount()) +"index:" + goIndexStr + ":channel:"+ strconv.Itoa(p.GetChannelCount()) + ":con:" + strconv.Itoa(p.GetConCount()))
					continue
				}
				amqpCon := con.Get().(*amqp.Connection)
				ch, err := amqpCon.Channel()
				if err != nil {
					if ch != nil {
						ch.Close()
					}
					amqpCon.Close()
					t.Log("生成channel出错" + goIndexStr)
					continue
				}
				body := "{\"goIndex\":" + goIndexStr + ",\"time\":\"" + time.Now().Format("2006-01-02 15:04:05") + "\"}"
				ch.Publish("test", "test", false, false, amqp.Publishing{
					ContentType: "text/plain",
					Body:        []byte(body),
				})
				ch.Close()
				p.Put(con)
				time.Sleep(time.Second)
				t.Log(body)
			}
		}(i)
	}
	wg.Wait()
	con, errs := p.Get()
	if (errs != nil) {
		t.Log(errs.Error() + ":获取链接出错")
	}
	amqpCon := con.Get().(*amqp.Connection)
	ch, err := amqpCon.Channel()
	if err != nil {
		if ch != nil {
			ch.Close()
		}
		amqpCon.Close()
		t.Log("生成channel出错")
	}
	ch.Consume("test","",true,false,false,false,nil)

}

//c := &pool.Config{
//	MaxIdleConn: 10,
//	MaxOpenConn: 20,
//	Factory: func() (interface{}, error) {
//		return amqp.Dial("amqp://guest:guest@localhost:5672/")
//	},
//	Close: func(i interface{}) error {
//		c := i.(*amqp.Connection)
//		return c.Close()
//	},
//	Ping: func(i interface{}) error {
//		c := i.(*amqp.Connection)
//		if c.IsClosed() {
//			return errors.New("链接已经关闭")
//		}
//		return nil
//	},
//	IdleTimeout: 5 * time.Second,
//	WaitTime: 3 * time.Second,
//}
//p,err := pool.NewPool(c)
//if (err != nil) {
//	fmt.Println(err.Error())
//}
//
//wg := sync.WaitGroup{}
//wg.Add(30)
//for i := 0; i < 30; i++ {
//	go func(goIndex int) {
//		defer wg.Done()
//		indexCount  := 0
//		for {
//			if indexCount > 10 {
//				return
//			}
//			indexCount++
//
//			con, errs := p.Get()
//			goIndexStr := strconv.Itoa(goIndex)
//			if (errs != nil) {
//				fmt.Println(errs.Error() + ":获取链接出错" + "realCount:" + strconv.Itoa(p.GetRealConCount()) +"index:" + goIndexStr + ":channel:"+ strconv.Itoa(p.GetChannelCount()) + ":con:" + strconv.Itoa(p.GetConCount()))
//				fmt.Println(con)
//				continue
//			}
//			amqpCon := con.Get().(*amqp.Connection)
//			ch, err := amqpCon.Channel()
//			if err != nil {
//				fmt.Println("生成channel出错" + goIndexStr)
//			}
//			body := "{\"goIndex\":" + goIndexStr + ",\"time\":\"" + time.Now().Format("2006-01-02 15:04:05") + "\"}"
//			ch.Publish("test", "test", false, false, amqp.Publishing{
//				ContentType: "text/plain",
//				Body:        []byte(body),
//			})
//			ch.Close()
//			p.Put(con)
//			//time.Sleep(time.Second)
//			fmt.Println(body)
//		}
//	}(i)
//}
//wg.Wait()
//
//time.Sleep(10*time.Second)
//fmt.Println("休眠十秒后看看，链接是否关闭")
//time.Sleep(3*time.Second)
//wg.Add(30)
//for i := 0; i < 30; i++ {
//	go func(goIndex int) {
//		defer wg.Done()
//		indexCount := 0
//		for {
//			if indexCount > 10 {
//				return
//			}
//			indexCount++
//			con, errs := p.Get()
//			goIndexStr := strconv.Itoa(goIndex)
//			if (errs != nil) {
//				fmt.Println(errs.Error() + ":获取链接出错" + "realCount:" + strconv.Itoa(p.GetRealConCount()) +"index:" + goIndexStr + ":channel:"+ strconv.Itoa(p.GetChannelCount()) + ":con:" + strconv.Itoa(p.GetConCount()))
//				fmt.Println(con)
//				continue
//			}
//			amqpCon := con.Get().(*amqp.Connection)
//			ch, err := amqpCon.Channel()
//			if err != nil {
//				fmt.Println("生成channel出错" + goIndexStr)
//			}
//			body := "{\"goIndex\":" + goIndexStr + ",\"time\":\"" + time.Now().Format("2006-01-02 15:04:05") + "\"}"
//			ch.Publish("test", "test", false, false, amqp.Publishing{
//				ContentType: "text/plain",
//				Body:        []byte(body),
//			})
//			ch.Close()
//			p.Put(con)
//			//time.Sleep(time.Second)
//			fmt.Println(body)
//		}
//	}(i)
//}
//wg.Wait()
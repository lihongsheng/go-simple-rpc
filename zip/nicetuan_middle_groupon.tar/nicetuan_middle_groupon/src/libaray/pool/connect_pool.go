package pool

import (
	"errors"
	"fmt"
	"strconv"
	"sync"
	"time"
)

// 此连接池未使用排队机制，检测到channel为0的时候，会等待超时间，
// 然后再次轮询channel检测是否归返连接，如果没有归返连接，报超时错误。
// 使用channel来控制并发创建链接的数目，使用双链表来控制链接的排队最早使用的放在队头
var (
	MaxConnErr = errors.New("超过最大链接数")
	ClosedErr  = errors.New("连接池已经关闭")
)

// Config 连接池相关配置
type Config struct {
	//最大空闲连接
	MaxIdleConn int
	//最大并发存活连接数
	MaxOpenConn int
	//生成连接的方法
	Factory func() (interface{}, error)
	//关闭连接的方法
	Close func(interface{}) error
	//检查连接是否有效的方法
	Ping func(interface{}) error
	//连接最大空闲时间，超过该事件则将失效
	IdleTimeout time.Duration
	WaitTime    time.Duration
	IsLive      bool // 是否保持活跃，ture 会另起一个go来维持链接的ping操作，确认链接是否存活
}

type Pool struct {
	config    *Config
	con       chan struct{}
	closed    bool
	openCount int
	idle      IdleList
	l         sync.Mutex
}

// NewPool 建立连接池
func NewPool(config *Config) (*Pool, error) {
	if config.MaxIdleConn <= 0 || config.MaxOpenConn < config.MaxIdleConn {
		return nil, errors.New("参数设置错误，最大连接数应该大于最大空闲连接数")
	}
	if config.IsLive && config.Ping == nil {
		return nil, errors.New("参数设置错误，Islive true,ping must set")
	}
	if config.Factory == nil || config.Close == nil {
		return nil, errors.New("参数设置错误，Factory and close must set")
	}

	p := &Pool{
		config: config,
		con:    make(chan struct{}, config.MaxOpenConn),
		idle:   IdleList{},
		openCount: 0,
	}
	for i := 0; i < config.MaxIdleConn; i++ {
		p.con <- struct{}{}
	}
	p.closed = false
	// 未开启
	//if (config.IsLive && config.Ping != nil) {
	//	go p.ping()
	//}
	return p, nil
}

// Get 获取链接
func (p *Pool) Get() (*poolConnect, error) {
	if p.closed {
		return nil, ClosedErr
	}

	if len(p.con) <= 0 {
		// 超时等等
		fmt.Println("超时等等------" + "::真实链接::" + strconv.Itoa(p.GetRealConCount()))
		<-time.After(p.config.WaitTime)
	}
	select {
	case <-p.con:
		return p.dial()
	default:
		if len(p.con) <= 0 {
			return nil, MaxConnErr
		}
		return p.dial()
	}

}

// dial 生成链接
func (p *Pool) dial() (*poolConnect, error) {
	p.l.Lock()
	if p.config.IdleTimeout > 0 && p.idle.last != nil && p.idle.last.t.Add(p.config.IdleTimeout).Before(time.Now()) {
		fmt.Println("关闭链接开始---:::::::::::::---" + strconv.Itoa(p.openCount))
		for p.idle.last != nil && p.idle.last.t.Add(p.config.IdleTimeout).Before(time.Now())  {
			pc := p.idle.popBack()
			if pc != nil {
				fmt.Println("关闭链接---:::::::::::::---" + strconv.Itoa(p.openCount))
				p.config.Close(pc.con)
				p.openCount--
			}
		}
	}
	for p.idle.head != nil {
		pc := p.idle.popHead()
		// 探测链接是否可用
		if pc != nil && p.config.Ping(pc.con) == nil {
			p.l.Unlock()
			fmt.Println("返回有效链接---************---" + "::真实链接::" + strconv.Itoa(p.GetRealConCount()))
			return pc, nil
		}
		// 关闭不可用链接
		p.config.Close(pc.con)
		p.openCount--
		fmt.Println("关闭失效链接---************---" + strconv.Itoa(p.openCount))
	}
	p.openCount++
	con, err := p.config.Factory()
	if err != nil {
		p.openCount--
		if p.con != nil && !p.closed {
			p.con <- struct{}{}
			return nil, err
		}
	}
	p.l.Unlock()
	fmt.Println("创建链接------" + strconv.Itoa(p.GetRealConCount()))
	return &poolConnect{con: con, t: time.Now(), create: time.Now()}, nil

}

// Put 归返对象链接
func (p *Pool) Put(pc *poolConnect) {
	if p.closed {
		// 连接池关闭，把归返的链接关闭
		if pc.con != nil {
			p.config.Close(pc.con)
		}
		return
	}
	p.l.Lock()
	pc.t = time.Now()
	p.idle.put(pc)
	if p.con != nil {
		p.con <- struct{}{}
	}
	p.l.Unlock()
	fmt.Println("归还链接-------" + strconv.Itoa(len(p.con)) + "::::" + strconv.Itoa(p.GetRealConCount()))
}

// ping 单独起协程,维护链接活跃性
func (p *Pool) ping() {
	if !(p.config.IsLive && p.config.IdleTimeout > 0) {
		return
	}
	for {
		select {
		case <-time.After(p.config.IdleTimeout):
			if p.closed || p.openCount < p.config.MaxIdleConn {
				return
			}
			p.l.Lock()
			if p.config.IdleTimeout > 0 && p.openCount > 0 {
				pc := p.idle.popBack()
				for i := 0; i < p.openCount && pc != nil && pc.t.Add(p.config.IdleTimeout).Before(time.Now()); i++ {
					p.config.Close(pc.con)
					pc = p.idle.popBack()
					p.openCount--
				}
			}
			p.l.Unlock()
		default:
			if p.closed {
				return
			}

		}

	}
}

func (p *Pool) Release() {
	if p.closed {
		return
	}
	p.l.Lock() // 加锁
	// 双检测，防止获取到锁的时候，p.closed已被别的协程置位TRUE
	if p.closed {
		p.l.Unlock()
		return
	}
	p.closed = true
	close(p.con)
	for range p.con {
	}
	for p.idle.head != nil {
		pc := p.idle.popHead()
		p.config.Close(pc.con)
		pc.next = nil
		pc.prev = nil
	}
	p.openCount = 0
	p.l.Unlock()
}

// GetChannelCount 获取channel长度
func (p *Pool) GetChannelCount() int {
	return len(p.con)
}

func (p *Pool) GetConCount() int {
	return p.openCount
}

// GetRealConCount 当前实际链接长度
func (p *Pool) GetRealConCount() int {
	return p.idle.GetListLength()
}

func (p *Pool) Close(pc *poolConnect) (err error) {
	if p.closed {
		// 连接池关闭，把归返的链接关闭
		if pc != nil && pc.con != nil {
			p.config.Close(pc.con)
		}
		return nil
	}
	pc.prev = nil
	pc.next = nil
	p.l.Lock()
	p.openCount--
	err = p.config.Close(pc.con)
	p.l.Unlock()
	if p.con != nil {
		p.con <- struct{}{}
	}
	return err
}

// 存储 实际链接
type poolConnect struct {
	con        interface{}
	t          time.Time
	create     time.Time
	next, prev *poolConnect
}

// Get 获取实际链接
func (p *poolConnect) Get() interface{} {
	return p.con
}

// IdleList 双向列表来保存链接
type IdleList struct {
	count int
	head, last *poolConnect
}

// put 压入头部
func (l *IdleList) put(pc *poolConnect) {
	pc.next = l.head
	pc.prev = nil
	if l.head == nil && l.last == nil {
		l.head = pc
		l.last = pc
	} else {
		l.head.prev = pc
		l.head = pc
	}
	l.count++
}

// popHead 弹出头部
func (l *IdleList) popHead() *poolConnect {
	if l.head == nil {
		return nil
	}
	pc := l.head
	l.count--
	if pc.next !=nil {
		pc.next.prev = nil
	} else {
		l.last = nil
	}
	l.head = pc.next
	pc.next, pc.prev = nil, nil
	return pc
}

// popBack 弹出尾部
func (l *IdleList) popBack() *poolConnect {
	if l.last == nil {
		return nil
	}
	pc := l.last
	l.count--
	if pc.prev != nil {
		pc.prev.next = nil
	} else {
		l.head = nil
	}
	l.last = pc.prev
	pc.next, pc.prev = nil, nil
	return pc
}

// GetListLength 获取实际长度
func (l *IdleList) GetListLength() int {
	return l.count
}

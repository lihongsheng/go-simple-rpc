package pool
// 这个map存储的是连接池对象，而不是单独的链接，所以对于不同的connect只存储一个map映射
import (
	"sync"
)

// CloseInterface 定义Factory 生成的必须Close函数
type CloseInterface interface {
	Close() error
}


// ConnectMapPool 固定映射池子，不做自动激活操作
type ConnectMapPool struct {
	Factory func(connectName string) (CloseInterface,error)
	connect map[string]CloseInterface
	lock sync.Mutex
}

// Get 获取链接对象
func (c *ConnectMapPool) Get(connectName string) (CloseInterface,error) {
	// 如果已经存在
	if _,exit := c.connect[connectName]; exit {
		return c.connect[connectName],nil
	}
	con,err := c.GenerateFactory(connectName)
	if err != nil {
		return nil,err
	}
	return con,nil
}

// GenerateFactory 生成，重新生成
func (c *ConnectMapPool) GenerateFactory(connectName string)  (CloseInterface,error) {
	c.lock.Lock()
	defer c.lock.Unlock()
	// 重新生成
	if _,exit := c.connect[connectName]; exit {
		 delete(c.connect,connectName)
	}
	// 第一次初始化内存
	if len(c.connect) <= 0 {
		c.connect = make(map[string]CloseInterface)
	}
	// 生成新的对象
	con,err := c.Factory(connectName)
	c.connect[connectName] = con
	return c.connect[connectName],err
}

// Delete 删除
func (c *ConnectMapPool)  Delete(connectName string)  {
	// 如果已经删除
	if _,exit := c.connect[connectName]; !exit {
		return
	}

	c.lock.Lock()
	defer c.lock.Unlock()
	// 获取到锁的时候，已经被删除
	if _,exit := c.connect[connectName]; !exit {
		return
	}
	c.connect[connectName].Close()
	delete(c.connect,connectName)
}

// Close 关闭所有链接
func (c *ConnectMapPool) Close() {
	c.lock.Lock()
	defer c.lock.Unlock()
	// 循环遍历关闭所有的链接
	for k,v := range c.connect{
		v.Close()
		delete(c.connect,k)
	}
}

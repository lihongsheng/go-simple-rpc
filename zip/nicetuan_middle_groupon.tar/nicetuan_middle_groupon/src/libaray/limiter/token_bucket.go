package limiter
// 令牌桶
import (
	"math"
	"sync"
	"time"
)

type TokenBucket struct {
	Capacity int // 桶容量
	Rate int // 速率
	TimestampKey int64 // 上次生成token的时间
	LastTokens int // 最后一次的剩余的令牌桶数目
	FillTime int // 填充
	lock sync.Mutex
}
// NewTokenBucket 生成管控的速率
func NewTokenBucket(capacity int,rate int) *TokenBucket {
	return &TokenBucket{
		Capacity: capacity,
		Rate: rate,
		LastTokens: capacity/rate,
		FillTime: capacity/rate, // 填充时间速率比
	}
}
// Allow 判断是否允许访问
func (t *TokenBucket) Allow(reqNum int,reqTime int64) bool  {
	defer t.lock.Unlock()
	t.lock.Lock()
	// 时间差
	now := time.Now().Unix()
	delta := math.Max(0,float64(reqTime - t.TimestampKey))
	delTime := int(delta)
	// 基于时间差和填充比 算出时间差内的应该填充的令牌桶
	t.LastTokens = int(math.Min(float64(t.Capacity),float64(t.LastTokens) + float64(delTime * t.FillTime)))
	allow := false
	if t.LastTokens >= reqNum {
		allow = true
	}
	t.LastTokens = t.LastTokens - reqNum
	t.TimestampKey = now
	return allow
}

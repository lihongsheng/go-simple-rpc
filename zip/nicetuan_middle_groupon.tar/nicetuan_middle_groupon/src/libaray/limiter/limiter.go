package limiter

type LimitInterface interface {
	 Allow(reqNum int,reqTime int64) bool
}

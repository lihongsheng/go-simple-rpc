package limiter

import (
	"math"
	"sync"
	"time"
)

// 滑动窗口算法
/**
 第一个窗口
*  - |- - - - |
第二个窗口
   - - |- - - - |
 */
// 使用循环数组实现滑动窗口

type SlidingWindow struct {
	IntervalInMs time.Duration // 最大间隔时间
	SampleCount int // 最大间隔时间的统计次数 ，也就是 IntervalInMs/SampleCount 时间单位内作为统计的时间间隔，也即是窗口数
	RateTime int
	Windows []int // 窗口数 有IntervalInMs/SampleCount的出
	MaxReqNum int
	headIndex int // 队列的头部
	lastIndex int // 队列的尾部
	lastTime int64
	lock sync.Mutex
	realLength int
}

func NewSlidingWindow(intervalInMs time.Duration, sampleCount int,maxReqNum int) *SlidingWindow  {
	return &SlidingWindow{
		MaxReqNum: maxReqNum,
		IntervalInMs: intervalInMs,
		SampleCount: sampleCount,
		Windows: make([]int,intervalInMs.Milliseconds()/int64(sampleCount)),
		RateTime: int(intervalInMs.Milliseconds()/int64(sampleCount)),
	}
}

func (s *SlidingWindow) Allow(reqNum int,reqTime int64)  {
	s.lock.Lock()
	s.Windows[s.lastIndex] += reqNum

}

func (s *SlidingWindow) setIndex(reqTime int64)  {
	// 说明是第一次请求
	if s.lastTime <= 0 {
		s.lastTime = reqTime
		s.headIndex = 0
		s.lastIndex = 0
		s.realLength = 1
		return
	}
	// 非第一次请求
	diffTime := int(reqTime - s.lastTime)
	skip := int(math.Ceil(float64(diffTime)/float64(s.RateTime)))
	if skip == 0 {
		return
	}
	if skip >= s.SampleCount {
		s.lastTime = reqTime
		s.headIndex = 0
		s.lastIndex = 0
		s.realLength = 1
		return
	}
	// 第一种情况
	// headIndex = 0,lastIndex = 0
	// lastIndex + skip < SampleCount
	// 第二种情况
	// headIndex = 0,lastIndex != 0
	// lastIndex + skip < SampleCount
	// 第三种情况
	// headIndex = 0,lastIndex != 0
	// lastIndex + skip > SampleCount
	// 第四种情况
	// headIndex != 0,lastIndex != 0
	// lastIndex + skip < headIndex
	// 第五种情况
	// headIndex != 0,lastIndex != 0
	// lastIndex + skip > headIndex

	if s.realLength + skip <= s.SampleCount {
		s.realLength = s.realLength + skip
		if s.lastIndex >= s.headIndex && (s.lastIndex + skip) <= (s.SampleCount  - 1) {
			s.lastIndex = s.lastIndex + skip
		}
		if s.lastIndex >= s.headIndex && (s.lastIndex + skip) > (s.SampleCount  - 1) {
			s.lastIndex = s.lastIndex + skip + 1 - s.SampleCount
			tmp := s.lastIndex + 1
			for tmp > 0 {
				tmp--
				s.Windows[s.headIndex] = 0
				s.headIndex++
			}
		}
	}


}
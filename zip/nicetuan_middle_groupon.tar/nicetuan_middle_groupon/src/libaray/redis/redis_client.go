package redis

import (
	"github.com/go-redis/redis/v8"
	"sync"
)

var client map[string]*redis.Client
var lock sync.Mutex

func BuildClient(redisConnectName string) *redis.Client  {
	if val,exit := client[redisConnectName]; exit {
		return val
	}
	lock.Lock()
	if val,exit := client[redisConnectName]; exit {
		lock.Unlock()
		return val
	}
	// 获取redisConnectName配置
	// 生成信息
	// 设置client
	// 返回链接
	//rdb := redis.NewClient()
	return nil
}


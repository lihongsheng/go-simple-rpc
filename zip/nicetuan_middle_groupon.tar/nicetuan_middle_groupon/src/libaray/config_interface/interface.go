package config_interface


type ConfigInterface interface {
	// InitConfig 初始化加载配置
	InitConfig(filepath string) error
	AddConfig(filepath string) error
	Get(node string) interface{}
	GetBool(node string) bool
	GetInt(node string) int
	GetString(node string) string
	GetMap(node string) map[string]interface{}
	GetStringSlice(node string) []string
	getNodeStruct(node string,tag string,target interface{}) error // 有问题
	Unmarshal(param interface{}) error
	UnmarshalKey(node string,param interface{}) error
	// Watch 为以后使用 etcd等留下接口观察节点变化做通知准备
	Watch(node string,callback func(interface{}))

}

package main

import "fmt"

func main() {
	var slice [][]int
	slice = [][]int{
		{1},
		{3},
		{5},
	}
	fmt.Println(prt(slice))
	fmt.Println("-----------------")
}

func prt(slice [][]int) []int {
	height := len(slice)
	width :=  len(slice[0])
	sl := make([]int,0)
	heightLength := height / 2
	widthLength  := width / 2
	if height%2 != 0 {
		heightLength++
	}
	if width%2 != 0 {
		widthLength++
	}

	x := 0
	y := 0

	h := 0
	w := 0
	for  {
		yy := y
		xx := x
		for yy < (width - w) {
			sl = append(sl,slice[xx][yy])
			yy++
		}
		yy--
		for xx++; xx < (height - h);xx++ {
			sl = append(sl,slice[xx][yy])

		}
		xx--
		fmt.Println(xx)
		for ;yy > y;  {
			yy--
			sl = append(sl,slice[xx][yy])
		}

		for xx > (x+1)   {
			xx--
			sl = append(sl,slice[xx][yy])
		}
		fmt.Println(yy)
		return sl
		x++
		y++
		if h < heightLength {
			h++
		}
		if w < widthLength {
			w++
		}
		if h == heightLength   && w == widthLength  {
			break
		}
	}
	return sl
}

func sortArray(nums []int) []int {
	if len(nums) <= 1 {
		return nums
	}
	quick(nums, 0, len(nums)-1)
	return nums
}

func quick(nums []int, left int, right int) {
	if left < right {
		cen := mid(nums, left, right)
		quick(nums, left, cen)
		quick(nums, cen+1, right)
	}

}

func mid(nums []int, left int, right int) int {
	leftStart := left
	m := nums[left]
	for {
		for leftStart < right && nums[right] >= m {
			right--
		}
		for leftStart < right && nums[leftStart] <= m {
			leftStart++
		}
		if leftStart >= right {
			break
		}
		tmp := nums[leftStart]
		nums[leftStart] = nums[right]
		nums[right] = tmp
	}
	nums[left] = nums[right]
	nums[right] = m
	return right
}

# nicetuan_middle_groupon

# CMS团购业务
# 应用相关命令支持
以下命令基于未编译成二进制文件之前
conf/config.yml为基础配置文件
此架子现在是个泥糊浆,只是将各种组件组合起来，有些很多地方粗糙，大家一起完善。
 * web的启动
   go run src/main.go start -c ./conf/config.yml 启动web程序[-c 不指定，默认当前目录下的conf/config.yml]
   在 src/cmd/start.go 是web启动相关
 * model脚手架的使用
   go run src/main.go model  生成model struct的脚手架，入口在 src/cmd/scaffold_model.go是model脚手架相关
   * -d, --desc string     描述信息
   * -n, --name string     model的struct名字
   * -s, --source string   链接的数据源 (default "cms")
   * -t, --table string    table 表名
 * kafka 任务的处理,目前是和入淘go项目类似，一个topic起一个进程方式,后续是所有的消费队列都放在
一个进程里，还是说目前这种方式待和大家探讨。<br>
    在 src/cmd/kafka.go这里是启动kafka 入口
    需要在 conf/kafka_consumer.yml里配置消费者的相关信息
    启动方式 go run src/main.go kafka --consumer test
    在modules/kafka 下有消费kafka的例子
 * rabbitMq
   官方提供的SDK，未提供连接池支持，但是看源码，是单独起了一个协程来保持链接的活性【ping操作】，且限制了channel的最大数
   ***channel是rabbitMq特有的机制，用来复用一个TCP理解，一个channel需要在一个单独的协程里。
   把channel比喻成人，tcp比喻成门，好理解些，就是多个人出入一个门，而不是一个人一个门。***
   如果不在web工程做发送消息的操作，而是使用类似入淘go项目，那就不用过渡封装了，对于同一个消费者而言，起一个TCP连接，一个协程里放一个channel即可，一个消费者单独起一个进程的方式。
   如果是在web工程里，见下边写了一个没有排队机制的连接池，需要使用连接池来发送队列消息
### go mod 命令
  * go mod tidy 安装扩展包
  * go mod download 下载扩展包或者直接使用 go get命令
### go其他全类型框架 【有研究的可以使用】
    go micro go较早的微服务框架
    go zero 有脚手架支持，部分代码能用脚手架自动生成
    go rpcx 非全类型框架
### 已加入 pool类，链接不够用的时候，未提供排队机制。
    超时后会再次尝试获取一次查看是否有可用链接，没有的话会返回超时错误
    基于channel控制并发请求
    基于双链表，保存链接及按时间排序
    在library/pool/connect_pool.go 中
### 路由配置在
    在modules/router下配置注册，例子参考groupon_api.go
    modules/router/mapper.go 用来收集注册的路由，并且基于注册的方法参数，
    基于反射自动构造了参数对象，目前参数对象都是依据指针参数方式【必须指针方式】。serviceContext待优化。
### context.context 【值得拥有，现在普遍见于各大项目中】
   可以控制多个go协程通知消息，传递，超时，取消。
### 其他
    1：已加入雪花算法，时钟回滚问题是依赖于sleep，可以传参数不启用sleep【时钟回滚有可能产生重复ID】。待优化代码和提供反解析数字的方法。
    可以使用于社群业务线，社群线貌似未规避时钟回滚问题，对于并发量不大的项目来说，时钟回滚问题可以不考虑。
    2：
### gin
   gin框架是基于go的 net/http做了一层封装，所以在底层对于每个请求会有一个goroutine.
并且做了recover来处理异常，防止在每个请求的goroutine有异常，造成整个程序崩溃退出
#### 基础扩展包说明
  * orm 使用 gorm
  * 配置使用 github.com/spf13/viper [yaml说明](https://www.ruanyifeng.com/blog/2016/07/yaml.html)
  * 命令选项支持 github.com/spf13/cobra
  * 日志使用 zap go.uber.org/zap
  * web框架使用gin [不错的文档](http://www.topgoer.cn/docs/ginkuangjia/ginkuangjia-1c50hfaag99k2)
  * github.com/Shopify/sarama kafka扩展SDK
  * web框架使用gin [gin依赖的验证器示例](https://www.cnblogs.com/zhzhlong/p/10033234.html)
  * 配置中心使用 etcd
  * amqp github.com/streadway/amqp rabbitMq官网，不提供连接池支持，对于每个TCP下的channel有控制最大数目
  * jwt github.com/dgrijalva/jwt-go [jwt说明](https://www.ruanyifeng.com/blog/2018/07/json_web_token-tutorial.html)
### 规范
  * 不要基于一个slice，创建一个新的slice，因为在没扩容前，两个slice指向同一个底层数组
  * 如果变量或是struct里的属性不需要包以外的访问，最好小写，或者提供get方法。如果需要序列化，记得字段首字母大写，否则会造成序列化不出来
  * 使用go函数的时候，记得加 捕获 panic的方法，或者会造成整个程序退出，panic只能在当前go 函数内捕获。不会在go函数之间冒泡传递
### 修改的问题
* go panic [提供案例，防止出错]
* 日志类型不要用错
* 日志格式统一
* 提供给service的注入函数
* dto的脚手架
* 验签支持
#### 日志traceId 的串联问题，需要每个package传递上下文